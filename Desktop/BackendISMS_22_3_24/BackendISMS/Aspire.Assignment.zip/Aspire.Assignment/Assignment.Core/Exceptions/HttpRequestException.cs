using System;


      public class HttpRequestException : Exception
    {
        public HttpRequestException() : base("An error occurred while making an HTTP request.")
        {
        }

        public HttpRequestException(string message) : base(message)
        {
        }
    }
