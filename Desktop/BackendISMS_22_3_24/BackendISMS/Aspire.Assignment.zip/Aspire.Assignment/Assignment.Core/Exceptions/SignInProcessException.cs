using System;

namespace Assignment.Core.Exceptions
{
    // Define the custom exception class
    public class SignInProcessException : Exception
    {
        // Constructor with message and inner exception
        public SignInProcessException(string message, Exception innerException) : base(message, innerException)
        {
            // Optionally, you can add custom logic here
        }

        // Additional constructors if needed
        public SignInProcessException(string message) : base(message)
        {
            // Optionally, you can add custom logic here
        }

        // You can also add additional properties or methods as needed
  

    // Define the custom exception class
    public class InvalidCredentialsException : Exception
    {
        // Constructor with message and inner exception
        public InvalidCredentialsException(string message, Exception innerException) : base(message, innerException)
        {
            // Optionally, you can add custom logic here
        }
    }

    public class EntityNotFoundException : Exception
    {
        // Constructor with message and inner exception
        public EntityNotFoundException(string message, Exception innerException) : base(message, innerException)
        {
            // Optionally, you can add custom logic here
        }
    }

    public class UnauthorizedAccessException : Exception
    {
        // Constructor with message and inner exception
        public UnauthorizedAccessException(string message, Exception innerException) : base(message, innerException)
        {
            // Optionally, you can add custom logic here
        }
    }

    public class UnauthorizedRefreshTokenException : Exception
    {
        // Constructor with message and inner exception
        public UnauthorizedRefreshTokenException(string message, Exception innerException) : base(message, innerException)
        {
            // Optionally, you can add custom logic here
        }
    }

    public class InvalidTokenException : Exception
    {
        // Constructor with message and inner exception
        public InvalidTokenException(string message, Exception innerException) : base(message, innerException)
        {
            // Optionally, you can add custom logic here
        }
    }

    }

}
