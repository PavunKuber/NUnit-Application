using System;

public class MeetingScheduleFailedException : Exception
{
    public MeetingScheduleFailedException() : base("Failed to schedule meeting.")
    {
    }

    public MeetingScheduleFailedException(string message) : base(message)
    {
    }
}
