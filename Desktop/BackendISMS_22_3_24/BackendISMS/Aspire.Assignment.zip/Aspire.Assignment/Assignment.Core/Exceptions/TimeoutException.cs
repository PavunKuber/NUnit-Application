using System;


     public class TimeoutException : Exception
    {
        public TimeoutException() : base("A timeout occurred while waiting for a response.")
        {
        }

        public TimeoutException(string message) : base(message)
        {
        }
    }

