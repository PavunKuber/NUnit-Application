using System;
public class EmptyListNotFoundException : NotFoundException
{
    public EmptyListNotFoundException() : base("Empty list returned.")
    {
    }

    public EmptyListNotFoundException(string message) : base(message)
    {
    }
}