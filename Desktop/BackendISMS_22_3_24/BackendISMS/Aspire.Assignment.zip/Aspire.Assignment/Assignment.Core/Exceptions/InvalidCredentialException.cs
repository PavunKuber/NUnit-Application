using System;
public class InvalidCredentialsException : Exception
{
    public InvalidCredentialsException(string message, Exception innerException) : base(message, innerException)
    {
    }
}
