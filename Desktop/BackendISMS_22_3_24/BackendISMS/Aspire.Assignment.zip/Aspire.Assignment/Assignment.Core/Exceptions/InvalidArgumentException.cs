using System;


    public class InvalidArgumentException : Exception
    {
        public InvalidArgumentException() : base("Invalid argument provided.")
        {
        }

        public InvalidArgumentException(string message) : base(message)
        {
        }
    }
