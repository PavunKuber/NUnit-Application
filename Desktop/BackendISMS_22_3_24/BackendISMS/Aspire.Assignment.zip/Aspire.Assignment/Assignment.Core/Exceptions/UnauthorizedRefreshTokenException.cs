using System;
public class UnauthorizedRefreshTokenException : Exception
{
    public UnauthorizedRefreshTokenException() : base("Unauthorized access to refresh token.")
    {
    }

    public UnauthorizedRefreshTokenException(string message) : base(message)
    {
    }
}