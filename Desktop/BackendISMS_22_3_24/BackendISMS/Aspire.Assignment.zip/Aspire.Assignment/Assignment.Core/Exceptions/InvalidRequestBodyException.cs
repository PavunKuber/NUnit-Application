﻿using System;

namespace Assignment.Core.Exceptions
{
    // Custom exception class for invalid request body
    public class InvalidRequestBodyException : Exception
    {
        public string[] Errors { get; }

        // Constructor with error message and array of errors
        public InvalidRequestBodyException(string message, string[] errors) : base(message)
        {
            Errors = errors;
        }

        // Constructor with only error message
        public InvalidRequestBodyException(string message) : base(message)
        {
            Errors = new string[0];
        }
    }
}
