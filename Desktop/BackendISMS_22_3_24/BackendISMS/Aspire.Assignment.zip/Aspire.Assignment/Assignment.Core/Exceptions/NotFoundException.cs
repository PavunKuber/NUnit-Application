using System;

namespace Assignment.Core.Exceptions
{
    // Custom exception for indicating a not found error
    public class NotFoundException : Exception
    {
        public NotFoundException() : base("Resource not found.")
        {
        }

        public NotFoundException(string message) : base(message)
        {
        }
    }
}
