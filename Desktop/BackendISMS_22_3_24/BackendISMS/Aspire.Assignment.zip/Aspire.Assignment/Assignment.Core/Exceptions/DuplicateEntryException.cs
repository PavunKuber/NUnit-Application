using System;
public class DuplicateEntryException : Exception
{
    public DuplicateEntryException() : base("Attempted to add a duplicate entry into the system.")
    {
    }

    public DuplicateEntryException(string message) : base(message)
    {
    }
}
