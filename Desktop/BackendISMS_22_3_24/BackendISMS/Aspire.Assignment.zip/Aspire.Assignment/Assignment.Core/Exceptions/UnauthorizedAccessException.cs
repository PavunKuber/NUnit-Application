using System;

public class UnauthorizedAccessException : Exception
{
    public UnauthorizedAccessException() : base("Unauthorized access.")
    {
    }

    public UnauthorizedAccessException(string message) : base(message)
    {
    }
}
