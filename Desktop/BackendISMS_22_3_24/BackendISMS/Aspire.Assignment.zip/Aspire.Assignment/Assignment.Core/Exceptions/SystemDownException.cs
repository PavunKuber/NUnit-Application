using System;

// Custom exception for when the system is down
public class SystemDownException : Exception
{
    public SystemDownException() : base("The system is currently down.")
    {
    }

    public SystemDownException(string message) : base(message)
    {
    }
}

// Custom exception for database connection issues
public class DatabaseConnectionException : Exception
{
    public DatabaseConnectionException() : base("An error occurred while establishing a connection to the database.")
    {
    }

    public DatabaseConnectionException(string message) : base(message)
    {
    }
}

// Custom exception for network-related issues
public class NetworkException : Exception
{
    public NetworkException() : base("An error occurred in the network.")
    {
    }

    public NetworkException(string message) : base(message)
    {
    }
}
