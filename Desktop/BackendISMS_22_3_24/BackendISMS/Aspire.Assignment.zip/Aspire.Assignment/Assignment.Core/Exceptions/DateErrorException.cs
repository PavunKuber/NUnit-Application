using System;

public class DateErrorException : Exception
{
    public DateErrorException() : base("Date and time  processing or validation error occurred.")
    {
    }

    public DateErrorException(string message) : base(message)
    {
    }

    public DateErrorException(string message, Exception innerException) : base(message, innerException)
    {
    }
}
