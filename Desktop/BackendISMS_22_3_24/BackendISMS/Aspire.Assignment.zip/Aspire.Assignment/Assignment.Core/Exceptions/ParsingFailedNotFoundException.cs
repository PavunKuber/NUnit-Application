using System;
public class ParsingFailedNotFoundException : NotFoundException
{
    public ParsingFailedNotFoundException() : base("Failed to parse data.")
    {
    }

    public ParsingFailedNotFoundException(string message) : base(message)
    {
    }
}