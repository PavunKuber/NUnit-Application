using System;
public class InvalidInputException : Exception
{
    public InvalidInputException() : base("The input data does not meet the required criteria or is invalid.")
    {
    }

    public InvalidInputException(string message) : base(message)
    {
    }
}
