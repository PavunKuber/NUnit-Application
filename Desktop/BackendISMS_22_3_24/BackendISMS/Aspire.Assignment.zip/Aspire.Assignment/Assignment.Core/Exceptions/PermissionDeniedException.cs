using System;
 public class PermissionDeniedException : Exception
    {
        public PermissionDeniedException(string message) : base(message)
        {
            
        }
    }