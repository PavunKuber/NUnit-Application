using System;


 public class InvalidOperationException : Exception
    {
        public InvalidOperationException() : base("Invalid operation performed.")
        {
        }

        public InvalidOperationException(string message) : base(message)
        {
        }
    }
