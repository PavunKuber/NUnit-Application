using System;

public class UserRoleException : Exception
{
    public UserRoleException() : base("An error occurred related to user roles.")
    {
    }

    public UserRoleException(string message) : base(message)
    {
    }

    public UserRoleException(string message, Exception innerException) : base(message, innerException)
    {
    }
}
