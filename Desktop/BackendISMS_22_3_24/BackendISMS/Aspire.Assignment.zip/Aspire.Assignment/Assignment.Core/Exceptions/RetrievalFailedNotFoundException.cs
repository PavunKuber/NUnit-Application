
using System;
public class RetrievalFailedNotFoundException : NotFoundException
{
    public RetrievalFailedNotFoundException() : base("Failed to retrieve data.")
    {
    }

    public RetrievalFailedNotFoundException(string message) : base(message)
    {
    }
}