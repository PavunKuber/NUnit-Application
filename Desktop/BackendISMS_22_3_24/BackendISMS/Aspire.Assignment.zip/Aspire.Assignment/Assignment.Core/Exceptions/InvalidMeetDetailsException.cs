using System;

public class InvalidMeetDetailsException : Exception
{
    public InvalidMeetDetailsException() : base("Invalid meeting details provided.")
    {
    }

    public InvalidMeetDetailsException(string message) : base(message)
    {
    }
}
