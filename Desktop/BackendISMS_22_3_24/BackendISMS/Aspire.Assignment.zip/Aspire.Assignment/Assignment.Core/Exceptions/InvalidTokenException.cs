using System;

namespace Assignment.Core.Exceptions
{
    public class InvalidTokenException : Exception
    {
        public InvalidTokenException() : base("Invalid token provided.")
        {
        }

        public InvalidTokenException(string message) : base(message)
        {
        }
    }
}
