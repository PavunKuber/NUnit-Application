﻿using Microsoft.AspNetCore.Authentication; // Importing Microsoft.AspNetCore.Authentication namespace
using Microsoft.AspNetCore.Authentication.Cookies; // Importing Microsoft.AspNetCore.Authentication.Cookies namespace
using Microsoft.AspNetCore.Authentication.Google; // Importing Microsoft.AspNetCore.Authentication.Google namespace
using Microsoft.AspNetCore.Authentication.JwtBearer; // Importing Microsoft.AspNetCore.Authentication.JwtBearer namespace
using Microsoft.Extensions.Configuration; // Importing Microsoft.Extensions.Configuration namespace
using Microsoft.Extensions.DependencyInjection; // Importing Microsoft.Extensions.DependencyInjection namespace
using Microsoft.Extensions.Options; // Importing Microsoft.Extensions.Options namespace
using Microsoft.IdentityModel.Tokens; // Importing Microsoft.IdentityModel.Tokens namespace
using System.Text; // Importing System.Text namespace

namespace Assignment.Core.Security
{
    // Static class to add authentication-related services
    public static class AuthenticationExtensions
    {
        // Method to configure and add authentication services
        public static void AddMarketplaceAuthentication(this IServiceCollection services, IConfiguration configuration)
        {
            try
            {
                var isAuthEnabled = false; // Flag to check if authentication is enabled

                // Configure authentication services
                var authenticationBuilder = services.AddAuthentication(options =>
                {
                    options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme; // Set default authentication scheme to JwtBearer
                    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme; // Set default challenge scheme to JwtBearer
                });

                // Get Google authentication configuration section
                IConfigurationSection config = configuration.GetSection("Authentication:Google");
                if (config != null)
                {
                    // Check if Google OAuth is enabled
                    bool.TryParse(config["IsOAuthEnabled"], out isAuthEnabled);
                    if (isAuthEnabled)
                    {
                        // Add Google authentication
                        AddGoogleAuthentication(authenticationBuilder, config);
                    }
                }

                // Get JWT authentication configuration section
                config = configuration.GetSection("Authentication:Jwt");
                if (config != null)
                {
                    // Check if JWT authentication is enabled
                    bool.TryParse(config["IsJwtEnabled"], out isAuthEnabled);
                    if (isAuthEnabled)
                    {
                        // Add authorization policies if needed
                        services.AddAuthorization(options =>
                        {
                            // Example: Add policy to require authenticated user with a specific claim
                            //options.AddPolicy("AuthorizedUsersOnly", policy =>
                            //{
                            //    policy.RequireAuthenticatedUser();
                            //    policy.RequireClaim("userId");
                            //});
                        });

                        // Add JWT authentication
                        AddJwtAuthentication(authenticationBuilder, config);
                    }
                }
            }
            catch (Exception )
            {
                // Handle exceptions
            }
        }

        // Method to add Google authentication
        private static void AddGoogleAuthentication(AuthenticationBuilder authenticationBuilder, IConfigurationSection configurationSection)
        {
            // Configure Google authentication
            authenticationBuilder.AddCookie() // Add cookie authentication
            .AddGoogle(options =>
            {
                options.ClientId = configurationSection["client_id"]; // Set Google OAuth client ID
                options.ClientSecret = configurationSection["client_secret"]; // Set Google OAuth client secret
            });
        }

        // Method to add JWT authentication
        private static void AddJwtAuthentication(AuthenticationBuilder authenticationBuilder, IConfigurationSection configurationSection)
        {
            var key = Encoding.ASCII.GetBytes(configurationSection.GetValue<string>("Secret")); // Retrieve secret key from configuration

            // Configure JWT bearer authentication
            authenticationBuilder.AddJwtBearer(options =>
            {
                options.RequireHttpsMetadata = false; // Disable HTTPS metadata requirement
                options.SaveToken = true; // Enable saving token
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true, // Validate issuer signing key
                    IssuerSigningKey = new SymmetricSecurityKey(key), // Set issuer signing key
                    ValidateIssuer = false, // Disable issuer validation
                    ValidateAudience = false // Disable audience validation
                };
            });
        }
    }
}
