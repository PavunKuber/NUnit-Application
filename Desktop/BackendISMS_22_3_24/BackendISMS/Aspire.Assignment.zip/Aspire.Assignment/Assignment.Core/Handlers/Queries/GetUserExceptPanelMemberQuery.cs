using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Assignment.Contracts.Data;
using Assignment.Contracts.Data.Repositories;
using Assignment.Contracts.DTO;
using MediatR;
 
namespace Assignment.Providers.Handlers.Queries
{
    public class GetUserExceptPanelMemberQuery : IRequest<IEnumerable<PanelMemberDTO>> { }
 
    public class GetUserExceptPanelMemberQueryHandler
        : IRequestHandler<GetUserExceptPanelMemberQuery, IEnumerable<PanelMemberDTO>>
    {
        private readonly IUnitOfWork _repository;
 
        public GetUserExceptPanelMemberQueryHandler(IUnitOfWork repository)
        {
            _repository = repository;
        }
 
        public async Task<IEnumerable<PanelMemberDTO>> Handle(
            GetUserExceptPanelMemberQuery request,
            CancellationToken cancellationToken
        )
        {
            var otherUsers = await _repository.PanelCoordinator.GetUserExceptPanelMember();
            return otherUsers;
        }
    }
}
 