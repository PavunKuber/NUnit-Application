using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Assignment.Contracts.Data;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.Data.Repositories;
using Assignment.Contracts.DTO;
using MediatR;

namespace Assignment.Providers.Handlers.Queries
{
    public class GetTeamMemberQuery : IRequest<IEnumerable<TeamMemberDTO>>
    {
        public string LoggedInUser { get; }

        public GetTeamMemberQuery(string loggedInUser)
        {
            LoggedInUser = loggedInUser;
        }
    }

    public class GetTeamMemberQueryHandler : IRequestHandler<GetTeamMemberQuery, IEnumerable<TeamMemberDTO>>
    {
        private readonly IUnitOfWork _unitOfWork;

        public GetTeamMemberQueryHandler(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<IEnumerable<TeamMemberDTO>> Handle(GetTeamMemberQuery request, CancellationToken cancellationToken)
        {
            var managerName = request.LoggedInUser;
            var members = await _unitOfWork.TeamMember.GetTeamMemberAsync(managerName);
            return members;
        }
    }
}
