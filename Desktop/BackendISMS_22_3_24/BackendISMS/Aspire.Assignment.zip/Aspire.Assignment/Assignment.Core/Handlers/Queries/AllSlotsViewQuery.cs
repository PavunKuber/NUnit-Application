// using Assignment.Contracts.Data;
// using Assignment.Contracts.Data.Entities;
// using Assignment.Contracts.DTO;
// using MediatR;
// using System.Collections.Generic;
// using System.Linq;
// using System.Threading;
// using System.Threading.Tasks;

// namespace Assignment.Providers.Handlers.Queries
// {
//     // Represents a query request to fetch all slot details.
//     public class AllSlotsViewQuery : IRequest<IEnumerable<SlotDetailsDTO>>
//     {
//         // No properties or parameters needed since you want to retrieve all slots.
//     }

//     // Handles the AllSlotsViewQuery request and returns a collection of SlotDetailsDTO.
//     public class AllSlotsViewQueryHandler : IRequestHandler<AllSlotsViewQuery, IEnumerable<SlotDetailsDTO>>
//     {
//         private readonly IUnitOfWork _unitOfWork;

//         public AllSlotsViewQueryHandler(IUnitOfWork unitOfWork)
//         {
//             _unitOfWork = unitOfWork;
//         }

//         // Handles the query request and returns all slot details.
//         public async Task<IEnumerable<SlotDetailsDTO>> Handle(AllSlotsViewQuery request, CancellationToken cancellationToken)
//         {
//             // Retrieve all slot details from the repository.
//             var slotDetails = await _unitOfWork.SlotDetails.GetAllAsync();

//             // Map the retrieved slot entities to SlotDetailsDTO objects.
//             var slotDetailsDTOs = slotDetails.Select(slot =>
//                 new SlotDetailsDTO
//                 {
//                     // Map properties accordingly
                    
//                     userName = slot.userName,
//                     Date = slot.Date,
//                     StartTime = slot.StartTime,
                
//                     IsAvailable = slot.IsAvailable,
//                     IsBlocked = slot.IsBlocked
//                 });

//             return slotDetailsDTOs;
//         }
//     }
// }
