using System.Linq;
using Assignment.Contracts.Data;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.Data.Repositories;
using Assignment.Contracts.DTO;
using MediatR;
#nullable disable

namespace Assignment.Providers.Handlers.Queries
{
    public class GetUserRoleQuery : IRequest<IEnumerable<UsersDetailDTO>> { }

    public class GetUserRoleQueryHandler
        : IRequestHandler<GetUserRoleQuery, IEnumerable<UsersDetailDTO>>
    {
        private readonly IUserRoleRepository _userRoleRepository;

        public GetUserRoleQueryHandler(IUserRoleRepository userRoleRepository)
        {
            _userRoleRepository = userRoleRepository;
        }

        public async Task<IEnumerable<UsersDetailDTO>> Handle(
            GetUserRoleQuery request,
            CancellationToken cancellationToken
        )
        {
            var entities = await _userRoleRepository.GetUserRoleAsync();

            return (IEnumerable<UsersDetailDTO>)entities;
        }
    }
}
