using System.Linq;
using Assignment.Contracts.Data;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.DTO;
using MediatR;
 
namespace Assignment.Providers.Handlers.Queries
{
    // This class represents a query request to fetch all users.
    public class GetAllocatedateQuery : IRequest<IEnumerable<AllocateDateDTO>>
    {
        public string loggedInUser { get; }
 
        public GetAllocatedateQuery(string _loggedInUser)
        {
            loggedInUser = _loggedInUser;
        }
    }
 
    public class GetAllocatedateQueryHandler
        : IRequestHandler<GetAllocatedateQuery, IEnumerable<AllocateDateDTO>>
    {
        //references to the dependencies required by the handler.
        private readonly IUnitOfWork _repository;
 
        // two parameters an instance of IUnitOfWork and IMapper.dependencies are injected into the handler.
        public GetAllocatedateQueryHandler(IUnitOfWork repository)
        {
            _repository = repository;
        }
 
        // Handle method required by the IRequestHandler interface
        public async Task<IEnumerable<AllocateDateDTO>> Handle(
            GetAllocatedateQuery request,
            CancellationToken cancellationToken
        )
        {
 
            var AllocateDate = new List<AllocateDateDTO>();
            var entities = await Task.FromResult(_repository.AllocateDate.GetAll());
 
            var users = await Task.FromResult(
                _repository.Users.GetAll().FirstOrDefault(u => u.Name == request.loggedInUser)
            );
 
            var email = users.Email;
 
            var dateDetails = await Task.FromResult(
                _repository.AllocateDate.GetAll().Where(u => u.Email == email).ToList()
            );
 
         
 
            foreach (var detail in dateDetails)
            {
                AllocateDate.Add(
                    new AllocateDateDTO{
                        StartDate = detail.StartDate.Date,
                        EndDate = detail.EndDate.Date,
                        Email = detail.Email
                    }
                );
            }
            return AllocateDate;
 
        }
    }
}
 