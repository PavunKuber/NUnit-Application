using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Assignment.Contracts.Data;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.DTO;
using Assignment.Core.Exceptions;
using MediatR;

namespace Assignment.Providers.Handlers.Queries
{
    public class GetCodeMasterQuery : IRequest<IEnumerable<CodeMasterDTO>> { }

    public class GetCodeMasterQueryHandler : IRequestHandler<GetCodeMasterQuery, IEnumerable<CodeMasterDTO>>
    {
        private readonly IUnitOfWork _unitOfWork;

        public GetCodeMasterQueryHandler(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<IEnumerable<CodeMasterDTO>> Handle(GetCodeMasterQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var entities = await _unitOfWork.CodeMaster.GetAllAsync();
                var dtos = entities.Select(entity => new CodeMasterDTO
                {
                    CodeName = entity.CodeName
                });
                return dtos;
            }
            catch (Exception ex)
            {
                // Log the exception for further investigation
                Console.WriteLine($"An error occurred in GetCodeMasterQueryHandler: {ex}");
                
                // Rethrow the exception or handle it according to your requirement
                throw; // Rethrow the exception
            }
        }
    }
}
