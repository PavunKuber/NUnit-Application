using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.Data.Repositories;
using MediatR;

namespace Assignment.Providers.Handlers.Queries
{
    // Define the query
    public class GetAllUsersQuery : IRequest<List<Users>>
    {
        // No properties needed for this query
    }

    // Handler for the query
    public class GetAllUsersQueryHandler : IRequestHandler<GetAllUsersQuery, List<Users>>
    {
        private readonly IUserRoleRepository _userRepository;

        public GetAllUsersQueryHandler(IUserRoleRepository userRepository)
        {
            _userRepository = userRepository;
        }

        public async Task<List<Users>> Handle(
            GetAllUsersQuery request,
            CancellationToken cancellationToken
        )
        {
            // Implement your logic to retrieve all users here
            var users = await _userRepository.GetAllAsync();

            return users.ToList(); // Explicitly convert IEnumerable<Users> to List<Users>
        }
    }
}
