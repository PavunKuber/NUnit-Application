using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Assignment.Contracts.Data.Repositories;
using Assignment.Contracts.DTO;
using MediatR;

namespace Assignment.Providers.Handlers.Queries
{
    public class GetAllRolesQuery : IRequest<IEnumerable<RolesDTO>> { }

    public class GetAllRolesQueryHandler : IRequestHandler<GetAllRolesQuery, IEnumerable<RolesDTO>>
    {
        private readonly IRolesRepository _rolesRepository;

        public GetAllRolesQueryHandler(IRolesRepository rolesRepository)
        {
            _rolesRepository = rolesRepository;
        }

        public async Task<IEnumerable<RolesDTO>> Handle(
            GetAllRolesQuery request,
            CancellationToken cancellationToken
        )
        {
            var roles = await _rolesRepository.GetAllAsync();
            var rolesDTOs = new List<RolesDTO>();

            foreach (var role in roles)
            {
                rolesDTOs.Add(
                    new RolesDTO
                    {
                        RoleName = role.RoleName,
                        RoleDescription = role.RoleDescription
                    }
                );
            }

            return rolesDTOs;
        }
    }
}
