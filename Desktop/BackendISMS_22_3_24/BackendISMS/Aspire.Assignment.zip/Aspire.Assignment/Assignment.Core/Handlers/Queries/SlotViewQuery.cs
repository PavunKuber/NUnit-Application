using System.Linq;
using Assignment.Contracts.Data;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.DTO;
using MediatR;

namespace Assignment.Providers.Handlers.Queries
{
    // This class represents a query request to fetch all users.
    public class SlotViewQuery : IRequest<IEnumerable<ViewSlotDTO>>
    {
        public string loggedInUser { get; }

        public SlotViewQuery(string _loggedInUser)
        {
            loggedInUser = _loggedInUser;
        }
    }

    public class SlotViewQueryHandler : IRequestHandler<SlotViewQuery, IEnumerable<ViewSlotDTO>>
    {
        //references to the dependencies required by the handler.
        private readonly IUnitOfWork _repository;

        // two parameters an instance of IUnitOfWork and IMapper.dependencies are injected into the handler.
        public SlotViewQueryHandler(IUnitOfWork repository)
        {
            _repository = repository;
        }

        // Handle method required by the IRequestHandler interface
        public async Task<IEnumerable<ViewSlotDTO>> Handle(
            SlotViewQuery request,
            CancellationToken cancellationToken
        )
        {
            var entities = await _repository.SlotDetails.GetAllSlotDetailsByUserName(
                request.loggedInUser
            );

            var users = await Task.FromResult(
                _repository.Users.GetAll().FirstOrDefault(u => u.Name == request.loggedInUser)
            );

            var codeMap = await Task.FromResult(
                _repository.CodeMapping.GetAll().FirstOrDefault(c => c.UserId == users.UserId)
            );

            var codeId = codeMap.CodeId;
            var levelId = codeMap.InterviewId;

            var codeDetails = await Task.FromResult(_repository.CodeMaster.Get(codeId));
            var interviewDetails = await Task.FromResult(_repository.LevelMaster.Get(levelId));

            var viewSlotDTOs = entities.Select(entity => new ViewSlotDTO
            {
                SlotId = entity.SlotId,
                Position = codeDetails.CodeName + ":" + interviewDetails.InterviewLevel,
                Date = entity.Date,
                StartTime = entity.StartTime,
                EndTime = entity.EndTime,
                Status = entity.Status,
                Remarks = entity.Remarks
            });

            return viewSlotDTOs;
        }
    }
}
