using System;
using System.IdentityModel.Tokens.Jwt;
using System.Reflection;
using System.Security.Authentication;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Assignment.Contracts.Data;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.Data.Repositories;
using Assignment.Contracts.DTO;
using Assignment.Contracts.DTO;
using Assignment.Core.Exceptions;
using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace Assignment.Providers.Handlers.Queries
{
    public class SignInAdminByAdminNameQuery : IRequest<TokenResponseDTO>
    {
        public string UserName { get; }
        public string PassWord { get; }

        public SignInAdminByAdminNameQuery(string userName, string password)
        {
            UserName = userName;
            PassWord = password;
        }
    }

    public class SignInAdminByAdminNameQueryHandler
        : IRequestHandler<SignInAdminByAdminNameQuery, TokenResponseDTO>
    {
        private readonly IUnitOfWork _repository;
        private readonly IPasswordHasher<User> _passwordHasher;
        private readonly IConfiguration _configuration;
        private readonly IRefreshTokenRepository _refreshTokenRepository; // Add refresh token repository

        public SignInAdminByAdminNameQueryHandler(
            IUnitOfWork repository,
            IPasswordHasher<User> passwordHasher,
            IConfiguration configuration,
            IRefreshTokenRepository refreshTokenRepository
        )
        {
            _repository = repository;
            _passwordHasher = passwordHasher;
            _configuration = configuration;
            _refreshTokenRepository = refreshTokenRepository;
        }

        public async Task<TokenResponseDTO> Handle(
            SignInAdminByAdminNameQuery request,
            CancellationToken cancellationToken
        )
        {
            var user = await Task.FromResult(
                _repository.Users.GetAll().FirstOrDefault(con => con.Name.Equals(request.UserName))
            );

            if (user == null)
            {
                throw new EntityNotFoundException($"No User found for  {request.UserName}");
            }

            // PasswordVerificationResult result = _passwordHasher.VerifyHashedPassword(user, user.Password, request.PassWord);
            if (request.PassWord != user.Password)
            {
                throw new InvalidCredentialException($"Invalid credentials");
            }

            var userRole = _repository
                .UserRoles.GetAll()
                .Where(con => con.UserId == user.UserId)
                .FirstOrDefault();

            var role = _repository
                .Roles.GetAll()
                .Where(con => con.RoleId == userRole.RoleId)
                .FirstOrDefault();

            var roleName = role.RoleName;

            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.ASCII.GetBytes(
                _configuration.GetValue<string>("Authentication:Jwt:Secret")
            );

            // Create claims for the token
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, user.Name),
                new Claim(ClaimTypes.Role, roleName)
                // Add additional claims here as needed
            };

            // Set token expiration times
            var accessTokenExpires = DateTime.UtcNow.AddMinutes(15); // Example: Access token expires in 15 minutes
            var refreshTokenExpires = DateTime.UtcNow.AddDays(7); // Example: Refresh token expires in 7 days

            // Create access token
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),
                Expires = accessTokenExpires,
                SigningCredentials = new SigningCredentials(
                    new SymmetricSecurityKey(key),
                    SecurityAlgorithms.HmacSha256Signature
                )
            };
            var accessToken = tokenHandler.CreateToken(tokenDescriptor);

            // Create refresh token
            var refreshToken = GenerateRefreshToken();

            // Store the refresh token securely (e.g., in a database)
            await _refreshTokenRepository.AddAsync(
                new RefreshToken
                {
                    Token = refreshToken,
                    ExpiresAt = refreshTokenExpires,
                    UserId = user.UserId
                }
            );

            // Return tokens
            return new TokenResponseDTO
            {
                AccessToken = tokenHandler.WriteToken(accessToken),
                AccessTokenExpiration = accessTokenExpires,
                RefreshToken = refreshToken,
                RefreshTokenExpiration = refreshTokenExpires,
                Username = request.UserName
            };
        }

        private string GenerateRefreshToken()
        {
            // Generate a random refresh token
            var randomNumber = new byte[32];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(randomNumber);
                return Convert.ToBase64String(randomNumber);
            }
        }
    }
}
