using Assignment.Contracts.Data;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.DTO;
using MediatR;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Assignment.Providers.Handlers.Queries
{
    // This class represents a query request to fetch all LevelMaster.  
    public class GetLevelMasterQuery : IRequest<IEnumerable<LevelMasterDTO>>
    {
       
    }
    
    // Class handles the GetAllUsersQuery request and returns a collection of LevelMasterDTO
    public class GetLevelMasterQueryHandler : IRequestHandler<GetLevelMasterQuery, IEnumerable<LevelMasterDTO>>
    {
        // References to the dependencies required by the handler.
        private readonly IUnitOfWork _repository;

        // Two parameters an instance of IUnitOfWork.dependencies are injected into the handler.
        public GetLevelMasterQueryHandler(IUnitOfWork repository)
        {
            _repository = repository;
        }

        // Handle method required by the IRequestHandler interface
        public async Task<IEnumerable<LevelMasterDTO>> Handle(GetLevelMasterQuery request, CancellationToken cancellationToken)
        {
            // Retrieves all LevelMaster entities from the repository asynchronously
            var entities = await _repository.LevelMaster.GetAllAsync();
 
            // Manually map the retrieved LevelMaster entities to LevelMasterDTO objects
            var dtos = entities.Select(entity => new LevelMasterDTO
            {
                ILevel = entity.InterviewLevel // Map the Name property to ILevel property
            });

            return dtos;
        }
    }
}
