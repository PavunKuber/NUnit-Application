using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Assignment.Contracts.Data;
using Assignment.Contracts.Data.Repositories;
using Assignment.Contracts.DTO;
using MediatR;

namespace Assignment.Providers.Handlers.Queries
{
    public class GetPanelMemberQuery : IRequest<IEnumerable<PanelMemberDTO>> { }

    public class GetPanelMemberQueryHandler
        : IRequestHandler<GetPanelMemberQuery, IEnumerable<PanelMemberDTO>>
    {
        private readonly IUnitOfWork _repository;

        public GetPanelMemberQueryHandler(IUnitOfWork repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<PanelMemberDTO>> Handle(
            GetPanelMemberQuery request,
            CancellationToken cancellationToken
        )
        {
            var panelCoordinators = await _repository.PanelCoordinator.GetUser();
            return panelCoordinators;
        }
    }
}
