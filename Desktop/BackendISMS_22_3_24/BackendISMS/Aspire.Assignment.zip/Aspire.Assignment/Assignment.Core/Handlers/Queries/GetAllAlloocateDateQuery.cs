using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Assignment.Contracts.Data;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.Data.Repositories;
using Assignment.Contracts.DTO;
using MediatR;
 
namespace Assignment.Providers.Handlers.Queries
{
    public class GetAllAlloocateDateQuery : IRequest<IEnumerable<AllocateDateDTO>> { }
 
    public class GetAllAlloocateDateQueryHandler : IRequestHandler<GetAllAlloocateDateQuery, IEnumerable<AllocateDateDTO>>
    {
         private readonly IUnitOfWork _repository;
 
        public GetAllAlloocateDateQueryHandler(IUnitOfWork repository)
        {
             _repository = repository;
        }
 
        public async Task<IEnumerable<AllocateDateDTO>> Handle(
            GetAllAlloocateDateQuery request,
            CancellationToken cancellationToken
        )
        {
            var dates = await _repository.AllocateDate.GetAllAsync();
            var AllocateDateDTO = new List<AllocateDateDTO>();
 
            foreach (var date in dates)
            {
                AllocateDateDTO.Add(
                    new AllocateDateDTO
                    {
                        Email = date.Email,
                        StartDate = date.StartDate,
                        EndDate = date.EndDate,
                    }
                );
            }
 
            return AllocateDateDTO;
        }
    }
}