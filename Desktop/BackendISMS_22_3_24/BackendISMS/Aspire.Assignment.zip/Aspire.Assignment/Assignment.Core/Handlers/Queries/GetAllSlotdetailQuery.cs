#region using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Assignment.Contracts.Data;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.DTO;
using MediatR;
#endregion using

namespace Assignment.Providers.Handlers.Queries
{
    // This class represents a query request to fetch all users.
    public class GetAllSlotdetailQuery : IRequest<IEnumerable<TAViewSlotDTO>> { }

    // class handles the GetAllUsersQuery request and returns a collection of UsersDTO
    public class GetAllSlotdetailQueryHandler
        : IRequestHandler<GetAllSlotdetailQuery, IEnumerable<TAViewSlotDTO>>
    {
        // references to the dependencies required by the handler.
        private readonly IUnitOfWork _repository;

        // two parameters an instance of IUnitOfWork and IMapper.dependencies are injected into the handler.
        public GetAllSlotdetailQueryHandler(IUnitOfWork repository)
        {
            _repository = repository;
        }

        // Handle method required by the IRequestHandler interface
        public async Task<IEnumerable<TAViewSlotDTO>> Handle(
            GetAllSlotdetailQuery request,
            CancellationToken cancellationToken
        )
        {
            // retrieves all user entities from the repository asynchronously
            var entities = await Task.FromResult(_repository.SlotDetails.GetAll());

            // maps the retrieved user entities to TAViewSlotDTO objects
            return entities.Select(e => new TAViewSlotDTO
            {
                SlotId = e.SlotId,
                userName = e.userName,
                Date = e.Date,
                StartTime = e.StartTime,
                EndTime = e.EndTime,
                Status = e.Status,
                Remarks = e.Remarks
            });
        }
    }
}
