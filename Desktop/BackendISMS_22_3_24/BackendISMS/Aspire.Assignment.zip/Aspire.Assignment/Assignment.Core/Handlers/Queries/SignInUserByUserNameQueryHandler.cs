// using System.IdentityModel.Tokens.Jwt;
// using System.Security.Claims;
// using System.Text;
// using Assignment.Contracts.Data;
// using Assignment.Contracts.DTO;
// using Assignment.Core.Exceptions;
// using MediatR;
// using Microsoft.Extensions.Configuration;
// using Microsoft.IdentityModel.Tokens;
// using Assignment.Contracts.Data.Repositories;
// using System.Security.Cryptography;
// using Assignment.Contracts.Data.Entities;
// using Microsoft.AspNetCore.Identity;


// namespace Assignment.Providers.Handlers.Queries
// {
//     public class SignInUserByUserNameQuery : IRequest<TokenResponseDTO>// Declaration of SignInUserByUserNameQuery class.
//     {
//         public string UserName { get; }
//         public string PassWord { get; }
//         public SignInUserByUserNameQuery(string userName, string password)
//         {
//             UserName = userName;
//             PassWord = password;
//         }
//     }
//     public class SignInUserByUserNameQueryHandler : IRequestHandler<SignInUserByUserNameQuery, TokenResponseDTO>
//     {
//         private readonly IUnitOfWork _repository;
//         private readonly IConfiguration _configuration;
//         private readonly IRefreshTokenRepository _refreshTokenRepository;
//            private readonly IPasswordHasher<Users> _passwordHasher;
//            private readonly IUsersRepository _usersRepository;

//         public SignInUserByUserNameQueryHandler(IUnitOfWork repository, IConfiguration configuration, IRefreshTokenRepository refreshTokenRepository,IPasswordHasher<Users> passwordHasher, IUsersRepository usersRepository)
//         {
//             _repository = repository;
//             _configuration = configuration;
//             _refreshTokenRepository = refreshTokenRepository;
//              _passwordHasher=passwordHasher;
//              _usersRepository = usersRepository;
//         }

//         public async Task<TokenResponseDTO> Handle(SignInUserByUserNameQuery request, CancellationToken cancellationToken)
//         {

// var user = await _usersRepository.GetUserByUsernameAsync(request.UserName) 
//                 ?? throw new EntityNotFoundException("User not found");

//             // Fetch the hashed password corresponding to the user from the database
//             string hashedPasswordFromDb = user.Password;

//             // Verify the hashed password against the plain text password
//             var passwordVerificationResult = _passwordHasher.VerifyHashedPassword(null, hashedPasswordFromDb, request.PassWord);

//             if (passwordVerificationResult == PasswordVerificationResult.Success)
//             {
//                 // Passwords match
//                 // Proceed with your logic here
//             }
//             else
//             {
//                 // Passwords do not match
//                 // Handle incorrect password scenario
//                 throw new Exception("Incorrect password");
//             }

// //     var passwordVerificationResult = _passwordHasher.VerifyHashedPassword(user, user.Password, request.PassWord);

// //     if (passwordVerificationResult != PasswordVerificationResult.Success)
// //     {
// //         // Passwords match
// //         throw new Exception("Incorrect password");

// //     }

// // }
// // catch (Exception ex)
// // {
// //     // Catch any exceptions and handle them
// //     Console.WriteLine($"An error occurred: {ex.Message}");
// //     // Handle the exception as needed, possibly return an error response or log it
// // }

//             var userRoles = _repository.UserRoles.GetAll().Where(con => con.UserId == user.UserId).ToList();

//             var roleNames = new List<string>();

//             foreach (var userRole in userRoles)
//             {
//                 var role = _repository.Roles.GetAll().FirstOrDefault(con => con.RoleId == userRole.RoleId);
//                 if (role != null)
//                 {
//                     roleNames.Add(role.RoleName);
//                 }
//             }

//             var tokenHandler = new JwtSecurityTokenHandler();

//             var key = Encoding.ASCII.GetBytes(_configuration.GetValue<string>("Authentication:Jwt:Secret"));

//             var claims = new List<Claim>
//             {
//                 new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString()),
//                 new Claim(ClaimTypes.Name, user.Name)
//             };

//             foreach (var roleName in roleNames)
//             {
//                 claims.Add(new Claim(ClaimTypes.Role, roleName));
//             }

//             var tokenDescriptor = new SecurityTokenDescriptor
//             {
//                 Subject = new ClaimsIdentity(claims),

//                 Expires = DateTime.UtcNow.AddMinutes(30),

//                 SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
//             };

//             var accessTokenExpires = DateTime.UtcNow.AddMinutes(10); // Example: Access token expires in 10 minutes
//             var refreshTokenExpires = DateTime.UtcNow.AddMinutes(30);

//             var token = tokenHandler.CreateToken(tokenDescriptor);

//             // Create refresh token
//             var refreshToken = GenerateRefreshToken();

//             // Store the refresh token securely (e.g., in a database)
//             await _refreshTokenRepository.AddAsync(new RefreshToken { Token = refreshToken, ExpiresAt = refreshTokenExpires, UserId = user.UserId });
//             await _repository.SaveChangesAsync();

//             // Return tokens
//             return new TokenResponseDTO
//             {
//                 AccessToken = tokenHandler.WriteToken(token),
//                 AccessTokenExpiration = accessTokenExpires,
//                 RefreshToken = refreshToken,
//                 RefreshTokenExpiration = refreshTokenExpires,
//                 Username = ClaimTypes.Role
//             };
//         }

//         private string GenerateRefreshToken()
//         {
//             // Generate a random refresh token
//             var randomNumber = new byte[32];
//             using (var rng = RandomNumberGenerator.Create())
//             {
//                 rng.GetBytes(randomNumber);
//                 return Convert.ToBase64String(randomNumber);
//             }
//         }
//     }
// }



using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Assignment.Contracts.Data;
using Assignment.Contracts.DTO;
using Assignment.Core.Exceptions;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Assignment.Contracts.Data.Repositories;
using System.Security.Cryptography;
using Assignment.Contracts.Data.Entities;
using Microsoft.AspNetCore.Identity;


namespace Assignment.Providers.Handlers.Queries
{
    public class SignInUserByUserNameQuery : IRequest<TokenResponseDTO>// Declaration of SignInUserByUserNameQuery class.
    {
        public string UserName { get; }
        public string PassWord { get; }
        public SignInUserByUserNameQuery(string userName, string password)
        {
            UserName = userName;
            PassWord = password;
        }
    }
    public class SignInUserByUserNameQueryHandler : IRequestHandler<SignInUserByUserNameQuery, TokenResponseDTO>
    {
        private readonly IUnitOfWork _repository;
        private readonly IConfiguration _configuration;
        private readonly IRefreshTokenRepository _refreshTokenRepository;
        private readonly IPasswordHasher<Users> _passwordHasher;
        private readonly IUsersRepository _usersRepository;

        public SignInUserByUserNameQueryHandler(IUnitOfWork repository, IConfiguration configuration, IRefreshTokenRepository refreshTokenRepository, IPasswordHasher<Users> passwordHasher, IUsersRepository usersRepository)
        {
            _repository = repository;
            _configuration = configuration;
            _refreshTokenRepository = refreshTokenRepository;
            _passwordHasher = passwordHasher;
            _usersRepository = usersRepository;
        }

        public async Task<TokenResponseDTO> Handle(SignInUserByUserNameQuery request, CancellationToken cancellationToken)
        {


            var user = await _usersRepository.GetUserByUsernameAsync(request.UserName)?? throw new EntityNotFoundException("User not found");
            var passwordVerificationResult = _passwordHasher.VerifyHashedPassword(user,user.Password,request.PassWord);
            if(passwordVerificationResult != PasswordVerificationResult.SuccessRehashNeeded)
            {
                throw new EntityNotFoundException("Password is Incorrect");
            }


            var userRoles = _repository.UserRoles.GetAll().Where(con => con.UserId == user.UserId).ToList();

            var roleNames = new List<string>();

            foreach (var userRole in userRoles)
            {
                var role = _repository.Roles.GetAll().FirstOrDefault(con => con.RoleId == userRole.RoleId);
                if (role != null)
                {
                    roleNames.Add(role.RoleName);
                }
            }
            
        

            var tokenHandler = new JwtSecurityTokenHandler();

            var key = Encoding.ASCII.GetBytes(_configuration.GetValue<string>("Authentication:Jwt:Secret"));

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.UserId.ToString()),
                new Claim(ClaimTypes.Name, user.Name)
            };

            foreach (var roleName in roleNames)
            {
                claims.Add(new Claim(ClaimTypes.Role, roleName));
            }

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),

                Expires = DateTime.UtcNow.AddMinutes(30),

                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var accessTokenExpires = DateTime.UtcNow.AddMinutes(10); // Example: Access token expires in 10 minutes
            var refreshTokenExpires = DateTime.UtcNow.AddMinutes(30);

            var token = tokenHandler.CreateToken(tokenDescriptor);
            var newRefreshToken = GenerateRefreshToken();
            var refreshToken = await _refreshTokenRepository.GetByUserIdAsync(user.UserId);
            // var newRefreshToken = GenerateRefreshToken();
            // var refreshTokenExpires = DateTime.UtcNow.AddMinutes(30); // Example: Refresh token expires in 30 minutes

            if (refreshToken == null)
            {
                // If refresh token doesn't exist, create a new one
                refreshToken = new RefreshToken
                {
                    UserId = user.UserId,
                    Token = newRefreshToken,
                    ExpiresAt = refreshTokenExpires
                };
                await _refreshTokenRepository.AddAsync(refreshToken);
                await _repository.SaveChangesAsync();
            }
            else
            {
                // If refresh token exists, update it with a new one
                refreshToken.Token = newRefreshToken;
                refreshToken.ExpiresAt = refreshTokenExpires;
                await _refreshTokenRepository.UpdateAsync(refreshToken);
                await _repository.SaveChangesAsync();
            }



            // Store the refresh token securely (e.g., in a database)
            // await _refreshTokenRepository.AddAsync(new RefreshToken { Token = newRefreshToken, ExpiresAt = refreshTokenExpires, UserId = user.UserId });
            // await _repository.SaveChangesAsync();
            

            // Return tokens
            return new TokenResponseDTO
            {
                AccessToken = tokenHandler.WriteToken(token),
                AccessTokenExpiration = accessTokenExpires,
                RefreshToken = newRefreshToken,
                RefreshTokenExpiration = refreshTokenExpires,
                Username = ClaimTypes.Role
            };
        }

        private string GenerateRefreshToken()
        {
            // Generate a random refresh token
            var randomNumber = new byte[32];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(randomNumber);
                return Convert.ToBase64String(randomNumber);
            }
        }
    }
}