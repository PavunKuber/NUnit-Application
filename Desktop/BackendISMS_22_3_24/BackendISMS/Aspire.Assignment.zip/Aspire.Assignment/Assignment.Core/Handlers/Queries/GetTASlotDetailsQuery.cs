using System.Linq;
using Assignment.Contracts.Data;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.Data.Repositories;
using Assignment.Contracts.DTO;
using MediatR;
#nullable disable

namespace Assignment.Providers.Handlers.Queries
{
    public class GetSlotDetailsQuery : IRequest<IEnumerable<TAAdminDTO>> { }

    public class GetSlotDetailsQueryHandler
        : IRequestHandler<GetSlotDetailsQuery, IEnumerable<TAAdminDTO>>
    {
        private readonly ITAAdminRepository _repository;

        public GetSlotDetailsQueryHandler(ITAAdminRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<TAAdminDTO>> Handle(
            GetSlotDetailsQuery request,
            CancellationToken cancellationToken
        )
        {
            var entities = await _repository.GetSlotDetailsAsync();

            return entities;
        }
    }
}
