using System.Threading;
using System.Threading.Tasks;
using Assignment.Contracts.Data;
using Assignment.Core.Exceptions;
using MediatR;

namespace Assignment.Providers.Handlers.Commands
{
    public class UpdateSlotAvailabilityCommandHandler
        : IRequestHandler<UpdateSlotAvailabilityCommand, Guid>
    {
        private readonly IUnitOfWork _unitOfWork;

        public UpdateSlotAvailabilityCommandHandler(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<Guid> Handle(
            UpdateSlotAvailabilityCommand request,
            CancellationToken cancellationToken
        )
        {
            var slot = await Task.FromResult(_unitOfWork.SlotDetails.Get(request.SlotId));
            if (slot == null)
            {
                throw new NotFoundException("Slot not found.");
            }
             if (slot.Status == "Unavailable")
            {
                throw new DuplicateUserException($"Slot {slot.Date} is already marked as unavailable.");
            }


            slot.Status = "Unavailable";
            _unitOfWork.SlotDetails.Update(slot);
            await _unitOfWork.CommitAsync();

            return slot.SlotId;
        }
    }
}
