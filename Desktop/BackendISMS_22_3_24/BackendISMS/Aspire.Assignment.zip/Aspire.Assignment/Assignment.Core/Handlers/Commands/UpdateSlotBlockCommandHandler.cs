using System.Threading;
using System.Threading.Tasks;
using Assignment.Contracts.Data;
using Assignment.Core.Exceptions;
using MediatR;

namespace Assignment.Providers.Handlers.Commands
{
    public class UpdateSlotBlockCommandHandler : IRequestHandler<UpdateSlotBlockCommand, string>
    {
        private readonly IUnitOfWork _unitOfWork;

        public UpdateSlotBlockCommandHandler(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<string> Handle(
            UpdateSlotBlockCommand request,
            CancellationToken cancellationToken
        )
        {
            var slot = await Task.FromResult(_unitOfWork.SlotDetails.Get(request.SlotId));
            if (slot == null)
                throw new NotFoundException("Slot not found.");

            slot.Status = "Blocked";
            _unitOfWork.SlotDetails.Update(slot);
            await _unitOfWork.CommitAsync();

            return slot.Status;
        }
    }
}
