using System.Net;
using Assignment.Contracts.Data;
using Assignment.Contracts.Data.Repositories;
using Assignment.Contracts.DTO;
using MediatR;

namespace Assignment.Providers.Handlers.Commands
{
    public class ScheduleMeetCommand : IRequest<HttpStatusCode>
    {
        public MeetDetailsDTO Model { get; }

        public ScheduleMeetCommand(MeetDetailsDTO model)
        {
            this.Model = model;
        }
    }

    public class ScheduleMeetCommandHandler : IRequestHandler<ScheduleMeetCommand, HttpStatusCode>
    {
        private readonly ITARecruiterRepository _recruiter;

        public ScheduleMeetCommandHandler(ITARecruiterRepository recruiter)
        {
            _recruiter = recruiter;
        }

        public async Task<HttpStatusCode> Handle(
            ScheduleMeetCommand request,
            CancellationToken cancellationToken
        )
        {
            await _recruiter.SendMail(request.Model);
            await _recruiter.UpdateSlot(request.Model.SlotId);

            return HttpStatusCode.OK;
        }
    }
}
