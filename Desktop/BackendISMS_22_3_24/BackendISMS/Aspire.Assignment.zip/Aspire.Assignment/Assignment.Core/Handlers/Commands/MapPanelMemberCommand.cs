using Assignment.Contracts.Data;
using Assignment.Contracts.Data.Entities;
using Assignment.Core.Exceptions;
using MediatR;

namespace Assignment.Providers.Handlers.Commands
{
    public class MapPanelMemberCommand : IRequest<Guid>
    {
        public string Username { get; }

        public MapPanelMemberCommand(string username)
        {
            Username = username;
        }
    }
}