using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Assignment.Contracts.Data;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.DTO;
using Assignment.Core.Exceptions;
using FluentValidation;
using MediatR;

namespace Assignment.Providers.Handlers.Commands
{
    public class SlotDetailsCommand : IRequest<string>
    {
        public SlotDetailsDTO Model { get; }

        public string loggedInUser { get; }

        public SlotDetailsCommand(SlotDetailsDTO model, string _loggedInUser)
        {
            Model = model;
            loggedInUser = _loggedInUser;
        }
    }
}
