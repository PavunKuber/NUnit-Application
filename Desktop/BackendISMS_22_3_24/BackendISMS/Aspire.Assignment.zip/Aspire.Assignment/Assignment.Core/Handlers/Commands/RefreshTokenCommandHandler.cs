using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Assignment.Contracts.Data;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.Data.Repositories;
using Assignment.Contracts.DTO;
using Assignment.Core.Exceptions;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace Assignment.Providers.Handlers.Commands
{
    public class RefreshTokenCommand : IRequest<TokenResponseDTO>
    {
        public string RefreshToken { get; }

        public RefreshTokenCommand(string refreshToken)
        {
            RefreshToken = refreshToken;
        }
    }

    public class RefreshTokenCommandHandler : IRequestHandler<RefreshTokenCommand, TokenResponseDTO>
{
    private readonly IConfiguration _configuration;
    private readonly IRefreshTokenRepository _refreshTokenRepository;
    private readonly IUnitOfWork _repository;

    public RefreshTokenCommandHandler(IConfiguration configuration,IUnitOfWork repository, IRefreshTokenRepository refreshTokenRepository)
    {
        _configuration = configuration;
        _refreshTokenRepository = refreshTokenRepository;
        _repository = repository ;
    }

    public async Task<TokenResponseDTO> Handle(RefreshTokenCommand request, CancellationToken cancellationToken)
{
    // Retrieve the refresh token by token string
    var refreshToken = await _refreshTokenRepository.GetByTokenAsync(request.RefreshToken);
    
    // Check if the refresh token exists and is not expired
    if (refreshToken == null || refreshToken.ExpiresAt <= DateTime.UtcNow)
    {
        throw new UnauthorizedAccessException("Invalid refresh token");
    }

    // Check if the refresh token has been revoked
    if (refreshToken.IsRevoked)
    {
        throw new UnauthorizedAccessException("Refresh token has been revoked");
    }

    // Generate a new access token
    var tokenHandler = new JwtSecurityTokenHandler();
    var key = Encoding.ASCII.GetBytes(_configuration.GetValue<string>("Authentication:Jwt:Secret"));
    var tokenDescriptor = new SecurityTokenDescriptor
    {
        Subject = new ClaimsIdentity(new[] { new Claim("userId", refreshToken.UserId.ToString()) }),
        Expires = DateTime.UtcNow.AddMinutes(15),
        SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
    };
    var token = tokenHandler.CreateToken(tokenDescriptor);
    var accessToken = tokenHandler.WriteToken(token);

    // Generate a new refresh token
    var newRefreshToken = GenerateRefreshToken();

    // Update the existing refresh token with the new token and expiration time
    refreshToken.Token = newRefreshToken;
    refreshToken.ExpiresAt = DateTime.UtcNow.AddMinutes(15);
    await _refreshTokenRepository.UpdateAsync(refreshToken);

    // Save changes to the database
    await _repository.SaveChangesAsync();

    // Return the new access token and refresh token details
    return new TokenResponseDTO
    {
        AccessToken = accessToken,
        AccessTokenExpiration = tokenDescriptor.Expires ?? DateTime.UtcNow.AddMinutes(15),
        RefreshToken = newRefreshToken,
        RefreshTokenExpiration = refreshToken.ExpiresAt
    };
}


    private string GenerateRefreshToken()
    {
        var randomNumber = new byte[32];
        using (var rng = RandomNumberGenerator.Create())
        {
            rng.GetBytes(randomNumber);
            return Convert.ToBase64String(randomNumber);
        }
    }
}


       
    }

