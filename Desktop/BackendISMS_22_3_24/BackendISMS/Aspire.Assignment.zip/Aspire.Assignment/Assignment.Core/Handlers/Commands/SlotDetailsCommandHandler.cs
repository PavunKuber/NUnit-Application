using Assignment.Contracts.Data;
using Assignment.Contracts.Data.Entities;
using Assignment.Core.Exceptions;
using FluentValidation;
using MediatR;

namespace Assignment.Providers.Handlers.Commands
{
    public class SlotDetailsCommandHandler : IRequestHandler<SlotDetailsCommand, string>
    {
        private readonly IUnitOfWork _repository;
        private readonly IValidator<SlotDetailsDTO> _validator;

        public SlotDetailsCommandHandler( IUnitOfWork repository, IValidator<SlotDetailsDTO> validator
        )
        {
            _repository = repository;
            _validator = validator;
        }

        public async Task<string> Handle(SlotDetailsCommand request,CancellationToken cancellationToken
        )
        {
            SlotDetailsDTO model = request.Model;

            var result = _validator.Validate(model);

            if (!result.IsValid)
            {
                var errors = result.Errors.Select(x => x.ErrorMessage).ToArray();
                throw new InvalidRequestBodyException("Invalid request body");
            }

            var users = await Task.FromResult(
                _repository.Users.GetAll().FirstOrDefault(u => u.Name == request.loggedInUser)
            );

            var allocateDate = await Task.FromResult(
                _repository.AllocateDate.GetAll().Where(u => u.Email == users.Email).ToList()
            );

            if (allocateDate.Count == 0)
            {
                throw new EntityNotFoundException("No allocation dates found for the user.");
            }

            // Check if the entered date falls within any allocation date range
            var validDate = allocateDate.Any(ad =>model.Date >= ad.StartDate && model.Date <= ad.EndDate );

            var existingSlot = await _repository.SlotDetails.FirstOrDefaultAsync(u =>
                u.StartTime == model.StartTime
                && u.Date == model.Date
                && u.userName == request.loggedInUser
            );

            if (existingSlot != null)
            {
                throw new DuplicateUserException(
                    $"User with the same Time {model.StartTime}and date {model.Date} already exists."
                );
            }

            var entity = new SlotDetails
            {
                userName = request.loggedInUser,
                Date = model.Date,
                StartTime = model.StartTime,
                EndTime = model.StartTime.Add(TimeSpan.FromHours(1)),
                Status = "Available",
                Remarks = "Remarks"
            };

            _repository.SlotDetails.Add(entity);
            await _repository.CommitAsync();

            return entity.userName;
        }
    }
}
