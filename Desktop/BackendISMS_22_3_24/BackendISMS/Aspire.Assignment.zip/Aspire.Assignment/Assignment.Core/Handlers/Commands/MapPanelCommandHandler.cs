using Assignment.Contracts.Data;
using Assignment.Contracts.Data.Entities;
using Assignment.Core.Exceptions;
using MediatR;

namespace Assignment.Providers.Handlers.Commands
{
    public class MapPanelMemberCommandHandler : IRequestHandler<MapPanelMemberCommand, Guid>
    {
        private readonly IUnitOfWork _repository;

        public MapPanelMemberCommandHandler(IUnitOfWork repository)
        {
            _repository = repository;
        }

        public async Task<Guid> Handle(
            MapPanelMemberCommand request,
            CancellationToken cancellationToken
        )
        {
            var userDetails =
                await Task.FromResult(
                    _repository.Users.GetAll().FirstOrDefault(req => req.Name == request.Username)
                )
                ?? throw new EntityNotFoundException(
                    $"User with username '{request.Username}' not found."
                );

            Guid managerId = await Task.FromResult(
                _repository.Users.GetManagerId(request.Username)
            );

            var managerDetails = await Task.FromResult(_repository.Users.Get(managerId));

            var roleDetails = await Task.FromResult(
                _repository.Roles.GetAll().FirstOrDefault(role => role.RoleName == "Panel Member")
            );

            var existingUserRole = await _repository.UserRoles.GetUserRoleByUserIdAndRoleId(
                userDetails.UserId,
                roleDetails.RoleId
            );

            var existingManager = await _repository.UserRoles.GetUserRoleByUserIdAndRoleId(
                managerId,
                roleDetails.RoleId
            );

            if (existingUserRole != null)
            {
                throw new InvalidOperationException(
                    $"User {userDetails.Name} is already mapped to the Panel Member role."
                );
            }

            var userRole = new UserRole
            {
                UserId = userDetails.UserId,
                RoleId = roleDetails.RoleId,
                LastChanges = DateTime.UtcNow,
                LastChangedBy = "Panel Coordinator"
            };

            _repository.UserRoles.Add(userRole);
            await _repository.CommitAsync();

            if (existingManager == null)
            {
                var managerRole = new UserRole
                {
                    UserId = managerDetails.UserId,
                    RoleId = roleDetails.RoleId,
                    LastChanges = DateTime.UtcNow,
                    LastChangedBy = "Panel Coordinator"
                };
                _repository.UserRoles.Add(managerRole);
                await _repository.CommitAsync();
            }

            return userRole.UserRoleId;
        }
    }
}
