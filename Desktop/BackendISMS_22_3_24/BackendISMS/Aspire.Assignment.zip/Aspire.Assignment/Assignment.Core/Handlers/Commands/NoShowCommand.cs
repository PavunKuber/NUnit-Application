// NoShowCommand.cs
using MediatR;
using Assignment.Contracts.Data.Entities;

namespace Assignment.Providers.Handlers.Commands
{
    public class NoShowCommand : IRequest<string>
    {
        public NoShowDTO Model { get; }

        public NoShowCommand(NoShowDTO model)
        {
            Model = model;
        }
    }
}
