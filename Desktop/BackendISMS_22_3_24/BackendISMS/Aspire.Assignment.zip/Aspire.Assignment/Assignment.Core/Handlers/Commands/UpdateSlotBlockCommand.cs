using MediatR;

namespace Assignment.Providers.Handlers.Commands
{
    public class UpdateSlotBlockCommand : IRequest<string>
    {
        public Guid SlotId { get; }

        public UpdateSlotBlockCommand(Guid slotId)
        {
            SlotId = slotId;
        }
    }
}
