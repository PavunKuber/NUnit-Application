// NoShowCommandHandler.cs
using System;
using System.Threading;
using System.Threading.Tasks;
using Assignment.Contracts.Data;
using Assignment.Contracts.Data.Entities;
using Assignment.Core.Exceptions;
using MediatR;

namespace Assignment.Providers.Handlers.Commands
{
    public class NoShowCommandHandler : IRequestHandler<NoShowCommand, string>
    {
        private readonly IUnitOfWork _unitOfWork;

        public NoShowCommandHandler(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<string> Handle(NoShowCommand request, CancellationToken cancellationToken)
        {
            var slotDetails = await Task.FromResult(
                _unitOfWork.SlotDetails.Get(request.Model.SlotId)
            );

            try
            {
                if (slotDetails == null)
                {
                    throw new EntityNotFoundException(
                        $"Slot with ID {request.Model.SlotId} not found."
                    );
                }
                else
                {
                    slotDetails.Status = request.Model.NewStatus;
                    slotDetails.Remarks = request.Model.UpdatedRemarks;

                    _unitOfWork.SlotDetails.Update(slotDetails);
                    await _unitOfWork.CommitAsync();

                    return "Status Updated";
                }
            }
            catch (EntityNotFoundException ex)
            {
                return ex.Message;
            }
            catch (Exception)
            {
                return "An error occurred while updating status.";
            }
        }
    }
}
