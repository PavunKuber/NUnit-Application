using MediatR; // Importing MediatR namespace
using Assignment.Contracts.Data; // Importing Assignment.Contracts.Data namespace
using Assignment.Contracts.Data.Entities; // Importing Assignment.Contracts.Data.Entities namespace
using Assignment.Core.Exceptions; // Importing Assignment.Core.Exceptions namespace
 
// Namespace declaration for the command handler
namespace Assignment.Providers.Handlers.Commands
{
    // Command handler class for creating users
    public class CreateUserRoleCommandHandler : IRequestHandler<CreateUserRoleCommand, object>
    {
        private readonly IUnitOfWork _unitOfWork; // Declaring IUnitOfWork dependency
 
        // Constructor for injecting dependencies
        public CreateUserRoleCommandHandler(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork; // Assigning injected dependency
        }
 
        // Method to handle the command and create a user
        public async Task<object> Handle(CreateUserRoleCommand request, CancellationToken cancellationToken)
        {
            // Retrieving user by email
            var user = await Task.FromResult(_unitOfWork.Users.GetAll().Where(con => con.Name.Equals(request.Model.Username)).FirstOrDefault()) ?? throw new EntityNotFoundException($"User with username '{request.Model.Username}' not found.");
 
            // Retrieving role by name
            var role = await Task.FromResult(_unitOfWork.Roles.GetAll().Where(con => con.RoleName.Equals(request.Model.Rolename)).FirstOrDefault());
 
            var UserRoles = await Task.FromResult(_unitOfWork.UserRoles.GetAll().FirstOrDefault(req => req.UserId == user.UserId && req.RoleId == role.RoleId));
 
            if (UserRoles != null)
            {
                throw new DuplicateUserException($"User: {user.Name} was already mapped to the role: {role.RoleName}");
            }
 
            var UserRole = new UserRole
            {
                UserId = user.UserId,
                RoleId = role.RoleId,
                LastChanges = DateTime.UtcNow,
                LastChangedBy = "Super Admin"
            };
 
            _unitOfWork.UserRoles.Add(UserRole);
            await _unitOfWork.CommitAsync();
 
            Console.WriteLine("REACHED USERROLE!");
 
            return UserRole.UserRoleId;
        }
    }
}