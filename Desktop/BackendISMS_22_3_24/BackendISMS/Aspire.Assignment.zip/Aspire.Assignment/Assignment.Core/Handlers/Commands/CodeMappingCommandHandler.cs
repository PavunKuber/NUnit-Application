using Assignment.Contracts.Data;
using Assignment.Contracts.DTO;
using Assignment.Core.Exceptions;
using FluentValidation;
using MediatR;

namespace Assignment.Providers.Handlers.Commands
{
    public class CodeMappingCommand : IRequest<object>
    {
        public CodeMappingDTO Model { get; }

        public CodeMappingCommand(CodeMappingDTO model)
        {
            this.Model = model;
        }
    }

    public class CodeMappingCommandHandler : IRequestHandler<CodeMappingCommand, object>
    {
        private readonly IUnitOfWork _repository;
        private readonly IValidator<CodeMappingDTO> _validator;

        public CodeMappingCommandHandler(
            IUnitOfWork repository,
            IValidator<CodeMappingDTO> validator
        )
        {
            _repository = repository;
            _validator = validator;
        }

        public async Task<object> Handle(
            CodeMappingCommand request,
            CancellationToken cancellationToken
        )
        {
            CodeMappingDTO model = request.Model;
            var result = _validator.Validate(model);

            if (!result.IsValid)
            {
                var errors = result.Errors.Select(x => x.ErrorMessage).ToArray();
                throw new InvalidRequestBodyException("Invalid request body");
            }

            var data = await _repository.PanelCoordinator.CheckExisiting(model);
            if (data == false)
            {
                throw new Exception(
                    $"{model.Email}-{model.Interviewlevel} level is already existing"
                );
            }
            var username = await _repository.PanelCoordinator.CodeMap(model);
            return username;
        }
    }
}
