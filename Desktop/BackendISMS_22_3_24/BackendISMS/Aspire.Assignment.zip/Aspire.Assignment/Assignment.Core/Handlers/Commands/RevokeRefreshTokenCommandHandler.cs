// RevokeRefreshTokenCommandHandler.cs
using System.Threading;
using System.Threading.Tasks;
using Assignment.Contracts.Data.Repositories;
using MediatR;

namespace Assignment.Providers.Handlers.Commands
{
     public class RevokeRefreshTokenCommand : IRequest
    {
        public string Token { get; }

        public RevokeRefreshTokenCommand(string token)
        {
            Token = token;
        }
    }
    public class RevokeRefreshTokenCommandHandler : IRequestHandler<RevokeRefreshTokenCommand>
    {
        private readonly IRefreshTokenRepository _refreshTokenRepository;

        public RevokeRefreshTokenCommandHandler(IRefreshTokenRepository refreshTokenRepository)
        {
            _refreshTokenRepository = refreshTokenRepository;
        }

        public async Task<Unit> Handle(RevokeRefreshTokenCommand request, CancellationToken cancellationToken)
        {
            await _refreshTokenRepository.RevokeRefreshTokenAsync(request.Token);
            return Unit.Value;
        }
    }
}
