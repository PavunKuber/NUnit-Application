using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.DTO;
// Importing the Assignment.Contracts.Data.Entities namespace which contains the definition of the entities.

using MediatR;

// Importing the MediatR namespace which provides interfaces and classes for implementing the mediator pattern.

namespace Assignment.Providers.Handlers.Commands
{
    public class CreateUserRoleCommand : IRequest<object>
    {
        public UserRoleDTO Model { get; }

        public CreateUserRoleCommand(UserRoleDTO model)
        {
            Model = model;
        }
    }
}
