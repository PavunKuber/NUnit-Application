using MediatR;

namespace Assignment.Providers.Handlers.Commands
{
    public class UpdateSlotAvailabilityCommand : IRequest<Guid>
    {
        public Guid SlotId { get; }

        public UpdateSlotAvailabilityCommand(Guid slotId)
        {
            SlotId = slotId;
        }
    }
}
