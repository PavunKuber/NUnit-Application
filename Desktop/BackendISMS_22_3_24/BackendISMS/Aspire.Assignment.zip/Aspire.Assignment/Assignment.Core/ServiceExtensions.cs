﻿using Assignment.Contracts.Data; // Importing Assignment.Contracts.Data namespace
using FluentValidation; // Importing FluentValidation namespace
using MediatR; // Importing MediatR namespace
using Microsoft.Extensions.DependencyInjection; // Importing Microsoft.Extensions.DependencyInjection namespace
using System.Reflection; // Importing System.Reflection namespace

namespace Assignment.Core
{
    // Static class to add core services
    public static class ServiceExtensions
    {
        // Method to add core services to the service collection
        public static IServiceCollection AddCore(this IServiceCollection services)
        {
            // Add validators from the executing assembly
            return services.AddValidatorsFromAssembly(Assembly.GetExecutingAssembly())
                // Add AutoMapper profiles from the executing assembly
                .AddAutoMapper(Assembly.GetExecutingAssembly())
                // Add MediatR handlers and related services from the executing assembly
                .AddMediatR(Assembly.GetExecutingAssembly());
                
        }
    }
}
