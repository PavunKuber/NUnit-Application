﻿using AutoMapper; // Importing AutoMapper namespace
using Assignment.Contracts.Data.Entities; // Importing Assignment.Contracts.Data.Entities namespace
using Assignment.Contracts.DTO; // Importing Assignment.Contracts.DTO namespace
using Assignment.Providers.Handlers.Commands; // Importing Assignment.Providers.Handlers.Commands namespace

namespace Assignment.Core.Mapper
{
    // AutoMapper profile for mapping between entities and DTOs
    public class AutoMapperProfile : Profile
    {
        // Constructor to configure mappings
        public AutoMapperProfile()
        {
            // Mapping from App entity to AppDTO
          //  CreateMap<App, AppDTO>();

            // Mapping from User entity to UserDTO
           // CreateMap<User, UserDTO>();
            CreateMap<User, UsersDTO>()
                .ForMember(dest => dest.UserId, opt => opt.MapFrom(src => src.Id)); // Assuming User entity has an Id property
            // Add other mappings as necessary
            CreateMap<Roles, RolesDTO>(); 


            // Mapping from Users entity to UsersDTO
            CreateMap<Users, UserRoleDTO>();

             // Mapping from CodeMaster entity to CodeMasterDTO
            CreateMap<CodeMaster, CodeMasterDTO>();
           
            CreateMap<UsersDetail, UsersDetailDTO>();
           CreateMap<LevelMaster, LevelMasterDTO>();
            CreateMap<SlotDetails,SlotDetailsDTO>();
            CreateMap<SlotDetails,ViewSlotDTO>();
             CreateMap<RefreshToken,RefreshTokenDTO>();
               CreateMap<SlotDetails,TAViewSlotDTO>();


            // Mapping from CreateUsersCommand to Users entity
            CreateMap<CreateUserRoleCommand, Users>()
                .ForMember(dest => dest.UserId, opt => opt.MapFrom(src => Guid.NewGuid())); // Setting UserId using Guid.NewGuid()
        }
    }
}
