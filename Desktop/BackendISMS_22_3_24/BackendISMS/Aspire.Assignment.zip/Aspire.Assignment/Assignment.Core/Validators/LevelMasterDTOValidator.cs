using FluentValidation;

namespace Assignment.Contracts.Data.Entities
{
    public class LevelMasterDTOValidator : AbstractValidator<LevelMasterDTO>
    {
        public LevelMasterDTOValidator()
        {
            RuleFor(x => x.ILevel).NotEmpty().WithMessage("ILevel is required");
        }
    }
}
