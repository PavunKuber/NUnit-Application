using Assignment.Contracts.DTO;
using FluentValidation;
 
namespace Assignment.Core.Validators
{
    public class CodeMappingDTOValidator:AbstractValidator<CodeMappingDTO>
    {
        public CodeMappingDTOValidator()
        {
            RuleFor(x=>x.Codelevel).NotEmpty().WithMessage("Codelevel is required");
            RuleFor(x=>x.Interviewlevel).NotEmpty().WithMessage("Interview level is required");
            RuleFor(x=>x.Email).NotEmpty().WithMessage("Email is required")
            .Matches(@"^([a-zA-Z0-9._%-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})$").WithMessage("Invalid Email address");
        }
    }
}