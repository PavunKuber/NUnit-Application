using FluentValidation;

namespace Assignment.Contracts.DTO
{
    public class BaseResponseDTOValidator : AbstractValidator<BaseResponseDTO>
    {
        public BaseResponseDTOValidator()
        {
            RuleFor(x => x.IsSuccess).NotNull().WithMessage("IsSuccess cannot be null");
            RuleFor(x => x.Errors).NotNull().WithMessage("Errors array cannot be null");
            RuleFor(x => x.Data).NotNull().WithMessage("Data cannot be null");
        }
    }
}
