using Assignment.Contracts.Data.Entities;
using FluentValidation;
using System;

namespace Assignment.Contracts.DTO
{
    public class SlotDetailsDTOValidator : AbstractValidator<SlotDetailsDTO>
    {
        public SlotDetailsDTOValidator()
        {
            RuleFor(x => x.Date).NotEmpty().WithMessage("Date is required");
            RuleFor(x => x.StartTime).NotEmpty().WithMessage("StartTime is required");
        }
    }
}
