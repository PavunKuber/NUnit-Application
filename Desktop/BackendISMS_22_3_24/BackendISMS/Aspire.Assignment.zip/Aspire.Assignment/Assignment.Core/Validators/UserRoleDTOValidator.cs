using FluentValidation;

namespace Assignment.Contracts.DTO
{
    public class UserRoleDTOValidator : AbstractValidator<UserRoleDTO>
    {
        public UserRoleDTOValidator()
        {
            RuleFor(x => x.Username).NotEmpty().WithMessage("Username is required");
            RuleFor(x => x.Rolename).NotEmpty().WithMessage("Role name is required");
        }
    }
}
