using FluentValidation;

namespace Assignment.Contracts.Data.Entities
{
    public class NoShowDTOValidator : AbstractValidator<NoShowDTO>
    {
        public NoShowDTOValidator()
        {
            RuleFor(x => x.SlotId).NotEmpty().WithMessage("SlotId is required");
            RuleFor(x => x.NewStatus).NotEmpty().WithMessage("NewStatus is required");
            RuleFor(x => x.UpdatedRemarks).NotEmpty().WithMessage("UpdatedRemarks is required");
        }
    }
}
