// using Assignment.Contracts.Data.Entities; // Importing Assignment.Contracts.Data.Entities namespace
// using Assignment.Providers.Handlers.Commands; // Importing Assignment.Providers.Handlers.Commands namespace
// using FluentValidation; // Importing FluentValidation namespace
// using System; // Importing System namespace

// namespace Assignment.Core.Validators
// {
//     // Validator class for CreateUsersCommand
//     public class CreateUserRoleCommandValidator : AbstractValidator<CreateUserRoleCommand>
//     {
//         // Constructor to configure validation rules
//         public CreateUserRoleCommandValidator()
//         {
//             // Validation rule for Email property
//             RuleFor(x => x.Email)
//                 .NotEmpty().WithMessage("Email is required") // Email should not be empty
//                 .EmailAddress().WithMessage("Invalid email format"); // Email should be in a valid email format

//             // Validation rule for RoleName property
//             RuleFor(x => x.RoleName)
//                 .NotEmpty().WithMessage("Role name is required"); // RoleName should not be empty

//             // Validation rule for LastChangedBy property
//             RuleFor(x => x.LastChangedBy)
//                 .NotEmpty().WithMessage("Last changed by is required"); // LastChangedBy should not be empty

//             // You can add more validation rules as needed
//         }
//     }
// }
