using FluentValidation;
using System;

namespace Assignment.Contracts.Data.Entities
{
    public class TeamMemberDTOValidator : AbstractValidator<TeamMemberDTO>
    {
        public TeamMemberDTOValidator()
        {
            RuleFor(x => x.Email).NotEmpty().WithMessage("Email is required").EmailAddress().WithMessage("Invalid email format");
            RuleFor(x => x.position).NotEmpty().WithMessage("Position is required");
            RuleFor(x => x.Date).NotEmpty().WithMessage("Date is required");
            RuleFor(x => x.StartTime).NotEmpty().WithMessage("StartTime is required");
            RuleFor(x => x.EndTime).NotEmpty().WithMessage("EndTime is required");
        }
    }
}
