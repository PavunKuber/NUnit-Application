using FluentValidation;

namespace Assignment.Contracts.DTO
{
    public class UsersDetailDTOValidator : AbstractValidator<UsersDetailDTO>
    {
        public UsersDetailDTOValidator()
        {
            RuleFor(x => x.Name).NotEmpty().WithMessage("Name is required");
            RuleFor(x => x.RoleName).NotEmpty().WithMessage("RoleName is required");
            RuleFor(x => x.ReportingManager).NotEmpty().WithMessage("ReportingManager is required");
        }
    }
}
