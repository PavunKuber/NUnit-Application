using FluentValidation;
using System;

namespace Assignment.Contracts.Data.Entities
{
    public class TAViewSlotDTOValidator : AbstractValidator<TAViewSlotDTO>
    {
        public TAViewSlotDTOValidator()
        {
            RuleFor(x => x.SlotId).NotEmpty().WithMessage("SlotId is required");
            RuleFor(x => x.userName).NotEmpty().WithMessage("UserName is required");
            RuleFor(x => x.Date).NotEmpty().WithMessage("Date is required");
            RuleFor(x => x.StartTime).NotEmpty().WithMessage("StartTime is required");
            RuleFor(x => x.EndTime).NotEmpty().WithMessage("EndTime is required");
        }
    }
}
