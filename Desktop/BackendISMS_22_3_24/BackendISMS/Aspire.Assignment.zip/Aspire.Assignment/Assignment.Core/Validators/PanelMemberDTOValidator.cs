using FluentValidation;

namespace Assignment.Contracts.DTO
{
    public class PanelMemberDTOValidator : AbstractValidator<PanelMemberDTO>
    {
        public PanelMemberDTOValidator()
        {
            RuleFor(x => x.Name).NotEmpty().WithMessage("Name is required");
            RuleFor(x => x.Email).NotEmpty().WithMessage("Email is required").EmailAddress().WithMessage("Invalid email format");
            RuleFor(x => x.Designation).NotEmpty().WithMessage("Designation is required");
            RuleFor(x => x.Location).NotEmpty().WithMessage("Location is required");
            RuleFor(x => x.ReportingManager).NotEmpty().WithMessage("ReportingManager is required");
        }
    }
}
