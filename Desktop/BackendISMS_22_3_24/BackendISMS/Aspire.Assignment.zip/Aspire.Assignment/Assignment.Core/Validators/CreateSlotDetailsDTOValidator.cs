using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.DTO;
using FluentValidation;

namespace Assignment.Core.Validators
{
    // public class SlotDetailsDTOValidator : AbstractValidator<SlotDetailsDTO>
    // {
    //     public SlotDetailsDTOValidator()
    //     {

    //         RuleFor(x => x.StartTime).NotEmpty().WithMessage("StartTime is required");




    //     }
    // }
}