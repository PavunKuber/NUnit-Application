using FluentValidation;

namespace Assignment.Contracts.DTO
{
    public class CodeMasterDTOValidator : AbstractValidator<CodeMasterDTO>
    {
        public CodeMasterDTOValidator()
        {
            RuleFor(x => x.CodeName).NotEmpty().WithMessage("CodeName is required");
            RuleFor(x => x.CodeDescription).NotEmpty().WithMessage("CodeDescription is required");
        }
    }
}
