using FluentValidation;
using System;

namespace Assignment.Contracts.DTO
{
    public class TokenResponseDTOValidator : AbstractValidator<TokenResponseDTO>
    {
        public TokenResponseDTOValidator()
        {
            RuleFor(x => x.AccessToken).NotEmpty().WithMessage("AccessToken is required");
            RuleFor(x => x.AccessTokenExpiration).NotEmpty().WithMessage("AccessTokenExpiration is required");
            RuleFor(x => x.RefreshToken).NotEmpty().WithMessage("RefreshToken is required");
            RuleFor(x => x.RefreshTokenExpiration).NotEmpty().WithMessage("RefreshTokenExpiration is required");
            RuleFor(x => x.Username).NotEmpty().WithMessage("Username is required");
        }
    }
}
