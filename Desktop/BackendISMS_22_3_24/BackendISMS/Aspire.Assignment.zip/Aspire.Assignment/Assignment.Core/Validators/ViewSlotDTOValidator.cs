using FluentValidation;
using System;

namespace Assignment.Contracts.Data.Entities
{
    public class ViewSlotDTOValidator : AbstractValidator<ViewSlotDTO>
    {
        public ViewSlotDTOValidator()
        {
            RuleFor(x => x.SlotId).NotEmpty().WithMessage("SlotId is required");
            RuleFor(x => x.Date).NotEmpty().WithMessage("Date is required");
            RuleFor(x => x.StartTime).NotEmpty().WithMessage("StartTime is required");
            RuleFor(x => x.EndTime).NotEmpty().WithMessage("EndTime is required");
            RuleFor(x => x.Position).NotEmpty().WithMessage("Position is required");
            RuleFor(x => x.Status).NotEmpty().WithMessage("Status is required");
            RuleFor(x => x.Remarks).NotEmpty().WithMessage("Remarks is required");
        }
    }
}
