using FluentValidation;
using System;

namespace Assignment.Contracts.DTO
{
    public class RolesDTOValidator : AbstractValidator<RolesDTO>
    {
        public RolesDTOValidator()
        {
            RuleFor(x => x.RoleId).NotEmpty().WithMessage("RoleId is required");
            RuleFor(x => x.RoleName).NotEmpty().WithMessage("RoleName is required");
            RuleFor(x => x.RoleDescription).NotEmpty().WithMessage("RoleDescription is required");
            RuleFor(x => x.LastChangedOn).NotEmpty().WithMessage("LastChangedOn is required");
            RuleFor(x => x.LastChangedBy).NotEmpty().WithMessage("LastChangedBy is required");
        }
    }
}
