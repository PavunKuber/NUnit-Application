using FluentValidation;
using System;

namespace Assignment.Contracts.DTO
{
    public class RefreshTokenDTOValidator : AbstractValidator<RefreshTokenDTO>
    {
        public RefreshTokenDTOValidator()
        {
            RuleFor(x => x.Token).NotEmpty().WithMessage("Token is required");
            RuleFor(x => x.ExpiresAt).NotEmpty().WithMessage("ExpiresAt is required");
            RuleFor(x => x.UserId).NotEmpty().WithMessage("UserId is required").GreaterThan(0).WithMessage("UserId must be greater than 0");
        }
    }
}
