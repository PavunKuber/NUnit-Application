using FluentValidation;
using Assignment.Contracts.DTO;

namespace Assignment.Contracts.DTO.Validators
{
    public class UpdateSlotAvailabilityDTOValidator : AbstractValidator<UpdateSlotAvailabilityDTO>
    {
        public UpdateSlotAvailabilityDTOValidator()
        {
            RuleFor(x => x.SlotId).NotEmpty().WithMessage("SlotId is required");
        }
    }
}
