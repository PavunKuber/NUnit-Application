using FluentValidation;
using System;

namespace Assignment.Contracts.DTO
{
    public class MeetDetailsDTOValidator : AbstractValidator<MeetDetailsDTO>
    {
        public MeetDetailsDTOValidator()
        {
            RuleFor(x => x.SlotId).NotEmpty().WithMessage("SlotId is required");
            RuleFor(x => x.CandidateEmail).NotEmpty().WithMessage("CandidateEmail is required")
                .EmailAddress().WithMessage("Invalid email format");
            RuleFor(x => x.Date).NotEmpty().WithMessage("Date is required")
                .GreaterThanOrEqualTo(DateTime.Today).WithMessage("Date should be today or a future date");
            RuleFor(x => x.StartTime).NotEmpty().WithMessage("StartTime is required");
            RuleFor(x => x.EndTime).NotEmpty().WithMessage("EndTime is required");
        }
    }
}
