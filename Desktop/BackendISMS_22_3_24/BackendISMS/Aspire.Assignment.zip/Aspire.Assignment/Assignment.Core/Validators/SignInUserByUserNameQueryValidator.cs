using Assignment.Providers.Handlers.Queries;
using FluentValidation;
using System;

namespace Assignment.Contracts.DTO
{
    public class SignInUserByUserNameQueryValidator : AbstractValidator<SignInUserByUserNameQuery>
    {
        public SignInUserByUserNameQueryValidator()
        {
            RuleFor(x => x.UserName).NotEmpty().WithMessage("Username is required");
            RuleFor(x => x.PassWord).NotEmpty().WithMessage("Password is required");
        }
    }
}
