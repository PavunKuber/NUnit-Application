using System.Collections.Generic;
using System.Threading.Tasks;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.Data.Repositories;
using Assignment.Migrations;
using Microsoft.EntityFrameworkCore;

namespace Assignment.Core.Data.Repositories
{
    public class LevelMasterRepository : Repository<LevelMaster>, ILevelMasterRepository
    {
        public LevelMasterRepository(DatabaseContext context) : base(context)
        {
            // Constructor
        }

        public async Task<IEnumerable<LevelMaster>> GetAllAsync()
        {
            return await _context.LevelMasters.ToListAsync();
        }
    }
}
