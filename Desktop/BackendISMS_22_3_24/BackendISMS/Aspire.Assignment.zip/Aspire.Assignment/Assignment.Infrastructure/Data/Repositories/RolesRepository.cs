using System.Collections.Generic;
using System.Threading.Tasks;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.Data.Repositories;
using Assignment.Core.Data.Repositories;
using Assignment.Migrations;
using Microsoft.EntityFrameworkCore;

namespace Assignment.Data.Repositories
{
    public class RolesRepository :Repository<Roles>, IRolesRepository
    {
        private readonly DatabaseContext _dbContext;

        public RolesRepository(DatabaseContext dbContext) : base(dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IEnumerable<Roles>> GetAllAsync()
        {
            // Implement your logic here to fetch all roles from the data source (e.g., database)
            // Example:
            // var roles = await _dbContext.Roles.ToListAsync();
            // return roles;

            // For demonstration purposes, let's assume you have a DbSet<Role> property named "Roles" in your DatabaseContext
            return await _dbContext.Roles.ToListAsync();
        }
    }
}
