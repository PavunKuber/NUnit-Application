using System.Threading.Tasks;
using Assignment.Contracts.Data.Entities;
using Assignment.Migrations;
using Microsoft.EntityFrameworkCore;

namespace Assignment.Contracts.Data.Repositories
{
    public class RefreshTokenRepository : IRefreshTokenRepository
    {
        private readonly DatabaseContext _context;

        // Constructor injection of YourDbContext
        public RefreshTokenRepository(DatabaseContext context)
        {
            _context = context;
        }

        // Retrieve a refresh token by user id asynchronously
        public async Task<RefreshToken> GetByUserIdAsync(Guid userId)
        {
            // Use FirstOrDefaultAsync to retrieve the first matching refresh token or null if not found
            return await _context.RefreshToken.FirstOrDefaultAsync(rt => rt.UserId == userId);
        }

        // Add a refresh token asynchronously
        public async Task AddAsync(RefreshToken refreshToken)
        {
            // Add the refresh token to the DbSet
            await _context.RefreshToken.AddAsync(refreshToken);
            // Save changes to the database
            await _context.SaveChangesAsync();
        }

        // Update a refresh token asynchronously
        public async Task UpdateAsync(RefreshToken refreshToken)
        {
            // Update the refresh token entity in the DbSet
            _context.RefreshToken.Update(refreshToken);
            // Save changes to the database
            await _context.SaveChangesAsync();
        }
        
        public async Task<RefreshToken> GetByTokenAsync(string token)
        {
            return await _context.RefreshToken.FirstOrDefaultAsync(rt => rt.Token == token);
        }
         public async Task RevokeRefreshTokenAsync(string token)
        {
            var refreshToken = await _context.RefreshToken.FirstOrDefaultAsync(rt => rt.Token == token);
            if (refreshToken != null)
            {
                refreshToken.IsRevoked = true; // Set IsRevoked to true
                  _context.RefreshToken.Update(refreshToken);
                await _context.SaveChangesAsync();
            }
            // Handle if token is not found
        }

    }
}