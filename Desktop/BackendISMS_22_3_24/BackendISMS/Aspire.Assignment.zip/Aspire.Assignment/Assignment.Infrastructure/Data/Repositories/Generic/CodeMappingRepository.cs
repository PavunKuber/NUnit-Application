using System.Collections.Generic;
using System.Threading.Tasks;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.Data.Repositories;
using Assignment.Migrations;
using Microsoft.EntityFrameworkCore;

namespace Assignment.Core.Data.Repositories
{
    public class CodeMappingRepository : Repository<CodeMapping>, ICodeMappingRepository
    {
        public CodeMappingRepository(DatabaseContext context) : base(context)
        {
            // Constructor
        }
    }
}