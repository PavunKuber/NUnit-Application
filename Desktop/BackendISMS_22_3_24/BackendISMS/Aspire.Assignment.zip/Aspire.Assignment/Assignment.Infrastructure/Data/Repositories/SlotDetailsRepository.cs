using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.Data.Repositories;
using Assignment.Migrations;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Assignment.Core.Data.Repositories
{
    public class SlotDetailsRepository : Repository<SlotDetails>, ISlotDetailsRepository
    {
        private readonly DatabaseContext _context;

        public SlotDetailsRepository(DatabaseContext context) : base(context)
        {
            _context = context;
        }

        public async Task<SlotDetails> FindAsync(string slotId)
        {
            Guid slotGuid;
            if (!Guid.TryParse(slotId, out slotGuid))
            {
                // Handle invalid slotId format
                return null;
            }

            return await _context.SlotDetails.FirstOrDefaultAsync(s => s.SlotId == slotGuid);
        }

        public async Task<SlotDetails> FirstOrDefaultAsync(Expression<Func<SlotDetails, bool>> predicate)
        {
            return await _context.SlotDetails.FirstOrDefaultAsync(predicate);
        }

        public async Task<SlotDetails> FindByUserNameAsync(string userName)
        {
            throw new NotImplementedException(); // Implement according to your logic
        }

        public async Task<IEnumerable<SlotDetails>> GetAllAsync()
        {
            return await _context.SlotDetails.ToListAsync();
        }

    

        public async Task<List<SlotDetails>> GetAllSlotDetailsByUserName(string username)
        {
            return await _context.SlotDetails
                .Where(sd => sd.userName == username)
                .ToListAsync();
        }
    }
}
