using System.Collections.Generic;
using System.Threading.Tasks;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.Data.Repositories;
using Assignment.Migrations;
using Microsoft.EntityFrameworkCore;

namespace Assignment.Core.Data.Repositories
{
    public class CodeMasterRepository : Repository<CodeMaster>, ICodeMasterRepository
    {
        public CodeMasterRepository(DatabaseContext context) : base(context)
        {
            // Constructor
        }

        public async Task<IEnumerable<CodeMaster>> GetAllAsync()
        {
            return await _context.CodeMasters.ToListAsync();
        }


    }
}
