using System.Net;
using System.Net.Mail;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.Data.Repositories;
using Assignment.Contracts.DTO;
using Assignment.Migrations;
using Microsoft.Extensions.Options;

 
namespace Assignment.Core.Data.Repositories
{
    public class TARecruiterRepository : Repository<App>, ITARecruiterRepository
    {
        private readonly EmailConfig _config;
        private readonly DatabaseContext _context;
 
        public TARecruiterRepository(DatabaseContext context,IOptions<EmailConfig> config) : base(context)
        {
            _config=config.Value;
            _context=context;
        }
 
        public async Task SendMail(MeetDetailsDTO meetDetailsDTO)
        {
            try
            {    
                Console.WriteLine("Mail sending in progress");
                var subject=_config.Subject;
                var meetingId=Guid.NewGuid().ToString("N");
                var startimestring=meetDetailsDTO.StartTime;
                var body = $"Hi , your interview is scheduled.\n\nStart time:{meetDetailsDTO.StartTime}\n\nMake sure to join the meeting 10 minutes earlier.\n\n https://teams.microsoft.com/l/meeting?id={meetingId}?subject={WebUtility.UrlEncode(subject)}&starttime={startimestring}\n\nBest of Luck.";
                var senderEmail = new MailAddress(_config.Sender, _config.DisplayName);
                var receiverEmail = new MailAddress(meetDetailsDTO.CandidateEmail);
                var password =  _config.Password;
                var smtp = new SmtpClient
                {
                    Host = _config.Host,
                    Port = _config.Port,
                    EnableSsl = true,
                    DeliveryMethod = SmtpDeliveryMethod.Network,
                    UseDefaultCredentials = false,
                    Credentials = new NetworkCredential(senderEmail.Address, password)
                };
                using (var message = new MailMessage(senderEmail, receiverEmail)
                {
                    Subject = subject,
                    Body = body
                })
                {
                     await smtp.SendMailAsync(message);
                }
                Console.WriteLine("Mail sent successfully");
 
            }
            catch (Exception error)
            {
                Console.WriteLine("Error: "+error.Message);
            }
 
             
       
    }
    public async Task UpdateSlot(object id)
        {
            var slotDetails = _context.SlotDetails.FirstOrDefault(slotid => slotid.SlotId == (Guid)id);
            slotDetails.Status = "Interview Scheduled";
            _context.SlotDetails.Update(slotDetails);
            await _context.SaveChangesAsync();
 
        }
}
}