using System.ComponentModel.DataAnnotations;
using System.Data.Common;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.Data.Repositories;
using Assignment.Contracts.DTO;
using Assignment.Migrations;
using Assignment.Providers.Handlers.Queries;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration.UserSecrets;
using Microsoft.IdentityModel.Tokens;
#nullable disable

namespace Assignment.Core.Data.Repositories
{
    public class ReportingManagerRepository : Repository<TeamMember>, IReportingManagerRepository
    {
        private readonly DatabaseContext _dbcontext;

        public ReportingManagerRepository(DatabaseContext dbcontext)
            : base(dbcontext)
        {
            _dbcontext = dbcontext;
        }

        public async Task<IEnumerable<TeamMemberDTO>> GetTeamMemberAsync(object managerName)
        {
            var teamMembers = await _dbcontext
                .Users.Where(manager => manager.ReportingManager == (string)managerName)
                .ToListAsync();
            var positions = await _dbcontext.CodeMapping.ToListAsync();
            var store = "";
            var teamMemberDTOs = new List<TeamMemberDTO>(); // Initialize list to store TeamMemberDTO objects

            foreach (var member in teamMembers)
            {
                var details = await _dbcontext
                    .SlotDetails.Where(table => table.userName == member.Name)
                    .ToListAsync();
                foreach (var detail in details)
                {
                    if (detail != null)
                    {
                        foreach (var level in positions)
                        {
                            var userChecks = _dbcontext.Users.FirstOrDefault(user =>
                                user.UserId == level.UserId
                            );
                            var codeIdCheck = _dbcontext.CodeMasters.FirstOrDefault(Id =>
                                Id.CodeId == level.CodeId
                            );
                            var levelIdCheck = _dbcontext.LevelMasters.FirstOrDefault(Id =>
                                Id.InterviewId == level.InterviewId
                            );

                            if (userChecks != null)
                            {
                                if (userChecks.UserId == member.UserId)
                                {
                                    store =
                                        codeIdCheck.CodeName + "/" + levelIdCheck.InterviewLevel;
                                    var teamMemberDTO = new TeamMemberDTO
                                    {
                                        Email = member.Email,
                                        position = store,
                                        StartTime = detail.StartTime,
                                        Date = detail.Date,
                                        EndTime = detail.EndTime
                                    };
                                    teamMemberDTOs.Add(teamMemberDTO); // Add TeamMemberDTO to the list
                                }
                            }
                        }
                    }
                }
            }
            return teamMemberDTOs; // Return the list of TeamMemberDTO objects outside the loop
        }
    }
}
