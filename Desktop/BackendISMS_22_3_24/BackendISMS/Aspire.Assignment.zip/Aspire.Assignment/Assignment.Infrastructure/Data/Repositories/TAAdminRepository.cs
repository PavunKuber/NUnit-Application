using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.Data.Repositories;
using Assignment.Contracts.DTO;
using Assignment.Migrations;
using Microsoft.EntityFrameworkCore;

namespace Assignment.Core.Data.Repositories
{
    public class TAAdminRepository : Repository<TAAdmin>, ITAAdminRepository
    {
        private readonly DatabaseContext _dbcontext;

        public TAAdminRepository(DatabaseContext dbcontext) : base(dbcontext)
        {
            _dbcontext = dbcontext;
        }

        public async Task<IEnumerable<TAAdminDTO>> GetSlotDetailsAsync()
        {
        var entities = await _dbcontext.SlotDetails.ToListAsync();
        var positions = await _dbcontext.CodeMapping.ToListAsync();
        var store ="";
        var viewSlotDTOs = new List<TAAdminDTO>();
 
            foreach (var entity in entities)
            {
                var userCheck = _dbcontext.Users.FirstOrDefault(users => users.Name == entity.userName);
               
                if (userCheck != null)
                {
                    foreach(var level in positions )
                    {
                        var userChecks = _dbcontext.Users.FirstOrDefault(user => user.UserId == level.UserId);
                        var codeIdCheck = _dbcontext.CodeMasters.FirstOrDefault(Id => Id.CodeId == level.CodeId);
                        var levelIdCheck = _dbcontext.LevelMasters.FirstOrDefault(Id => Id.InterviewId == level.InterviewId);
                       
                        if(userChecks!=null )
                        {  
                            if(userChecks.UserId == userCheck.UserId)
                            {
                                store = codeIdCheck.CodeName+"/"+levelIdCheck.InterviewLevel;
                                var slotDetailDTOs = new TAAdminDTO
                                {
                                Email = userCheck.Email,
                                position = store,
                                StartTime = entity.StartTime,
                                Date = entity.Date,
                                EndTime = entity.EndTime,
                                userName = entity.userName,
                                SlotId = entity.SlotId,
                                Status = entity.Status,
                                Remarks = entity.Remarks
                                };
                            viewSlotDTOs.Add(slotDetailDTOs);
                            }
                        }
                    }
                }
            }
            return viewSlotDTOs;
        }
    }   
}
