﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.Data.Repositories;
using Assignment.Migrations;

namespace Assignment.Core.Data.Repositories
{
    public class UserRepository : Repository<User>, IUserRepository
    {
        public UserRepository(DatabaseContext context) : base(context)
        {
        }

        public async Task<IEnumerable<object>> GetAllAsync()
        {
            // Implement the logic to retrieve all users asynchronously
            // For example:
            // return await Context.Users.ToListAsync();
            return null; // Placeholder return statement
        }
    }
}
