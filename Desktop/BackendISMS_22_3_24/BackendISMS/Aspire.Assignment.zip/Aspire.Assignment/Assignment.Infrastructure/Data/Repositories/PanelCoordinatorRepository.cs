using Assignment.Contracts.DTO;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.Data.Repositories;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Assignment.Migrations;

namespace Assignment.Core.Data.Repositories
{
    public class PanelCoordinatorRepository : Repository<PanelCoordinator>, IPanelCoordinatorRepository
    {
        private readonly DatabaseContext _context;

        public PanelCoordinatorRepository(DatabaseContext context) : base(context)
        {
            _context = context;
        }

        public async Task<IEnumerable<PanelMemberDTO>> GetUser()
        {
            var users = new List<PanelMemberDTO>();

            var roleId = await _context.Roles.Where(role => role.RoleName == "Panel Member").Select(id => id.RoleId).FirstOrDefaultAsync();

            var userIds = await _context.UserRole.Where(id => id.RoleId == roleId).Select(userId => userId.UserId).ToListAsync();

            if (userIds == null)
            {
                return null;
            }

            foreach (var userId in userIds)
            {
                var user = await _context.Users.Where(id => id.UserId == userId).FirstOrDefaultAsync();

                var panelMemberDTO = new PanelMemberDTO
                {
                    Name = user.Name,
                    Email = user.Email,
                    Designation = user.Designation,
                    Location = user.Location,
                    ReportingManager = user.ReportingManager
                };
                users.Add(panelMemberDTO);
            }

            return users;
        }

        public async Task<bool> CheckExisiting(CodeMappingDTO codeMapping)
        {
            var interviewId = await _context.LevelMasters.Where(level => level.InterviewLevel == codeMapping.Interviewlevel).Select(id => id.InterviewId).FirstOrDefaultAsync();

            var roleId = await _context.Roles.Where(rolename => rolename.RoleName == "Panel Member").Select(roleId => roleId.RoleId).FirstOrDefaultAsync();

            var user = await _context.Users
                .Include(userRole => userRole.UserRoles)
                .Where(user => user.Email == codeMapping.Email)
                .FirstOrDefaultAsync();

            if (user != null)
            {
                var userId = user.UserId;

                var exisitingData = await _context.CodeMapping.Where(id => id.UserId == userId && id.InterviewId == interviewId).FirstOrDefaultAsync();

                return exisitingData == null;
            }

            return false;
        }

        public async Task<object> CodeMap(CodeMappingDTO codeMapping)
        {
            var codeId = await _context.CodeMasters.Where(name => name.CodeName == codeMapping.Codelevel).Select(id => id.CodeId).FirstOrDefaultAsync();
            var interviewId = await _context.LevelMasters.Where(level => level.InterviewLevel == codeMapping.Interviewlevel).Select(id => id.InterviewId).FirstOrDefaultAsync();
            var roleId = await _context.Roles.Where(rolename => rolename.RoleName == "Panel Member").Select(roleId => roleId.RoleId).FirstOrDefaultAsync();

            var user = await _context.Users
                .Include(userRole => userRole.UserRoles)
                .Where(user => user.Email == codeMapping.Email)
                .FirstOrDefaultAsync();

            if (user != null)
            {
                foreach (var role in user.UserRoles)
                {
                    if (role.RoleId == roleId)
                    {
                        await _context.CodeMapping.AddAsync(new CodeMapping()
                        {
                            CodeId = codeId,
                            InterviewId = interviewId,
                            UserId = user.UserId
                        });

                        await _context.SaveChangesAsync();

                        return new { message = $"{codeMapping.Email} is added successfully" };
                    }
                }

                throw new Exception($"{codeMapping.Email} is not matched with panel member");
            }

            return HttpStatusCode.NoContent;
        }

public async Task<bool> CheckStartDateAsync(DateTime newStartDate, string email)
{
    // Retrieve the latest end date for the given email
    DateTime? previousEndDate = await _context.AllocateDate
        .Where(entity => entity.Email == email)
        .OrderByDescending(entity => entity.EndDate)
        .Select(entity => entity.EndDate)
        .FirstOrDefaultAsync();

    // Check if the new start date is after the latest end date or if there are no previous allocations
    bool isStartDateAfterPreviousEndDate = previousEndDate == null || newStartDate > previousEndDate;

    return isStartDateAfterPreviousEndDate;
}

public async Task<bool> AddAllocationAsync(AllocateDate allocation)
{
    try
    {
        // Add the allocation to the database
        _context.AllocateDate.Add(allocation);
        await _context.SaveChangesAsync();
        return true; // Return true if the allocation is added successfully
    }
    catch
    {
        return false; // Return false if an exception occurs while saving changes
    }
}
public async Task<IEnumerable<PanelMemberDTO>> GetUserExceptPanelMember()
        {
            var users = new List<PanelMemberDTO>();
 
            // Get user IDs mapped to the "Panel Member" role
            var panelMemberUserIds = await _context.UserRole
                .Where(ur => ur.Roles.RoleName == "Panel Member")
                .Select(ur => ur.UserId)
                .ToListAsync();
 
            // Get user IDs mapped to any role
            var userRoleUserIds = await _context.UserRole
                .Select(ur => ur.UserId)
                .ToListAsync();
 
            // Get user IDs who are not mapped to the "Panel Member" role
            var nonPanelMemberUserIds = userRoleUserIds.Except(panelMemberUserIds);
 
            // Get user IDs who are not mapped to any role
            var usersWithoutRoles = await _context.Users
                .Where(u => !userRoleUserIds.Contains(u.UserId))
                .Select(u => u.UserId)
                .ToListAsync();
 
            // Merge the two lists of user IDs
            var allNonPanelMemberUserIds = nonPanelMemberUserIds.Concat(usersWithoutRoles);
 
            // Fetch user details for each user ID
            foreach (var userId in allNonPanelMemberUserIds)
            {
                var user = await _context.Users
                    .Where(u => u.UserId == userId)
                    .FirstOrDefaultAsync();
 
                // Adding user details to the list
                if (user != null)
                {
                    var panelMemberDTO = new PanelMemberDTO
                    {
                        Name = user.Name,
                        Email = user.Email,
                        Designation = user.Designation,
                        Location = user.Location,
                        ReportingManager = user.ReportingManager
                    };
                    users.Add(panelMemberDTO);
                }
            }
 
            return users;
 
        }
    }
}
