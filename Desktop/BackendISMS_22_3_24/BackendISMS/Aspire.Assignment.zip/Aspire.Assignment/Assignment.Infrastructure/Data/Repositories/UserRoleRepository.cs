using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.Data.Repositories;
using Assignment.Contracts.DTO;
using Assignment.Migrations;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment.Core.Data.Repositories
{
    public class UserRoleRepository : Repository<UserRole>, IUserRoleRepository
    {
        private readonly DatabaseContext _dbContext;

        public UserRoleRepository(DatabaseContext context) : base(context)
        {
            _dbContext = context;
        }

        public async Task<IEnumerable<Users>> GetAllAsync()
        {
            return await _dbContext.Users.ToListAsync();
        }

        public async Task<Users> GetByIdAsync(Guid userId)
        {
            return await _dbContext.Users.FirstOrDefaultAsync(u => u.UserId == userId);
        }

        public async Task<Users> GetUserByEmailAsync(string email)
        {
            return await _dbContext.Users.FirstOrDefaultAsync(u => u.Email == email);
        }

        public async Task<Roles> GetRoleByNameAsync(string roleName)
        {
            return await _dbContext.Roles.FirstOrDefaultAsync(r => r.RoleName == roleName);
        }

        public async Task AddUserRoleAsync(UserRole userRole)
        {
            _dbContext.UserRole.Add(userRole);
            await _dbContext.SaveChangesAsync();
        }

        public async Task<IEnumerable<UserRole>> GetUserRolesAsync(Guid userId)
        {
            return await _dbContext.UserRole.Where(ur => ur.UserId == userId).ToListAsync();
        }

        public async Task<IEnumerable<UsersDetailDTO>> GetUserRoleAsync()
        {
            var userIds = await _dbContext.UserRole.ToListAsync();
            var userDetailDTOs = new List<UsersDetailDTO>();

            foreach (var userId in userIds)
            {
                var userDetails = await _dbContext.Users.FirstOrDefaultAsync(users => users.UserId == userId.UserId);
                var roleDetails = await _dbContext.Roles.FirstOrDefaultAsync(id => id.RoleId == userId.RoleId);

                if (userDetails != null && roleDetails != null)
                {
                    var userDetailDTO = new UsersDetailDTO
                    {
                        Name = userDetails.Name,
                        ReportingManager = userDetails.ReportingManager,
                        RoleName = roleDetails.RoleName
                    };
                    userDetailDTOs.Add(userDetailDTO);
                }
            }

            return userDetailDTOs;
        }

        public async Task AddRoleAsync(Roles role)
        {
            _dbContext.Roles.Add(role);
            await _dbContext.SaveChangesAsync();
        }

        public async Task SaveChangesAsync()
        {
            await _dbContext.SaveChangesAsync();
        }
    }
}
