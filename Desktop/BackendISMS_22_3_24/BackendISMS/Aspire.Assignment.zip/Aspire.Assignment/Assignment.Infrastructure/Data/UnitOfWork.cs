﻿using System.Threading.Tasks;
using Assignment.Contracts.Data; // Importing Assignment.Contracts.Data namespace
using Assignment.Contracts.Data.Repositories; // Importing Assignment.Contracts.Data.Repositories namespace
using Assignment.Core.Data.Repositories; // Importing Assignment.Core.Data.Repositories namespace
using Assignment.Data.Repositories;
using Assignment.Migrations; // Importing Assignment.Migrations namespace

namespace Assignment.Core.Data
{
    // Unit of Work class responsible for coordinating work between repositories and managing transactions
    public class UnitOfWork : IUnitOfWork
    {
        private readonly DatabaseContext _context; // Database context for accessing data

        // Constructor to initialize the unit of work with a database context
        public UnitOfWork(DatabaseContext context)
        {
            _context = context;
        }

        // Property to access the repository for App entities
        public IAppRepository App => new AppRepository(_context);

        // Property to access the repository for User entities
        public IUserRepository User => new UserRepository(_context);
        public IUsersRepository Users => new UsersRepository(_context);

        public IRolesRepository Roles => new RolesRepository(_context);

        // Property to access the repository for Users entities
        public IUserRoleRepository UserRoles => new UserRoleRepository(_context);

        // Property to access the repository for CodeMaster entities


        // Property to access the repository for Slot entities
        public ISlotDetailsRepository SlotDetails => new SlotDetailsRepository(_context);
        public ILevelMasterRepository LevelMaster => new LevelMasterRepository(_context);

        public IPanelCoordinatorRepository PanelCoordinator => new PanelCoordinatorRepository(_context);

        public IReportingManagerRepository TeamMember => new ReportingManagerRepository(_context);

        public ICodeMasterRepository CodeMaster => new CodeMasterRepository(_context);

        public ICodeMappingRepository CodeMapping => new CodeMappingRepository(_context);

        public IAllocatedateRepository AllocateDate => new AllocatedateRepository(_context);

        // Method to commit changes asynchronously to the database
        public async Task CommitAsync()
        {
            await _context.SaveChangesAsync();
        }

        // Method to save changes asynchronously to the database
        public async Task<int> SaveChangesAsync()
        {
            return await _context.SaveChangesAsync();
        }
    }
}
