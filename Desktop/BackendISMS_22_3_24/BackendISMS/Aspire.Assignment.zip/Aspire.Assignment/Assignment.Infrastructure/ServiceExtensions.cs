﻿using Assignment.Contracts.Data; // Importing Assignment.Contracts.Data namespace
using Assignment.Core.Data; // Importing Assignment.Core.Data namespace
using Assignment.Migrations; // Importing Assignment.Migrations namespace
using Microsoft.Extensions.Configuration; // Importing Microsoft.Extensions.Configuration namespace
using Microsoft.Extensions.DependencyInjection; // Importing Microsoft.Extensions.DependencyInjection namespace
using Microsoft.EntityFrameworkCore; // Importing Microsoft.EntityFrameworkCore namespace
using Microsoft.AspNetCore.Identity; // Importing Microsoft.AspNetCore.Identity namespace
using Assignment.Contracts.Data.Entities; // Importing Assignment.Contracts.Data.Entities namespace
using Assignment.Contracts.Data.Repositories; // Importing Assignment.Contracts.Data.Repositories namespace
using Assignment.Core.Data.Repositories; // Importing Assignment.Core.Data.Repositories namespace
using Assignment.Data.Repositories;
namespace Assignment.Infrastructure
{
    public static class ServiceExtensions
    {
        // Extension method to add UnitOfWork to the service collection
        private static IServiceCollection AddUnitOfWork(this IServiceCollection services)
        {
            return services.AddScoped<IUnitOfWork, UnitOfWork>()
            .AddScoped<ITARecruiterRepository,TARecruiterRepository>(); // Registering UnitOfWork as a scoped service
        }

        // Extension method to add UserRepository to the service collection
        private static IServiceCollection UserRepositoryService(this IServiceCollection services)
        {
            return services.AddScoped<IUserRepository, UserRepository>(); // Registering UserRepository as a scoped service
        }

        // Extension method to add UsersRepository to the service collection
        private static IServiceCollection UsersRepositoryService(this IServiceCollection services)
        {
            return services.AddScoped<IUserRoleRepository, UserRoleRepository>(); // Registering UsersRepository as a scoped service
        }  
        
        private static IServiceCollection CodeMasterRepositoryService(this IServiceCollection services)
        {
            return services.AddScoped<ICodeMasterRepository, CodeMasterRepository>(); // Registering UsersRepository as a scoped service
        }

        private static IServiceCollection RoleRepositoryService(this IServiceCollection services)
        {
            return services.AddScoped<IRolesRepository, RolesRepository>(); // Registering UsersRepository as a scoped service
        }
           
        private static IServiceCollection RefreshtokenRepositoryService(this IServiceCollection services)
        {
            return services.AddScoped<IRefreshTokenRepository, RefreshTokenRepository>(); // Registering UsersRepository as a scoped service
        }

       
          private static IServiceCollection SlotRepositoryService(this IServiceCollection services)
        {
            return services.AddScoped<ISlotDetailsRepository, SlotDetailsRepository>(); // Registering UsersRepository as a scoped service
        }
          private static IServiceCollection LevelMasterRepositoryService(this IServiceCollection services)
        {
            return services.AddScoped<ILevelMasterRepository, LevelMasterRepository>(); // Registering UsersRepository as a scoped service
        }
              private static IServiceCollection PanelCoordinatorRepositoryService(this IServiceCollection services)
        {
            return services.AddScoped<IPanelCoordinatorRepository, PanelCoordinatorRepository>(); // Registering UsersRepository as a scoped service
        } 
          private static IServiceCollection TAAdminRepositoryService(this IServiceCollection services)
        {
            return services.AddScoped<ITAAdminRepository, TAAdminRepository>(); // Registering UsersRepository as a scoped service
        } 

        
        // Extension method to add DatabaseContext to the service collection
        private static IServiceCollection AddDatabaseContext(this IServiceCollection services, IConfiguration configuration)
        {
            // Configuring DatabaseContext with connection string and migrations assembly
            services.AddDbContext<DatabaseContext>(options =>
            {
                options.UseSqlServer(configuration.GetConnectionString("DefaultConnection"), sqlOptions =>
                {
                    sqlOptions.MigrationsAssembly("Assignment.Migrations"); // Specifying the assembly for migrations
                });
            });
 
            return services;
        }

        // Extension method to add all persistence-related services to the service collection
        public static IServiceCollection AddPersistence(this IServiceCollection services, IConfiguration configuration)
        {
            // Adding PasswordHasher<User> as a scoped service
            services.AddScoped<IPasswordHasher<User>, PasswordHasher<User>>();
            services.AddScoped<IPasswordHasher<Users>, PasswordHasher<Users>>();
            services.AddScoped<IUsersRepository, UsersRepository>();


            

            // Adding DatabaseContext, UserRepository, UsersRepository, and UnitOfWork to the service collection
            return services.AddDatabaseContext(configuration)
                           .UsersRepositoryService()
                           .AddUnitOfWork()
                           .CodeMasterRepositoryService()
                           .SlotRepositoryService()
                           .UserRepositoryService()
                           .RoleRepositoryService()
                           .LevelMasterRepositoryService()
                           .PanelCoordinatorRepositoryService()
                           .TAAdminRepositoryService()
                           .RefreshtokenRepositoryService();
        }
    }
}
