﻿using Assignment.Contracts.Data.Repositories;

namespace Assignment.Contracts.Data
{
    
   public interface IUnitOfWork
    {
         IAppRepository App { get; }

       IRolesRepository Roles { get; }

        IUserRepository User { get; }
        IUsersRepository Users{get;}
        IUserRoleRepository UserRoles { get; }
        ICodeMasterRepository CodeMaster { get; }
        ISlotDetailsRepository SlotDetails { get; } // Add ISlotRepository property

         ILevelMasterRepository LevelMaster { get; }

         ICodeMappingRepository CodeMapping { get; }

         IPanelCoordinatorRepository PanelCoordinator{get;}

         IReportingManagerRepository TeamMember{get;}

         IAllocatedateRepository AllocateDate {get;}
        Task CommitAsync();
         Task<int> SaveChangesAsync(); 
    }
}