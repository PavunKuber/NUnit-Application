using Assignment.Contracts.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Assignment.Contracts.Data.Repositories
{
    public interface ISlotDetailsRepository : IRepository<SlotDetails>
    {
        Task<SlotDetails> FindAsync(string slotId);
        Task<SlotDetails> FirstOrDefaultAsync(Expression<Func<SlotDetails, bool>> predicate);
        Task<SlotDetails> FindByUserNameAsync(string userName);
        Task<IEnumerable<SlotDetails>> GetAllAsync();
       // Task<IEnumerable<SlotDetails>> FindByUserNameAsync(string userName);
        Task<List<SlotDetails>> GetAllSlotDetailsByUserName(string userName);
    }
}
