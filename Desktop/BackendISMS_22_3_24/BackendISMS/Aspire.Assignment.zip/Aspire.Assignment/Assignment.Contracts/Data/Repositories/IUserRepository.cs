﻿using Assignment.Contracts.Data.Entities;
// Importing the Assignment.Contracts.Data.Entities namespace which contains the definition of the User entity.

namespace Assignment.Contracts.Data.Repositories
{
    public interface IUserRepository : IRepository<User>
    {
        // IEnumerable<Users> GetAll();
        Task<IEnumerable<object>> GetAllAsync();
    }
    // Declaring an interface named "IUserRepository" which inherits from the IRepository interface with the User entity type parameter.
}
