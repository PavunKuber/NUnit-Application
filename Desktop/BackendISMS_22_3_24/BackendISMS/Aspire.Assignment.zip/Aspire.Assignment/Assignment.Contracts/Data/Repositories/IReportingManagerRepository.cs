using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.DTO;
 
namespace Assignment.Contracts.Data.Repositories
{
    public interface IReportingManagerRepository : IRepository<TeamMember>
    {
        // //after the role based login to check oly their particular team members details is showing
         Task<IEnumerable<TeamMemberDTO>> GetTeamMemberAsync(object managerName);
   
 
    }
 
       
}