using Assignment.Contracts.Data.Entities;

namespace Assignment.Contracts.Data.Repositories
{
    public interface IUsersRepository : IRepository<Users>
    {
        Task<Users> GetUserByUsernameAsync(string username);
    
    }
}