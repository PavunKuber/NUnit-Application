using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.DTO;

namespace Assignment.Contracts.Data.Repositories
{
    public interface ITARecruiterRepository : IRepository<App>
    {
        Task SendMail(MeetDetailsDTO meetDetailsDTO);
        Task UpdateSlot(object id);
    }
}