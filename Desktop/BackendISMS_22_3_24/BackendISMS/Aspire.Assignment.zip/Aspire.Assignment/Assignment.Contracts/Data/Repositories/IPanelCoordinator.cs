using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.DTO;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Assignment.Contracts.Data.Repositories
{
    public interface IPanelCoordinatorRepository : IRepository<PanelCoordinator>
    {
        Task<IEnumerable<PanelMemberDTO>> GetUser();
        Task<object> CodeMap(CodeMappingDTO codeMapping);
        Task<bool> CheckExisiting(CodeMappingDTO codeMapping);
     Task<bool> CheckStartDateAsync(DateTime newStartDate, string email);
    Task<bool> AddAllocationAsync(AllocateDate allocation);
    Task<IEnumerable<PanelMemberDTO>> GetUserExceptPanelMember();
    }
}
