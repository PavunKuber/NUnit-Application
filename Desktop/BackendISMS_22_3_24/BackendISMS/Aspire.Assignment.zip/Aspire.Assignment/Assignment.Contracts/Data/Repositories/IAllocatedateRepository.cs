using System.Collections.Generic;
using System.Threading.Tasks;
using Assignment.Contracts.Data.Entities;

namespace Assignment.Contracts.Data.Repositories
{
    public interface IAllocatedateRepository : IRepository<AllocateDate>
    {
        Task<IEnumerable<AllocateDate>> GetAllAsync();
    }
}
