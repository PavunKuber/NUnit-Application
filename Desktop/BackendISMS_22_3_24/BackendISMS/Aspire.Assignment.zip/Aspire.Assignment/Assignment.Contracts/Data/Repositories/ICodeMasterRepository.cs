using System.Collections.Generic;
using System.Threading.Tasks;
using Assignment.Contracts.Data.Entities;

namespace Assignment.Contracts.Data.Repositories
{
    public interface ICodeMasterRepository : IRepository<CodeMaster>
    {
        Task<IEnumerable<CodeMaster>> GetAllAsync();
    }
}
