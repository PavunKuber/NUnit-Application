using System;
// Importing the System namespace which provides fundamental classes and base classes.

using System.Collections.Generic;
using Assignment.Contracts.Data.Entities;
// Importing the System.Collections.Generic namespace which provides interfaces and classes that define generic collections.

namespace Assignment.Contracts.Data.Repositories{
public interface IRefreshTokenRepository
    {
       Task<RefreshToken> GetByTokenAsync(string token);
        Task AddAsync(RefreshToken refreshToken);
        Task UpdateAsync(RefreshToken refreshToken);
        Task<RefreshToken> GetByUserIdAsync(Guid userid);
        Task RevokeRefreshTokenAsync(string token);
    }
}