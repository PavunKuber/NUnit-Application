using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.DTO;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Assignment.Contracts.Data.Repositories
{
    public interface IUserRoleRepository : IRepository<UserRole>
    {
        Task<IEnumerable<Users>> GetAllAsync();
        Task<Users> GetByIdAsync(Guid userId);
        Task<Users> GetUserByEmailAsync(string email);
        Task<Roles> GetRoleByNameAsync(string roleName);
        Task AddUserRoleAsync(UserRole userRole);
        Task<IEnumerable<UserRole>> GetUserRolesAsync(Guid userId);
        Task<IEnumerable<UsersDetailDTO>> GetUserRoleAsync();
        Task AddRoleAsync(Roles role);
        Task SaveChangesAsync();
    }
}
