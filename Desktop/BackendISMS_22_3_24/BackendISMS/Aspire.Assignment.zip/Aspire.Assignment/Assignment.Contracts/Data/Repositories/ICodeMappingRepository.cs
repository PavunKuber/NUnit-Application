using Assignment.Contracts.Data.Entities;

namespace Assignment.Contracts.Data.Repositories
{
    public interface ICodeMappingRepository : IRepository<CodeMapping>
    {
      
    }
}