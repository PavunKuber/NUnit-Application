using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.DTO;
 
namespace Assignment.Contracts.Data.Repositories
{
    public interface ITAAdminRepository : IRepository<TAAdmin>
    {
        // to view every panel members slot details
        Task<IEnumerable<TAAdminDTO>> GetSlotDetailsAsync();
    }
 
       
}