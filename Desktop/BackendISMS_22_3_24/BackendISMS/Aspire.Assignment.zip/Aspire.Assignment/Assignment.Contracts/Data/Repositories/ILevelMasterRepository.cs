using System.Collections.Generic;
using System.Threading.Tasks;
using Assignment.Contracts.Data.Entities;

namespace Assignment.Contracts.Data.Repositories
{
    public interface ILevelMasterRepository : IRepository<LevelMaster>
    {
        Task<IEnumerable<LevelMaster>> GetAllAsync();
    }
}
