﻿using System;
// Importing the System namespace which provides fundamental classes and base classes.

using System.Collections.Generic;
using Assignment.Contracts.Data.Entities;
// Importing the System.Collections.Generic namespace which provides interfaces and classes that define generic collections.

namespace Assignment.Contracts.Data.Repositories
{
    public interface IRepository<T>
    {
        // Declaring a generic interface named "IRepository" with a type parameter T.
        
        IEnumerable<T> GetAll();
        // Declaring a method named "GetAll" that returns IEnumerable<T>, which represents a collection of all entities of type T.

        T Get(object id);
        // Declaring a method named "Get" that accepts an object id and returns an entity of type T corresponding to the given id.

        void Add(T entity);
        // Declaring a method named "Add" that accepts an entity of type T and adds it to the repository.

        void Update(T entity);
        // Declaring a method named "Update" that accepts an entity of type T and updates it in the repository.

        void Delete(object id);
        // Declaring a method named "Delete" that accepts an object id and deletes the corresponding entity from the repository.

        int Count();
        // Declaring a method named "Count" that returns the total count of entities in the repository.

        public Guid GetManagerId(string name);
        //

        Task<UserRole> GetUserRoleByUserIdAndRoleId(Guid userId, Guid roleId);
        //
    }
}
