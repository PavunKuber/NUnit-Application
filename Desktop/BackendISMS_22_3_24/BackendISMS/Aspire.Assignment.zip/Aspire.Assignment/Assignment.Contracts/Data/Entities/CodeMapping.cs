using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
 
namespace Assignment.Contracts.Data.Entities
{
    public class CodeMapping
    {
        [Key]
        public Guid Id{get; set;}
       
        /// <summary>
        ///
        /// </summary>
       public Guid CodeId{get; set;}
 
       [ForeignKey("CodeId")]
       public CodeMaster CodeMaster{get; set;}
       public Guid InterviewId{get; set;}
 
       [ForeignKey("InterviewId")]
       public LevelMaster LevelMaster{get; set;}
 
       public Guid UserId{get; set;}
       
 
    }
}