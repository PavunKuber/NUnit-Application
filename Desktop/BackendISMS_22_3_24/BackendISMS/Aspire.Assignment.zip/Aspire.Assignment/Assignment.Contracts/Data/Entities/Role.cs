using System;
// Importing the System namespace which provides fundamental classes and base classes.

using System.Collections.Generic;
// Importing the System.Collections.Generic namespace which provides interfaces and classes that define generic collections.

using System.ComponentModel.DataAnnotations;
// Importing the System.ComponentModel.DataAnnotations namespace which provides classes and attributes that are used to define metadata for ASP.NET MVC and Entity Framework data models.

using System.Linq;
// Importing the System.Linq namespace which provides classes and interfaces that support queries that use Language-Integrated Query (LINQ).

using System.Text;
// Importing the System.Text namespace which provides classes that represent ASCII and Unicode character encodings.

using System.Threading.Tasks;
// Importing the System.Threading.Tasks namespace which contains types that simplify the work of writing concurrent and asynchronous code.

namespace Assignment.Contracts.Data.Entities
{
    public class Roles
 
    {
        [Key]
        public Guid RoleId { get; set; }
        public string RoleName { get; set; }
        public string RoleDescription { get; set; }
        public DateTime LastChangedOn { get; set; }
        public string LastChangedBy { get; set; }
        public ICollection<UserRole> UserRoles { get; set; }
    }
}