using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.VisualBasic;
#nullable disable
namespace Assignment.Contracts.Data.Entities{
 
  public class TeamMember
    {
    [Key]
    public int Id { get; set; } // Primary Key
    public string Email{ get; set; }
 
    public string position {get; set;}
    public DateTime Date {get; set;}
   
    public TimeSpan StartTime {get; set;}
 
    public TimeSpan EndTime {get; set;}
 
   
    }
}