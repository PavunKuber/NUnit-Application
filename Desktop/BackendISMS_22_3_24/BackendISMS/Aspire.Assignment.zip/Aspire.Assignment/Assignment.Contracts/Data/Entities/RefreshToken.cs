using System;
// This line imports the System namespace, which contains fundamental classes and base classes that define commonly-used value and reference data types, events and event handlers, interfaces, attributes, and processing exceptions.

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


// This line imports the System.Collections.Generic namespace, which provides interfaces and classes that define generic collections, which allow users to create strongly typed collections that provide better type safety and performance than non-generic strongly typed collections.

using System.Linq;
// This line imports the System.Linq namespace, which provides classes and interfaces that support queries that use Language-Integrated Query (LINQ).

using System.Text;
// This line imports the System.Text namespace, which contains classes that represent ASCII and Unicode character encodings.

using System.Threading.Tasks;
// This line imports the System.Threading.Tasks namespace, which contains types that simplify the work of writing concurrent and asynchronous code.

namespace Assignment.Contracts.Data.Entities
{
      public class RefreshToken
    {
           [Key]
        public int Id { get; set; }

        public string Token { get; set; }

        public DateTime ExpiresAt { get; set; }

        
        public Guid UserId { get; set; }
         public bool IsRevoked { get; set; } // Add this property
        
        [ForeignKey("UserId")]
        public Users Users { get; set; }

    }
}