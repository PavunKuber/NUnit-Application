using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
 
namespace Assignment.Contracts.Data.Entities
{
     
  public class AllocateDate
    {
    [Key]
    public int Id { get; set; } // Primary Key
    public string Email{ get; set; }
 
    public DateTime StartDate {get; set;}
   
    public DateTime EndDate {get; set;}
    }
}