using System;
// Importing the System namespace which provides fundamental classes and base classes.

using System.Collections.Generic;
// Importing the System.Collections.Generic namespace which provides interfaces and classes that define generic collections.

using System.ComponentModel.DataAnnotations;
// Importing the System.ComponentModel.DataAnnotations namespace which provides classes and attributes that are used to define metadata for ASP.NET MVC and Entity Framework data models.

using System.ComponentModel.DataAnnotations.Schema;
// Importing the System.ComponentModel.DataAnnotations.Schema namespace which provides attributes for specifying metadata about the structure of Entity Framework Core model classes and properties.

using System.Linq;
// Importing the System.Linq namespace which provides classes and interfaces that support queries that use Language-Integrated Query (LINQ).

using System.Text;
// Importing the System.Text namespace which provides classes that represent ASCII and Unicode character encodings.

using System.Threading.Tasks;
// Importing the System.Threading.Tasks namespace which contains types that simplify the work of writing concurrent and asynchronous code.

namespace Assignment.Contracts.Data.Entities
{
public class UsersDetail
{
    [Key]
    public Guid Id { get; set; }
    
    public string Name { get; set; }

    public string RoleName { get; set; }

    public string ReportingManager { get; set; }
}
}