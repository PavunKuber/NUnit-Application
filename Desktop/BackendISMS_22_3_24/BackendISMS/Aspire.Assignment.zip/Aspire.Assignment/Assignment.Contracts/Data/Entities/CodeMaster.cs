using System;
// Imports the System namespace which provides fundamental classes and base classes.

using System.Collections.Generic;
// Imports the System.Collections.Generic namespace which provides interfaces and classes that define generic collections.

using System.ComponentModel.DataAnnotations;
// Imports the System.ComponentModel.DataAnnotations namespace which provides classes and attributes that are used to define metadata for ASP.NET MVC and Entity Framework data models.

using System.Linq;
// Imports the System.Linq namespace which provides classes and interfaces that support queries that use Language-Integrated Query (LINQ).

using System.Text;
// Imports the System.Text namespace which provides classes that represent ASCII and Unicode character encodings.

using System.Threading.Tasks;
// Imports the System.Threading.Tasks namespace which contains types that simplify the work of writing concurrent and asynchronous code.

namespace Assignment.Contracts.Data.Entities
{
    public class CodeMaster
    {
        [Key] // Attribute to define this property as the primary key
        public Guid CodeId { get; set; } // Property of type integer representing the primary key

        public string CodeName { get; set; } // Property of type string representing a code name
        public string CodeDescription { get; set; } // Property of type string representing a code description
        public ICollection<CodeMapping> CodeMappings{get; set;}

    }
}
