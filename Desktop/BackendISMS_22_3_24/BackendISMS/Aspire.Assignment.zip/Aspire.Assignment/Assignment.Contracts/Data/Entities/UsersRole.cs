using System;
// Importing the System namespace which provides fundamental classes and base classes.

using System.Collections.Generic;
// Importing the System.Collections.Generic namespace which provides interfaces and classes that define generic collections.

using System.ComponentModel.DataAnnotations;
// Importing the System.ComponentModel.DataAnnotations namespace which provides classes and attributes that are used to define metadata for ASP.NET MVC and Entity Framework data models.

using System.ComponentModel.DataAnnotations.Schema;
// Importing the System.ComponentModel.DataAnnotations.Schema namespace which provides attributes for specifying metadata about the structure of Entity Framework Core model classes and properties.

using System.Linq;
// Importing the System.Linq namespace which provides classes and interfaces that support queries that use Language-Integrated Query (LINQ).

using System.Text;
// Importing the System.Text namespace which provides classes that represent ASCII and Unicode character encodings.

using System.Threading.Tasks;
// Importing the System.Threading.Tasks namespace which contains types that simplify the work of writing concurrent and asynchronous code.

namespace Assignment.Contracts.Data.Entities
{
    public class UserRole
    {
        // Declaring a class named "UserRole".
        
        [Key]
        public Guid UserRoleId { get; set; }
        // Declaring a property named "UserRoleId" of type Guid, which represents the primary key for the UserRole entity. The [Key] attribute specifies that this property is the primary key.
        
        public Guid UserId { get; set; } // Foreign Key
        // Declaring a property named "UserId" of type Guid, which represents the foreign key referencing the Users entity.

        [ForeignKey("UserId")]
        public Users Users { get; set; }
        // Declaring a navigation property named "Users" of type Users, which represents the reference to the Users entity. The [ForeignKey] attribute specifies that this property is a foreign key referencing the Users entity.

        public Guid RoleId { get; set; } // Foreign Key
        // Declaring a property named "RoleId" of type Guid, which represents the foreign key referencing the Roles entity.

        [ForeignKey("RoleId")]
        public Roles Roles { get; set; }
        // Declaring a navigation property named "Roles" of type Roles, which represents the reference to the Roles entity. The [ForeignKey] attribute specifies that this property is a foreign key referencing the Roles entity.

        public DateTime LastChanges { get; set; }
        // Declaring a property named "LastChanges" of type DateTime, which represents the timestamp of the last changes made to the UserRole entity.

        public string LastChangedBy { get; set; }
        // Declaring a property named "LastChangedBy" of type string, which represents the user who last changed the UserRole entity.
    }
}
