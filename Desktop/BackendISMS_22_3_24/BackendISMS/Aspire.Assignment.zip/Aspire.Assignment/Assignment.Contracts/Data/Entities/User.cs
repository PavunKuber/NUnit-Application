﻿using System;
// Importing the System namespace which provides fundamental classes and base classes.

using System.Collections.Generic;
// Importing the System.Collections.Generic namespace which provides interfaces and classes that define generic collections.

using System.Linq;
// Importing the System.Linq namespace which provides classes and interfaces that support queries that use Language-Integrated Query (LINQ).

using System.Text;
// Importing the System.Text namespace which provides classes that represent ASCII and Unicode character encodings.

using System.Threading.Tasks;
// Importing the System.Threading.Tasks namespace which contains types that simplify the work of writing concurrent and asynchronous code.

namespace Assignment.Contracts.Data.Entities
{
    public class User : BaseEntity
    {
        // Declaring a class named "User" that inherits from the class "BaseEntity".
        
        public int Id { get; set; }
        // Declaring a property named "Id" of type integer (int), which represents the unique identifier for a user entity.

        public string Username { get; set; }
        // Declaring a property named "Username" of type string, which represents the username associated with a user entity.

        public string Password { get; set; }
        // Declaring a property named "Password" of type string, which represents the password associated with a user entity.
    }
}
