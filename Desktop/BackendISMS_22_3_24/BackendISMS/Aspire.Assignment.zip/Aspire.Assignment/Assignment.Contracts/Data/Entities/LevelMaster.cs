
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace Assignment.Contracts.Data.Entities
{
    public class LevelMaster{
 
        [Key]
 
        public Guid InterviewId{get;set;}
      //  public string Name { get; set; }
        public string InterviewLevel {get;set; }
        public string InterviewDescription {get;set;}
        public ICollection<CodeMapping> CodeMappings{get; set;}
 
    }
}