using System;
// Importing the System namespace which provides fundamental classes and base classes.

using System.Collections.Generic;
// Importing the System.Collections.Generic namespace which provides interfaces and classes that define generic collections.

using System.ComponentModel.DataAnnotations;
// Importing the System.ComponentModel.DataAnnotations namespace which provides classes and attributes that are used to define metadata for ASP.NET MVC and Entity Framework data models.

using System.Linq;
// Importing the System.Linq namespace which provides classes and interfaces that support queries that use Language-Integrated Query (LINQ).

using System.Text;
// Importing the System.Text namespace which provides classes that represent ASCII and Unicode character encodings.

using System.Threading.Tasks;
// Importing the System.Threading.Tasks namespace which contains types that simplify the work of writing concurrent and asynchronous code.

namespace Assignment.Contracts.Data.Entities
{
    public class Users
    {
    [Key]
    public Guid UserId { get; set; } // Primary Key
    public string Name { get; set; }
    public string Email { get; set; }
    public string Password { get; set; }
 
    public string Designation {get; set; }
 
    public string Location {get; set;}
 
    public string ReportingManager { get; set; }
 
    // Navigation property for many-to-many relationship
    public ICollection<UserRole> UserRoles { get; set; }
    }
}
