using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
 
namespace Assignment.Contracts.Data.Entities
{
    public class NoShowDTO
    {
        public Guid SlotId { get; set; }
        public string NewStatus { get; set; }
        public string UpdatedRemarks { get; set; }
    }
}