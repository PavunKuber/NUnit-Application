namespace Assignment.Contracts.DTO
{
    public class RevokeTokenDTO
    {
        public string Token { get; set; }
    }
}
