using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
 
namespace Assignment.Contracts.Data.Entities
{
    public class TAViewSlotDTO
    {
       
        public Guid SlotId { get; set; }
       
        public string userName { get; set; }
 
        public DateTime Date { get; set; }
 
        public TimeSpan StartTime { get; set; }
        public TimeSpan EndTime {get; set; }
         
           
        public string ?Status { get; set; }
 
        public string ?Remarks { get; set; }  
    }
}