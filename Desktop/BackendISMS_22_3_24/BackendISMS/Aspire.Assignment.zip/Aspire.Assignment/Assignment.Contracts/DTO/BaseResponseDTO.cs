﻿namespace Assignment.Contracts.DTO
{
    public class BaseResponseDTO
    {
        public bool IsSuccess { get; set; }

        public string[] Errors { get; set; }
        public object Data { get; set; } // Add a Data property of type object
    }
}
