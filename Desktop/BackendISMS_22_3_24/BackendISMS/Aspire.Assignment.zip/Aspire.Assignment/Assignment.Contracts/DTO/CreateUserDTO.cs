﻿namespace Assignment.Contracts.DTO
{
    public class CreateUserDTO
    {
        
        // Declaring a property named "Id" of type int, which represents the identifier of the user.

        public string Username { get; set; }
        // Declaring a property named "Username" of type string, which represents the username of the user.

        public string Password { get; set; }
        // Declaring a property named "Password" of type string, which represents the password of the user.
    }
}
