namespace Assignment.Contracts.DTO
{
    public class CodeMasterDTO
    {
        public string CodeName { get; set; }
        // Property representing the code name of the CodeMaster entity.
        
        public string CodeDescription { get; set; }
        // Property representing the code description of the CodeMaster entity.
    }
}
