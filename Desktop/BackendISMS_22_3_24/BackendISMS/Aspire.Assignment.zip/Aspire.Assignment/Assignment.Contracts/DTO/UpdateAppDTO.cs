namespace Assignment.Contracts.DTO
{
    public class UpdateAppDTO
    {
        public string Name { get; set; }
        // Declaring a property named "Name" of type string, which represents the updated name of the application.

        public string Moniker { get; set; }
        // Declaring a property named "Moniker" of type string, which represents the updated moniker of the application.
    }
}
