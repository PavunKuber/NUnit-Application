namespace Assignment.Contracts.DTO
{
    public class MeetDetailsDTO
    {
        public Guid SlotId {get; set;}
        public string CandidateEmail { get; set; }
        public DateTime Date { get; set; }
        public string StartTime { get; set; }
        public string? EndTime{get; set;}
    }
}
