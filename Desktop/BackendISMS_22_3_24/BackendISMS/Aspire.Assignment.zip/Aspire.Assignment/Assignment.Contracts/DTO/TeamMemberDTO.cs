#nullable disable
namespace Assignment.Contracts.Data.Entities{
 
  public class TeamMemberDTO
    {
    public string Email{ get; set; }
 
    public string position {get; set;}
    public DateTime Date {get; set;}
   
    public TimeSpan StartTime {get; set;}
 
    public TimeSpan EndTime {get; set;}
    }
}