using System;
using System.Text.Json.Serialization;

namespace Assignment.Contracts.DTO
{
    public class RefreshTokenDTO
    {
        public string Token { get; set; }
        
        public DateTime ExpiresAt { get; set; }
        
        public int UserId { get; set; }
         public bool IsRevoked { get; set; } // Add this property

    }
}
