using System;
using System.ComponentModel.DataAnnotations;

namespace Assignment.Contracts.Data.Entities
{
    public class LevelMasterDTO
    {
        [Key] // Define a key for the entity
        public int Id { get; set; } // Assuming an integer key, change the type if needed

        public string ILevel { get; set; }
    }
}
