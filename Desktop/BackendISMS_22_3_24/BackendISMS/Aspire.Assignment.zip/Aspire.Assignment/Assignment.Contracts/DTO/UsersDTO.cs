namespace Assignment.Contracts.DTO
{
    public class UsersDTO
    {
        public Guid UserId { get; set; }
        public string Name { get; set; }
        public string Designation { get; set; }
        public string Location { get; set; }
 
        public string Email { get; set; }
        public string ReportingManager  { get; set; }
 
    }

        
    }

