using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.VisualBasic;
#nullable disable
namespace Assignment.Contracts.Data.Entities{
 
  public class TAAdminDTO
    {
       public string Email{ get; set; }
 
    public string position {get; set;}
    public DateTime Date {get; set;}
   
    public TimeSpan StartTime {get; set;}
 
    public TimeSpan EndTime {get; set;}

    public Guid SlotId {get;set;}

    public string Status{get;set;}
    public string Remarks{get;set;}
    public string userName{get;set;}
    }
}