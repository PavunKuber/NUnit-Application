namespace Assignment.Contracts.DTO
{
    public class UsersDetailDTO
    {
        public string Name { get; set; }

        public string RoleName { get; set; }

        public string ReportingManager { get; set; }
    }
}
