namespace Assignment.Contracts.DTO
{
    public class TokenResponseDTO
    {
        public string AccessToken { get; set; }
        public DateTime AccessTokenExpiration { get; set; }
        public string RefreshToken { get; set; }
        public DateTime RefreshTokenExpiration { get; set; }
        // public string TokenType { get; set; }
        // public string Scope { get; set; }
        public string Username { get; set; }
    }
}
