using System;
using System.ComponentModel.DataAnnotations;
// Importing the System namespace which provides fundamental classes and base classes.

namespace Assignment.Contracts.DTO
{
    public class RolesDTO
    {
         [Key]
        public Guid RoleId { get; set; }
        public string RoleName { get; set; }
        public string RoleDescription { get; set; }
        public DateTime LastChangedOn { get; set; }
        public string LastChangedBy { get; set; }
    }
}
