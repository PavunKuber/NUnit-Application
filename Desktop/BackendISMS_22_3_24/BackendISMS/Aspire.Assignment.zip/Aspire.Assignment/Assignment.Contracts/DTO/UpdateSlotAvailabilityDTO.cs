namespace Assignment.Contracts.DTO
{
    public class UpdateSlotAvailabilityDTO
    {
        public Guid SlotId { get; set; }
    }
}
