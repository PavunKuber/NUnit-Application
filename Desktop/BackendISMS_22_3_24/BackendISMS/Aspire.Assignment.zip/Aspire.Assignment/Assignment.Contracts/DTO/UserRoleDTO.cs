namespace Assignment.Contracts.DTO
{
    public class UserRoleDTO
    {
       public string Username { get; set; }
       public string Rolename { get; set; }
    }
}
