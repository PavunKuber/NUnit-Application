﻿namespace Assignment.Contracts.DTO
{
    public class CreateAppDTO
    {
        public string Name { get; set; }
        // Declaring a property named "Name" of type string, which represents the name of the application.

        public string Description { get; set; }
        // Declaring a property named "Description" of type string, which represents the description of the application.

        public string Price { get; set; }
        // Declaring a property named "Price" of type string, which represents the price of the application.

        public string Developer { get; set; }
        // Declaring a property named "Developer" of type string, which represents the developer of the application.

        public string Type { get; set; }
        // Declaring a property named "Type" of type string, which represents the type or category of the application.
    }
}
