namespace Assignment.Contracts.DTO
{
    public class CodeMappingDTO
    {
        public  string Codelevel{get; set;}
        public  string Interviewlevel{get; set;}
        public string Email{get; set;}
    }
}