using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
 
namespace Assignment.Contracts.Data.Entities
{
    public class SlotDetailsDTO
    {
     
     
     public DateTime Date {get; set;}
     public TimeSpan StartTime { get ; set;}
     
 
 
 
   
    }
}