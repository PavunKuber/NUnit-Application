      namespace Assignment.Contracts.DTO
{
    public class PanelMemberDTO
    {
        public string Name{get; set;}
        public string Email{get; set;}
        public string Designation{get; set;}
        public string Location{get; set;}
        public string ReportingManager{get; set;}
    }
 
}