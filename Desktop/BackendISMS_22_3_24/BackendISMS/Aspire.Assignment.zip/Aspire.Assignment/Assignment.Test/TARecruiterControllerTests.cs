using System;
using System.Net;
using System.Threading.Tasks;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.DTO;
using Assignment.Controllers;
using Assignment.Core.Exceptions;
using Assignment.Providers.Handlers.Commands;
using Assignment.Providers.Handlers.Queries;
using AutoMapper.Configuration;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

namespace Assignment.Tests.Controllers
{
    public class TARecruiterControllerTests
    {
[Fact]
public async Task GetallDetails_Returns_InternalServerError_On_Exception()
{
    // Arrange
    var mediatorMock = new Mock<IMediator>();
    var configurationMock = new Mock<Microsoft.Extensions.Configuration.IConfiguration>(); // Mock Microsoft.Extensions.Configuration.IConfiguration

    var controller = new TARecruiterController(mediatorMock.Object, configurationMock.Object);

    // Mock mediator to throw an exception
    mediatorMock.Setup(m => m.Send(It.IsAny<GetAllSlotdetailQuery>(), default))
                .ThrowsAsync(new Exception("Test exception")); // Simulate an exception being thrown

    // Act
    var result = await controller.GetallDetails();

    // Assert
    var statusCodeResult = Assert.IsType<ObjectResult>(result);
    Assert.Equal((int)HttpStatusCode.InternalServerError, statusCodeResult.StatusCode); // Check if status code is 500
}

[Fact]
public async Task GetallDetails_Returns_OK_With_Valid_Response()
{
    // Arrange
    var mediatorMock = new Mock<IMediator>();
    var configurationMock = new Mock<Microsoft.Extensions.Configuration.IConfiguration>();

    var controller = new TARecruiterController(mediatorMock.Object, configurationMock.Object);

    var expectedResponse = new List<MeetDetailsDTO> { new MeetDetailsDTO() };

    // Mock mediator to return valid response
    mediatorMock.Setup(m => m.Send(It.IsAny<GetAllSlotdetailQuery>(), default))
                .ReturnsAsync(expectedResponse.Select(dto => new TAViewSlotDTO()));

    // Act
    var result = await controller.GetallDetails();

    // Assert
    var okResult = Assert.IsType<OkObjectResult>(result);
    var responseData = Assert.IsType<TAViewSlotDTO[]>(okResult.Value); // Change the assertion to match the actual return type
    Assert.Single(responseData); // Ensure only one item is returned
}


        [Fact]
        public async Task ScheduleMeet_Returns_OK_With_Valid_Response()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var controller = new TARecruiterController(mediatorMock.Object, null);
            var meetDetailsDTO = new MeetDetailsDTO();

            // Mock mediator to return OK
            mediatorMock.Setup(m => m.Send(It.IsAny<ScheduleMeetCommand>(), default))
                        .ReturnsAsync(HttpStatusCode.OK);

            // Act
            var result = await controller.ScheduleMeet(meetDetailsDTO);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal((int)HttpStatusCode.OK, okResult.StatusCode);
        }

        [Fact]
        public async Task ScheduleMeet_Returns_BadRequest_On_InvalidMeetDetailsException()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var controller = new TARecruiterController(mediatorMock.Object, null);
            var meetDetailsDTO = new MeetDetailsDTO();

            // Mock mediator to throw InvalidMeetDetailsException
            mediatorMock.Setup(m => m.Send(It.IsAny<ScheduleMeetCommand>(), default))
                        .ThrowsAsync(new InvalidMeetDetailsException("Invalid meet details"));

            // Act
            var result = await controller.ScheduleMeet(meetDetailsDTO);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal((int)HttpStatusCode.BadRequest, badRequestResult.StatusCode);
            Assert.Equal("Invalid meet details", badRequestResult.Value);
        }

        // Add more test cases for other exception scenarios...
    }
}
