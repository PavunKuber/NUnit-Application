using System;
using System.Collections.Generic;
using System.Net;
using System.Security.Claims;
using System.Threading.Tasks;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.DTO;
using Assignment.Controllers;
using Assignment.Providers.Handlers.Queries;
using FluentAssertions;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

namespace Assignment.Tests.Controllers
{
    public class ReportingManagerControllerTests
    {
        [Fact]
        public async Task GetMember_Returns_Ok_With_TeamMembers()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var expectedTeamMembers = new List<TeamMemberDTO>
            {
                new TeamMemberDTO { Email = "member1@example.com", position = "Developer", Date = DateTime.Now.Date, StartTime = TimeSpan.FromHours(9), EndTime = TimeSpan.FromHours(17) },
                new TeamMemberDTO { Email = "member2@example.com", position = "Tester", Date = DateTime.Now.Date, StartTime = TimeSpan.FromHours(9), EndTime = TimeSpan.FromHours(17) }
            };
            mediatorMock.Setup(m => m.Send(It.IsAny<GetTeamMemberQuery>(), default)).ReturnsAsync(expectedTeamMembers);

            var controller = new ReportingManagerController(mediatorMock.Object);
            controller.ControllerContext = new ControllerContext();
            controller.ControllerContext.HttpContext = new DefaultHttpContext
            {
                User = new ClaimsPrincipal(new ClaimsIdentity(new[]
                {
                    new Claim(ClaimTypes.Name, "testuser@example.com")
                }))
            };

            // Act
            var result = await controller.GetMember();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var actualTeamMembers = Assert.IsAssignableFrom<IEnumerable<TeamMemberDTO>>(okResult.Value);
            actualTeamMembers.Should().BeEquivalentTo(expectedTeamMembers);
        }

        [Fact]
        public async Task GetMember_Returns_NotFound_For_NotFoundException()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            mediatorMock.Setup(m => m.Send(It.IsAny<GetTeamMemberQuery>(), default)).ThrowsAsync(new NotFoundException("Team members not found"));

            var controller = new ReportingManagerController(mediatorMock.Object);
            controller.ControllerContext = new ControllerContext();
            controller.ControllerContext.HttpContext = new DefaultHttpContext
            {
                User = new ClaimsPrincipal(new ClaimsIdentity(new[]
                {
                    new Claim(ClaimTypes.Name, "testuser@example.com")
                }))
            };

            // Act
            var result = await controller.GetMember();

            // Assert
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
            var baseResponse = Assert.IsType<BaseResponseDTO>(notFoundResult.Value);
            baseResponse.IsSuccess.Should().BeFalse();
            baseResponse.Errors.Should().ContainSingle().Which.Should().Be("Team members not found");
        }

        [Fact]
        public async Task GetMember_Returns_BadRequest_For_InvalidParameterException()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            mediatorMock.Setup(m => m.Send(It.IsAny<GetTeamMemberQuery>(), default)).ThrowsAsync(new InvalidParameterException("Invalid parameter"));

            var controller = new ReportingManagerController(mediatorMock.Object);
            controller.ControllerContext = new ControllerContext();
            controller.ControllerContext.HttpContext = new DefaultHttpContext
            {
                User = new ClaimsPrincipal(new ClaimsIdentity(new[]
                {
                    new Claim(ClaimTypes.Name, "testuser@example.com")
                }))
            };

            // Act
            var result = await controller.GetMember();

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var baseResponse = Assert.IsType<BaseResponseDTO>(badRequestResult.Value);
            baseResponse.IsSuccess.Should().BeFalse();
            baseResponse.Errors.Should().ContainSingle().Which.Should().Be("Invalid parameter");
        }

        [Fact]
        public async Task GetMember_Returns_Forbidden_For_PermissionDeniedException()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            mediatorMock.Setup(m => m.Send(It.IsAny<GetTeamMemberQuery>(), default)).ThrowsAsync(new PermissionDeniedException("Permission denied"));

            var controller = new ReportingManagerController(mediatorMock.Object);
            controller.ControllerContext = new ControllerContext();
            controller.ControllerContext.HttpContext = new DefaultHttpContext
            {
                User = new ClaimsPrincipal(new ClaimsIdentity(new[]
                {
                    new Claim(ClaimTypes.Name, "testuser@example.com")
                }))
            };

            // Act
            var result = await controller.GetMember();

            // Assert
            var forbiddenResult = Assert.IsType<ObjectResult>(result);
            forbiddenResult.StatusCode.Should().Be((int)HttpStatusCode.Forbidden);
            var baseResponse = Assert.IsType<BaseResponseDTO>(forbiddenResult.Value);
            baseResponse.IsSuccess.Should().BeFalse();
            baseResponse.Errors.Should().ContainSingle().Which.Should().Be("Permission denied");
        }

        [Fact]
        public async Task GetMember_Returns_InternalServerError_For_Exceptions()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            mediatorMock.Setup(m => m.Send(It.IsAny<GetTeamMemberQuery>(), default)).ThrowsAsync(new Exception("Internal server error"));

            var controller = new ReportingManagerController(mediatorMock.Object);
            controller.ControllerContext = new ControllerContext();
            controller.ControllerContext.HttpContext = new DefaultHttpContext
            {
                User = new ClaimsPrincipal(new ClaimsIdentity(new[]
                {
                    new Claim(ClaimTypes.Name, "testuser@example.com")
                }))
            };

            // Act
            var result = await controller.GetMember();

            // Assert
            var internalServerErrorResult = Assert.IsType<ObjectResult>(result);
            internalServerErrorResult.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);
            var baseResponse = Assert.IsType<BaseResponseDTO>(internalServerErrorResult.Value);
            baseResponse.IsSuccess.Should().BeFalse();
            baseResponse.Errors.Should().ContainSingle().Which.Should().Be("Internal server error");
        }
    }
}
