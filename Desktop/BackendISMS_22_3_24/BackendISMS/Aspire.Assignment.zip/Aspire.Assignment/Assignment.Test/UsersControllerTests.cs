using Assignment.Controllers;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.Data.Repositories;
using Assignment.Contracts.DTO;
using Assignment.Providers.Handlers.Queries;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using MediatR;

namespace Assignment.Tests.Controllers
{
    public class UsersControllerTests
    {
        private UsersController _usersController;
        private Mock<IMediator> _mediatorMock;

        public UsersControllerTests()
        {
            _mediatorMock = new Mock<IMediator>();
            _usersController = new UsersController(_mediatorMock.Object, null);
        }

        [Fact]
        public async Task GetAllUsers_Success_ReturnsOk()
        {
            // Arrange
            var users = new List<Users> { new Users { UserId = Guid.NewGuid(), Name = "User1" } };
            _mediatorMock.Setup(m => m.Send(It.IsAny<GetAllUsersQuery>(), default)).ReturnsAsync(users);

            // Act
            var result = await _usersController.GetAllUsers();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal(users, okResult.Value);
        }

        [Fact]
        public async Task GetAllUsers_EmptyList_ReturnsEmpty()
        {
            // Arrange
            var users = new List<Users>();
            _mediatorMock.Setup(m => m.Send(It.IsAny<GetAllUsersQuery>(), default)).ReturnsAsync(users);

            // Act
            var result = await _usersController.GetAllUsers();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Empty(okResult.Value as List<Users>);
        }

       [Fact]
public async Task GetAllUsers_Exception_ReturnsInternalServerError()
{
    // Arrange
    _mediatorMock.Setup(m => m.Send(It.IsAny<GetAllUsersQuery>(), default))
        .ThrowsAsync(new NotFoundException("Users not found"));

    // Act
    var result = await _usersController.GetAllUsers();

    // Assert
    var statusCodeResult = Assert.IsType<ObjectResult>(result);
    Assert.Equal(500, statusCodeResult.StatusCode);
    Assert.Equal("Users not found", statusCodeResult.Value);
}

     [Fact]
public async Task GetAllUsers_Unauthorized_ReturnsUnauthorized()
{
    // Arrange
    _mediatorMock.Setup(m => m.Send(It.IsAny<GetAllUsersQuery>(), default))
        .ThrowsAsync(new UnauthorizedAccessException("Unauthorized access"));

    // Act
    var result = await _usersController.GetAllUsers();

    // Assert
    var statusCodeResult = Assert.IsType<ObjectResult>(result);
    Assert.Equal(401, statusCodeResult.StatusCode);
    Assert.Equal("Unauthorized access", statusCodeResult.Value);
}
        [Fact]
        public async Task GetAllUsers_ValidationFailure_ReturnsBadRequest()
        {
            // Arrange
            _mediatorMock.Setup(m => m.Send(It.IsAny<GetAllUsersQuery>(), default))
                .ThrowsAsync(new ValidationException("Validation failed"));

            // Act
            var result = await _usersController.GetAllUsers();

            // Assert
            Assert.IsType<BadRequestObjectResult>(result);
        }
    }
}
