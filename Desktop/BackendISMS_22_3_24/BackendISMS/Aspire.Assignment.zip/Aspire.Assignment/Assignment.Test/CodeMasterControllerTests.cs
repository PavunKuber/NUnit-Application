using Assignment.Controllers;
using Assignment.Contracts.DTO;
using Assignment.Core.Exceptions;
using Assignment.Providers.Handlers.Queries;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Xunit;
using Microsoft.AspNetCore.OData.Query;

namespace Assignment.Tests.Controllers
{
    public class CodeMasterControllerTests
    {
        [Fact]
        public async Task GetCodeMaster_ReturnsOkResult()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var configurationMock = new Mock<Microsoft.Extensions.Configuration.IConfiguration>();
            var controller = new CodeMasterController(mediatorMock.Object, configurationMock.Object);

            var codeMasterList = new List<CodeMasterDTO>
            {
                new CodeMasterDTO { CodeName = "Code1" },
                new CodeMasterDTO { CodeName = "Code2" }
            };

            mediatorMock.Setup(m => m.Send(It.IsAny<GetCodeMasterQuery>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(codeMasterList);

            // Act
            var actionResult = await controller.GetCodeMaster();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(actionResult);
            var codeMaster = Assert.IsAssignableFrom<IEnumerable<CodeMasterDTO>>(okResult.Value);
            Assert.NotEmpty(codeMaster); // Ensure that the result is not empty
        }

        [Fact]
        public async Task GetCodeMaster_EmptyList_ReturnsNotFoundResult()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var configurationMock = new Mock<Microsoft.Extensions.Configuration.IConfiguration>();
            var controller = new CodeMasterController(mediatorMock.Object, configurationMock.Object);

            var expectedCodeMaster = new CodeMasterDTO[] { };
            mediatorMock.Setup(m => m.Send(It.IsAny<GetCodeMasterQuery>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(expectedCodeMaster);

            // Act
            var result = await controller.GetCodeMaster();

            // Assert
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
            Assert.Equal("Code master not found", notFoundResult.Value);
        }

        [Fact]
        public async Task GetCodeMaster_RetrievalFailed_ReturnsNotFoundResult()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var configurationMock = new Mock<Microsoft.Extensions.Configuration.IConfiguration>();
            var controller = new CodeMasterController(mediatorMock.Object, configurationMock.Object);

            mediatorMock.Setup(m => m.Send(It.IsAny<GetCodeMasterQuery>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new RetrievalFailedNotFoundException("Retrieval failed"));

            // Act
            var result = await controller.GetCodeMaster();

            // Assert
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
            Assert.Equal("Retrieval failed", notFoundResult.Value);
        }

        [Fact]
        public async Task GetCodeMaster_OtherExceptions_ReturnsInternalServerError()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var configurationMock = new Mock<Microsoft.Extensions.Configuration.IConfiguration>();
            var controller = new CodeMasterController(mediatorMock.Object, configurationMock.Object);

            mediatorMock.Setup(m => m.Send(It.IsAny<GetCodeMasterQuery>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new Exception("Unknown error"));

            // Act
            var result = await controller.GetCodeMaster();

            // Assert
            var statusCodeResult = Assert.IsType<ObjectResult>(result);
            Assert.Equal((int)HttpStatusCode.InternalServerError, statusCodeResult.StatusCode);
        }
    }
}
