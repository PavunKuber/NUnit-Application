// // SlotDetailsControllerTests.cs
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Assignment.Controllers;
using Assignment.Contracts.DTO;
using Assignment.Core.Exceptions;
using Assignment.Providers.Handlers.Commands;
using Assignment.Providers.Handlers.Queries;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;
using Assignment.Contracts.Data.Entities;
using Microsoft.AspNetCore.Http;
using System.Security.Claims;
using Assignment.Contracts.Data;
using Assignment.Contracts.Data.Repositories;
using Newtonsoft.Json;

namespace Assignment.Tests.Controllers
{
    public class SlotDetailsControllerTests
    {
//     [Fact]
//         public async Task AddSlotDetails_Returns_Created_When_SlotDetails_Added_Successfully()
//         {
//             // Arrange
//             var mediatorMock = new Mock<IMediator>();
//             var controller = new SlotDetailsController(mediatorMock.Object);

//             // Mock HttpContext to provide authentication information
//             var httpContext = new DefaultHttpContext();
//             httpContext.User = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
//             {
//                 new Claim(ClaimTypes.Name, "testuser") // Provide authenticated user name here
//             }));
//             controller.ControllerContext = new ControllerContext
//             {
//                 HttpContext = httpContext
//             };

//             var model = new List<SlotDetailsDTO>
//             {
//                 // Add slot details DTO objects here as needed for the test case
//             };

//             // Mock the mediator to return a successful response
//             mediatorMock.Setup(m => m.Send(It.IsAny<SlotDetailsCommand>(), default)).ReturnsAsync("success");

//             // Act
//             var result = await controller.AddSlotDetails(model);

//            // Assert
// var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
// var baseResponse = Assert.IsType<BaseResponseDTO>(badRequestResult.Value);
// Assert.False(baseResponse.IsSuccess);
// Assert.NotNull(baseResponse.Errors);
// Assert.Single(baseResponse.Errors);
// Assert.Equal("No data provided.", baseResponse.Errors[0]);

//         }




// [Fact]
// public async Task AddSlotDetails_Returns_BadRequest_When_Model_Is_Null()
// {
//     // Arrange
//     var mediatorMock = new Mock<IMediator>();
//     var controller = new SlotDetailsController(mediatorMock.Object);

//     // Act
//     var result = await controller.AddSlotDetails(null);

//     // Assert
//     var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
//     var response = Assert.IsType<string>(badRequestResult.Value);
//     Assert.Equal("No data provided.", response);
// }




        [Fact]
public async Task ViewSlot_Returns_OkResult_With_Slots()
{
    // Arrange
    var mediatorMock = new Mock<IMediator>();
    var controller = new SlotDetailsController(mediatorMock.Object);
    var loggedInUser = "testuser"; // Simulate authenticated user
    controller.ControllerContext = new ControllerContext
    {
        HttpContext = new DefaultHttpContext
        {
            User = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
            {
                new Claim(ClaimTypes.Name, loggedInUser)
            }))
        }
    };
    var expectedSlots = new List<ViewSlotDTO>
    {
        // Add expected slots here
    };
    mediatorMock.Setup(m => m.Send(It.IsAny<SlotViewQuery>(), default)).ReturnsAsync(expectedSlots);

    // Act
    var result = await controller.ViewSlot();

    // Assert
    var okResult = Assert.IsType<OkObjectResult>(result);
    var actualSlots = Assert.IsAssignableFrom<List<ViewSlotDTO>>(okResult.Value);
    Assert.Equal(expectedSlots.Count, actualSlots.Count);
    // Additional assertions for comparing expected and actual slots
}
[Fact]
public async Task ViewSlot_Returns_BadRequest_When_User_Not_Authenticated()
{
    // Arrange
    var mediatorMock = new Mock<IMediator>();
    var controller = new SlotDetailsController(mediatorMock.Object);
    controller.ControllerContext = new ControllerContext
    {
        HttpContext = new DefaultHttpContext() // No authentication provided
    };

    // Act
    var result = await controller.ViewSlot();

    // Assert
    var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
    var baseResponse = Assert.IsType<BaseResponseDTO>(badRequestResult.Value);
    Assert.False(baseResponse.IsSuccess);
    Assert.NotNull(baseResponse.Errors);
    Assert.Single(baseResponse.Errors);
    Assert.Equal("User not authenticated.", baseResponse.Errors[0]);
}
  
        [Fact]
        public async Task UpdateSlotAvailability_Returns_InternalServerError_On_Exception()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var controller = new SlotDetailsController(mediatorMock.Object);
            var slotIds = new List<Guid> { Guid.NewGuid(), Guid.NewGuid() };

            // Mock mediator to throw exception
            mediatorMock.Setup(m => m.Send(It.IsAny<UpdateSlotAvailabilityCommand>(), default))
                        .ThrowsAsync(new Exception("Internal Server Error"));

            // Act
            var result = await controller.UpdateSlotAvailability(slotIds);

            // Assert
            var statusCodeResult = Assert.IsType<StatusCodeResult>(result);
            Assert.Equal((int)HttpStatusCode.InternalServerError, statusCodeResult.StatusCode);
        }

      [Fact]
        public async Task UpdateSlotBlock_Returns_OK_For_Valid_SlotId()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var controller = new SlotDetailsController(mediatorMock.Object);
            var slotId = Guid.NewGuid();
            var expectedResult = "Blocked"; // Expected result from the command handler

            mediatorMock.Setup(m => m.Send(It.IsAny<UpdateSlotBlockCommand>(), default))
                        .ReturnsAsync(expectedResult);

            // Act
            var result = await controller.UpdateSlotBlock(slotId);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var jsonResponse = Assert.IsType<string>(okResult.Value);
            var responseData = JsonConvert.DeserializeObject<string>(jsonResponse);
            Assert.Equal(expectedResult, responseData); // Check if the response matches the expected result
        }

      [Fact]
public async Task UpdateSlotBlock_Returns_InternalServerError_On_Exception()
{
    // Arrange
    var mediatorMock = new Mock<IMediator>();
    var controller = new SlotDetailsController(mediatorMock.Object);
    var slotId = Guid.NewGuid();
    var expectedStatusCode = (int)HttpStatusCode.InternalServerError;

    mediatorMock.Setup(m => m.Send(It.IsAny<UpdateSlotBlockCommand>(), default))
                .ThrowsAsync(new Exception());

    // Act
    var result = await controller.UpdateSlotBlock(slotId);

    // Assert
    var objectResult = Assert.IsType<ObjectResult>(result);
    Assert.Equal(expectedStatusCode, objectResult.StatusCode);
}

 [Fact]
        public async Task NoShow_Returns_OK_For_Valid_Request()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var controller = new SlotDetailsController(mediatorMock.Object);
            var model = new NoShowDTO
            {
                SlotId = Guid.NewGuid(),
                NewStatus = "No Show",
                UpdatedRemarks = "Candidate did not show up"
            };

            // Act
            var result = await controller.NoShow(model);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            Assert.Equal((int)HttpStatusCode.OK, okResult.StatusCode);
        }

        [Fact]
        public async Task NoShow_Returns_NotFound_For_Invalid_SlotId()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var controller = new SlotDetailsController(mediatorMock.Object);
            var model = new NoShowDTO
            {
                SlotId = Guid.NewGuid(),
                NewStatus = "No Show",
                UpdatedRemarks = "Candidate did not show up"
            };

            mediatorMock.Setup(m => m.Send(It.IsAny<NoShowCommand>(), default))
                        .ThrowsAsync(new NotFoundException("Slot not found"));

            // Act
            var result = await controller.NoShow(model);

            // Assert
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
            Assert.Equal((int)HttpStatusCode.NotFound, notFoundResult.StatusCode);
        }

        [Fact]
        public async Task NoShow_Returns_InternalServerError_On_Exception()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var controller = new SlotDetailsController(mediatorMock.Object);
            var model = new NoShowDTO
            {
                SlotId = Guid.NewGuid(),
                NewStatus = "No Show",
                UpdatedRemarks = "Candidate did not show up"
            };

            mediatorMock.Setup(m => m.Send(It.IsAny<NoShowCommand>(), default))
                        .ThrowsAsync(new Exception());

            // Act
            var result = await controller.NoShow(model);

            // Assert
            var objectResult = Assert.IsType<ObjectResult>(result);
            Assert.Equal((int)HttpStatusCode.InternalServerError, objectResult.StatusCode);
        }
[Fact]
public async Task AddSlotDetails_Returns_Created_When_SlotDetails_Added_Successfully()
{
    // Arrange
    var mediatorMock = new Mock<IMediator>();
    var controller = new SlotDetailsController(mediatorMock.Object);

    // Mock HttpContext to provide authentication information
    var httpContext = new DefaultHttpContext();
    httpContext.User = new ClaimsPrincipal(new ClaimsIdentity(new Claim[]
    {
        new Claim(ClaimTypes.Name, "testuser") // Provide authenticated user name here
    }));
    controller.ControllerContext = new ControllerContext
    {
        HttpContext = httpContext
    };

    var model = new List<SlotDetailsDTO>
    {
        // Add slot details DTO objects here as needed for the test case
    };

    // Mock the mediator to return a successful response
    mediatorMock.Setup(m => m.Send(It.IsAny<SlotDetailsCommand>(), default)).ReturnsAsync("success");

    // Act
    var result = await controller.AddSlotDetails(model);

    // Assert
    var createdResult = Assert.IsType<StatusCodeResult>(result);
    Assert.Equal((int)HttpStatusCode.Created, createdResult.StatusCode);
}



    }
    

    
}

