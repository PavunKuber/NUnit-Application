// using Assignment.Controllers;
using Assignment.Contracts.DTO;
using Assignment.Core.Exceptions;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Xunit;
using Assignment.Providers.Handlers.Commands;
using Assignment.Providers.Handlers.Queries;
using Microsoft.Extensions.Logging;
using System.Security.Authentication;
using Microsoft.Extensions.Configuration;
using Assignment.Controllers;

namespace Assignment.Tests.Controllers
{
    public class LoginControllerTests
    {
        [Fact]
        public async Task Login_ValidCredentials_ReturnsOkResult()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var configurationMock = new Mock<Microsoft.Extensions.Configuration.IConfiguration>();
            var loggerMock = new Mock<ILogger<LoginController>>(); // Create a mock logger
            var controller = new LoginController(mediatorMock.Object, configurationMock.Object, loggerMock.Object);

            // Sample mock data
            var userDto = new CreateUserDTO { Username = "testuser", Password = "testpassword" };
            var expectedToken = "sampletoken";
            mediatorMock.Setup(m => m.Send(It.IsAny<SignInUserByUserNameQuery>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(new TokenResponseDTO
                {
                    AccessToken = expectedToken,
                    AccessTokenExpiration = DateTime.UtcNow.AddHours(1),
                    RefreshToken = "refreshtoken",
                    RefreshTokenExpiration = DateTime.UtcNow.AddDays(7),
                    Username = "username"
                });

            // Act
            var result = await controller.Login(userDto);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var tokenResponse = Assert.IsType<TokenResponseDTO>(okResult.Value);
            Assert.Equal(expectedToken, tokenResponse.AccessToken);
        }

        [Fact]
        public async Task Login_InvalidRequestBodyException_ReturnsBadRequestResult()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var configurationMock = new Mock<Microsoft.Extensions.Configuration.IConfiguration>();
            var loggerMock = new Mock<ILogger<LoginController>>(); // Create a mock logger
            var controller = new LoginController(mediatorMock.Object, configurationMock.Object, loggerMock.Object);

            mediatorMock.Setup(m => m.Send(It.IsAny<SignInUserByUserNameQuery>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new InvalidRequestBodyException("Invalid request body"));

            // Act
            var result = await controller.Login(new CreateUserDTO());

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal("Invalid request body", ((BaseResponseDTO)badRequestResult.Value).Errors[0]);
        }

        [Fact]
        public async Task Login_EntityNotFoundException_ReturnsNotFoundResult()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var configurationMock = new Mock<Microsoft.Extensions.Configuration.IConfiguration>();
            var loggerMock = new Mock<ILogger<LoginController>>(); // Create a mock logger
            var controller = new LoginController(mediatorMock.Object, configurationMock.Object, loggerMock.Object);

            var nonExistentUsername = "nonExistentUser"; // Set a non-existent username

            mediatorMock.Setup(m => m.Send(It.IsAny<SignInUserByUserNameQuery>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new EntityNotFoundException($"User '{nonExistentUsername}' not found")); // Simulate throwing an EntityNotFoundException

            // Act
            var result = await controller.Login(new CreateUserDTO { Username = nonExistentUsername, Password = "password" });

            // Assert
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
            var baseResponse = Assert.IsType<BaseResponseDTO>(notFoundResult.Value);
            Assert.False(baseResponse.IsSuccess);
            Assert.NotNull(baseResponse.Errors);
            Assert.NotEmpty(baseResponse.Errors);
            Assert.Equal($"User '{nonExistentUsername}' not found", baseResponse.Errors[0]);
        }

        [Fact]
        public async Task Login_InvalidCredentialException_ReturnsBadRequestResult()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var configurationMock = new Mock<Microsoft.Extensions.Configuration.IConfiguration>();
            var loggerMock = new Mock<ILogger<LoginController>>(); // Create a mock logger
            var controller = new LoginController(mediatorMock.Object, configurationMock.Object, loggerMock.Object);

            var invalidUsername = "invalidUser"; // Set an invalid username
            var invalidPassword = "invalidPassword"; // Set an invalid password

            mediatorMock.Setup(m => m.Send(It.IsAny<SignInUserByUserNameQuery>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new InvalidCredentialException($"Invalid credentials for user '{invalidUsername}'")); // Simulate throwing an InvalidCredentialException

            // Act
            var result = await controller.Login(new CreateUserDTO { Username = invalidUsername, Password = invalidPassword });

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var baseResponse = Assert.IsType<BaseResponseDTO>(badRequestResult.Value);
            Assert.False(baseResponse.IsSuccess);
            Assert.NotNull(baseResponse.Errors);
            Assert.NotEmpty(baseResponse.Errors);
            Assert.Equal($"Invalid credentials for user '{invalidUsername}'", baseResponse.Errors[0]);
        }
        [Fact]
        public async Task Login_InvalidRequestBody_ReturnsBadRequestResult()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var configurationMock = new Mock<Microsoft.Extensions.Configuration.IConfiguration>();
            var loggerMock = new Mock<ILogger<LoginController>>(); // Create a mock logger
            var controller = new LoginController(mediatorMock.Object, configurationMock.Object, loggerMock.Object);

            var invalidRequestBody = new CreateUserDTO(); // Create an invalid request body

            mediatorMock.Setup(m => m.Send(It.IsAny<SignInUserByUserNameQuery>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new InvalidRequestBodyException("Invalid request body")); // Simulate throwing an InvalidRequestBodyException

            // Act
            var result = await controller.Login(invalidRequestBody);

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            var baseResponse = Assert.IsType<BaseResponseDTO>(badRequestResult.Value);
            Assert.False(baseResponse.IsSuccess);
            Assert.NotNull(baseResponse.Errors);
            Assert.NotEmpty(baseResponse.Errors);
            Assert.Equal("Invalid request body", baseResponse.Errors[0]);
        }



        [Fact]
        public async Task RefreshToken_UnauthorizedAccessException_ReturnsUnauthorizedResult()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var configurationMock = new Mock<Microsoft.Extensions.Configuration.IConfiguration>();
            var loggerMock = new Mock<ILogger<LoginController>>(); // Create a mock logger
            var controller = new LoginController(mediatorMock.Object, configurationMock.Object, loggerMock.Object);

            mediatorMock.Setup(m => m.Send(It.IsAny<RefreshTokenCommand>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new UnauthorizedAccessException("Unauthorized access"));

            // Act
            var result = await controller.RefreshToken(new RefreshTokenDTO());

            // Assert
            var unauthorizedResult = Assert.IsType<UnauthorizedObjectResult>(result);
            Assert.Equal("Unauthorized access", ((BaseResponseDTO)unauthorizedResult.Value).Errors[0]);
        }

        [Fact]
        public async Task RefreshToken_OtherExceptions_ReturnsInternalServerError()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var configurationMock = new Mock<Microsoft.Extensions.Configuration.IConfiguration>();
            var loggerMock = new Mock<ILogger<LoginController>>(); // Create a mock logger
            var controller = new LoginController(mediatorMock.Object, configurationMock.Object, loggerMock.Object);

            mediatorMock.Setup(m => m.Send(It.IsAny<RefreshTokenCommand>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new Exception("Unknown error"));
            mediatorMock.Setup(m => m.Send(It.IsAny<SignInUserByUserNameQuery>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(new TokenResponseDTO
                {
                    AccessToken = "sampletoken",
                    AccessTokenExpiration = DateTime.UtcNow.AddHours(1),
                    RefreshToken = "refreshtoken",
                    RefreshTokenExpiration = DateTime.UtcNow.AddDays(7),
                    Username = "username"
                });

            // Act
            var result = await controller.RefreshToken(new RefreshTokenDTO());

            // Assert
            var statusCodeResult = Assert.IsType<ObjectResult>(result);
            Assert.Equal((int)HttpStatusCode.InternalServerError, statusCodeResult.StatusCode);
        }

        [Fact]
        public async Task RefreshToken_InvalidTokenException_ReturnsUnauthorizedResult()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var configurationMock = new Mock<Microsoft.Extensions.Configuration.IConfiguration>();
            var loggerMock = new Mock<ILogger<LoginController>>(); // Create a mock logger
            var controller = new LoginController(mediatorMock.Object, configurationMock.Object, loggerMock.Object);

            mediatorMock.Setup(m => m.Send(It.IsAny<RefreshTokenCommand>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new InvalidTokenException("Invalid token"));

            // Act
            var result = await controller.RefreshToken(new RefreshTokenDTO());

            // Assert
            var unauthorizedResult = Assert.IsType<UnauthorizedObjectResult>(result);
            Assert.Equal("Invalid token", ((BaseResponseDTO)unauthorizedResult.Value).Errors[0]);
        }
        [Fact]
        public async Task RefreshToken_InvalidToken_ReturnsUnauthorizedResult()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var configurationMock = new Mock<Microsoft.Extensions.Configuration.IConfiguration>();
            var loggerMock = new Mock<ILogger<LoginController>>(); // Create a mock logger
            var controller = new LoginController(mediatorMock.Object, configurationMock.Object, loggerMock.Object);

            var invalidRefreshToken = "invalidRefreshToken"; // Set an invalid refresh token

            mediatorMock.Setup(m => m.Send(It.IsAny<RefreshTokenCommand>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new InvalidTokenException("Invalid token")); // Simulate throwing an InvalidTokenException

            // Act
            var result = await controller.RefreshToken(new RefreshTokenDTO { Token = invalidRefreshToken });

            // Assert
            var unauthorizedResult = Assert.IsType<UnauthorizedObjectResult>(result);
            var baseResponse = Assert.IsType<BaseResponseDTO>(unauthorizedResult.Value);
            Assert.False(baseResponse.IsSuccess);
            Assert.NotNull(baseResponse.Errors);
            Assert.NotEmpty(baseResponse.Errors);
            Assert.Equal("Invalid token", baseResponse.Errors[0]);
        }


        [Fact]
        public async Task RefreshToken_ValidToken_ReturnsOkResult()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var configurationMock = new Mock<IConfiguration>();
            var loggerMock = new Mock<ILogger<LoginController>>();
            var controller = new LoginController(mediatorMock.Object, configurationMock.Object, loggerMock.Object);

            // Sample mock data
            var refreshTokenDto = new RefreshTokenDTO { Token = "valid_refresh_token" };
            var expectedTokenResponse = new TokenResponseDTO
            {
                AccessToken = "new_access_token",
                AccessTokenExpiration = DateTime.UtcNow.AddHours(1),
                RefreshToken = "new_refresh_token",
                RefreshTokenExpiration = DateTime.UtcNow.AddDays(7)
            };

            // Mock the behavior of the mediator
            mediatorMock.Setup(m => m.Send(It.IsAny<RefreshTokenCommand>(), It.IsAny<CancellationToken>()))
                        .ReturnsAsync(expectedTokenResponse);

            // Act
            var result = await controller.RefreshToken(refreshTokenDto);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var tokenResponse = okResult.Value;
            Assert.NotNull(tokenResponse);

            var accessToken = tokenResponse.GetType().GetProperty("accessToken")?.GetValue(tokenResponse);
            var accessTokenExpiration = tokenResponse.GetType().GetProperty("accessTokenExpiration")?.GetValue(tokenResponse);
            var refreshToken = tokenResponse.GetType().GetProperty("refreshToken")?.GetValue(tokenResponse);
            var refreshTokenExpiration = tokenResponse.GetType().GetProperty("refreshTokenExpiration")?.GetValue(tokenResponse);

            Assert.NotNull(accessToken);
            Assert.IsType<string>(accessToken);
            Assert.NotNull(accessTokenExpiration);
            Assert.IsType<DateTime>(accessTokenExpiration);
            Assert.NotNull(refreshToken);
            Assert.IsType<string>(refreshToken);
            Assert.NotNull(refreshTokenExpiration);
            Assert.IsType<DateTime>(refreshTokenExpiration);
        }
        [Fact]
public async Task RevokeRefreshToken_ValidToken_ReturnsOkResult()
{
    // Arrange
    var mediatorMock = new Mock<IMediator>();
    var configurationMock = new Mock<Microsoft.Extensions.Configuration.IConfiguration>();
    var loggerMock = new Mock<ILogger<LoginController>>(); // Create a mock logger
    var controller = new LoginController(mediatorMock.Object, configurationMock.Object, loggerMock.Object);

    // Mock the behavior of the mediator to successfully revoke the refresh token
// Mock the behavior of the mediator to successfully revoke the refresh token
mediatorMock.Setup(m => m.Send(It.IsAny<RevokeRefreshTokenCommand>(), It.IsAny<CancellationToken>()))
            .Returns(Task.FromResult(Unit.Value));

    // Act
    var result = await controller.RevokeRefreshToken(new RevokeTokenDTO { Token = "valid_refresh_token" });

    // Assert
    var okResult = Assert.IsType<OkObjectResult>(result);
    var response = Assert.IsType<BaseResponseDTO>(okResult.Value);
    Assert.True(response.IsSuccess);
}



[Fact]
public async Task RevokeRefreshToken_InvalidToken_ReturnsUnauthorizedResult()
{
    // Arrange
    var mediatorMock = new Mock<IMediator>();
    var configurationMock = new Mock<Microsoft.Extensions.Configuration.IConfiguration>();
    var loggerMock = new Mock<ILogger<LoginController>>(); // Create a mock logger
    var controller = new LoginController(mediatorMock.Object, configurationMock.Object, loggerMock.Object);

    // Mock the behavior of the mediator to throw an InvalidTokenException
    mediatorMock.Setup(m => m.Send(It.IsAny<RevokeRefreshTokenCommand>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new InvalidTokenException("Invalid token"));

    // Act
    var result = await controller.RevokeRefreshToken(new RevokeTokenDTO { Token = "invalid_refresh_token" });

    // Assert
    var unauthorizedResult = Assert.IsType<UnauthorizedObjectResult>(result);
    var response = Assert.IsType<BaseResponseDTO>(unauthorizedResult.Value);
    Assert.False(response.IsSuccess);
    Assert.Equal("Invalid token", response.Errors[0]);
}



    }


}

