using Assignment.Controllers;
using Assignment.Contracts.DTO;
using Assignment.Core.Exceptions;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Xunit;
using Assignment.Providers.Handlers.Commands;
using Assignment.Providers.Handlers.Queries;
using Assignment.Contracts.Data.Entities;
using System.Text.Json;

namespace Assignment.Tests.Controllers
{
    public class PanelCoordinatorControllerTests
    {
        [Fact]
        public async Task GetUser_ReturnsOkResult()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var controller = new PanelCoordinatorController(mediatorMock.Object, null);

            var expectedPanelMembers = new List<PanelMemberDTO>
            {
                new PanelMemberDTO { Email = "test1@test.com", Name = "Test User 1" },
                new PanelMemberDTO { Email = "test2@test.com", Name = "Test User 2" }
            };

            mediatorMock.Setup(m => m.Send(It.IsAny<GetPanelMemberQuery>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(expectedPanelMembers);

            // Act
            var result = await controller.GetUser();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var panelMembersResult = Assert.IsAssignableFrom<IEnumerable<PanelMemberDTO>>(okResult.Value);
            Assert.Equal(expectedPanelMembers, panelMembersResult);
        }

[Fact]
public async Task GetUser_ReturnsBadRequestResultWhenPanelMembersNotFound()
{
    // Arrange
    var mediatorMock = new Mock<IMediator>();
    var controller = new PanelCoordinatorController(mediatorMock.Object, null);

    mediatorMock.Setup(m => m.Send(It.IsAny<GetPanelMemberQuery>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync((IEnumerable<PanelMemberDTO>)null); // Simulate no panel members found

    // Act
    var result = await controller.GetUser();

    // Assert
    var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
    Assert.Equal("No panel members found.", badRequestResult.Value);
}

// [Fact]
// public async Task DesignationAndInterviewLevel_ReturnsOkResult()
// {
//     // Arrange
//     var mediatorMock = new Mock<IMediator>();
//     var controller = new PanelCoordinatorController(mediatorMock.Object, null);

//     var codeMappings = new List<CodeMappingDTO>
//     {
//         new CodeMappingDTO { Codelevel = "Code1", Interviewlevel = "Interview1", Email = "test1@test.com" },
//         new CodeMappingDTO { Codelevel = "Code2", Interviewlevel = "Interview2", Email = "test2@test.com" }
//     };

//     mediatorMock.Setup(m => m.Send(It.IsAny<CodeMappingCommand>(), It.IsAny<CancellationToken>()))
//                 .ReturnsAsync(new object());

//     // Act
//     var result = await controller.DesignationAndInterviewLevel(codeMappings);

//     // Assert
//     var okResult = Assert.IsType<OkObjectResult>(result);
//     Assert.Equal("{\"status\":\"All Data added successfully\",\"responses\":[{},{}]}", JsonSerializer.Serialize(okResult.Value));
// }

[Fact]
public async Task MapPanelMembers_ReturnsBadRequestForInvalidOperation()
{
    // Arrange
    var mediatorMock = new Mock<IMediator>();
    var controller = new PanelCoordinatorController(mediatorMock.Object, null);

    var invalidUsername = "invalid_username";
    var expectedErrorMessage = $"Invalid operation for username: {invalidUsername}";

    // Set up the mediator mock to throw an InvalidOperationException with the expected error message
    mediatorMock.Setup(m => m.Send(It.IsAny<MapPanelMemberCommand>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new InvalidOperationException(expectedErrorMessage));

    // Act
    var result = await controller.MapPanelMembers(new List<string> { invalidUsername });

    // Assert
    var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
    var response = Assert.IsType<BaseResponseDTO>(badRequestResult.Value);
    Assert.False(response.IsSuccess);
    Assert.Contains(expectedErrorMessage, response.Errors);
}


      [Fact]
public async Task DesignationAndInterviewLevel_ReturnsOkResult()
{
    // Arrange
    var mediatorMock = new Mock<IMediator>();
    var controller = new PanelCoordinatorController(mediatorMock.Object, null);

    var codeMappings = new List<CodeMappingDTO>
    {
        new CodeMappingDTO { Codelevel = "Code1", Interviewlevel = "Interview1", Email = "test1@test.com" },
        new CodeMappingDTO { Codelevel = "Code2", Interviewlevel = "Interview2", Email = "test2@test.com" }
    };

    mediatorMock.Setup(m => m.Send(It.IsAny<CodeMappingCommand>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(new object());

    // Act
    var result = await controller.DesignationAndInterviewLevel(codeMappings);

    // Assert
    var okResult = Assert.IsType<OkObjectResult>(result);
    var responseObject = okResult.Value; // The actual value returned by the action
    Assert.True((bool)responseObject.GetType().GetProperty("IsSuccess").GetValue(responseObject)); // Check IsSuccess property
    Assert.Equal("All data added successfully", responseObject.GetType().GetProperty("Message").GetValue(responseObject)); // Check Message property
}

[Fact]
public async Task PostDate_ReturnsCreatedResult()
{
    // Arrange
    var mediatorMock = new Mock<IMediator>();
    var controller = new PanelCoordinatorController(mediatorMock.Object, null);

    var allocateDates = new List<AllocateDateDTO>
    {
        new AllocateDateDTO { StartDate = DateTime.Now, EndDate = DateTime.Now.AddDays(1), Email = "test1@test.com" },
        new AllocateDateDTO { StartDate = DateTime.Now.AddDays(1), EndDate = DateTime.Now.AddDays(2), Email = "test2@test.com" }
    };

    mediatorMock.Setup(m => m.Send(It.IsAny<AllocateDateCommand>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync("someStringResult"); // Replace "someStringResult" with the expected string result

    // Act
    var result = await controller.PostDate(allocateDates);

    // Assert
    Assert.IsType<OkObjectResult>(result);
}


        [Fact]
        public async Task MapPanelMembers_ReturnsOkResult()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var controller = new PanelCoordinatorController(mediatorMock.Object, null);

            var usernames = new List<string> { "user1", "user2" };

            mediatorMock.Setup(m => m.Send(It.IsAny<MapPanelMemberCommand>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(Guid.NewGuid()); // Assuming the method returns Task<Guid>

            // Act
            var result = await controller.MapPanelMembers(usernames);

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var responses = Assert.IsAssignableFrom<IEnumerable<object>>(okResult.Value);
            Assert.NotEmpty(responses);
        }

      

        [Fact]
        public async Task GetUser_ReturnsBadRequestResultWhenMediatorFails()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var controller = new PanelCoordinatorController(mediatorMock.Object, null);

            mediatorMock.Setup(m => m.Send(It.IsAny<GetPanelMemberQuery>(), It.IsAny<CancellationToken>()))
                .ThrowsAsync(new Exception("Error occurred")); // Simulate mediator failure

            // Act
            var result = await controller.GetUser();

            // Assert
            var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal("Error occurred", badRequestResult.Value);
        }
[Fact]
public async Task GetAllAllocatedate_NoDatesFound_ReturnsBadRequest()
{
    // Arrange
    var mediatorMock = new Mock<IMediator>();
    var controller = new PanelCoordinatorController(mediatorMock.Object, null);

// Set up mediator mock to return an empty list for AllocateDateDTO
    mediatorMock.Setup(m => m.Send(It.IsAny<GetAllAlloocateDateQuery>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(new List<AllocateDateDTO>());


    // Act
    var result = await controller.GetAllAllocatedate();

    // Assert
    var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
    Assert.Equal("No allocated dates found.", badRequestResult.Value);
}

[Fact]
public async Task GetAllAllocatedate_DatesFound_ReturnsOkResult()
{
// Arrange
var mediatorMock = new Mock<IMediator>();
var controller = new PanelCoordinatorController(mediatorMock.Object, null);

// Create a list of AllocateDateDTO objects
var expectedDates = new List<AllocateDateDTO>
{
    new AllocateDateDTO { Email = "test1@test.com", StartDate = DateTime.Now, EndDate = DateTime.Now.AddDays(1) },
    new AllocateDateDTO { Email = "test2@test.com", StartDate = DateTime.Now.AddDays(2), EndDate = DateTime.Now.AddDays(3) }
};

// Set up mediator mock to return the expected dates
mediatorMock.Setup(m => m.Send(It.IsAny<GetAllAlloocateDateQuery>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(expectedDates);

// Act
var result = await controller.GetAllAllocatedate();

// Assert
var okResult = Assert.IsType<OkObjectResult>(result);
var actualDates = Assert.IsAssignableFrom<IEnumerable<AllocateDateDTO>>(okResult.Value);
Assert.Equal(expectedDates, actualDates);
}
[Fact]
public async Task GetExceptPanelMember_ReturnsOkResultWithPanelMembers()
{
    // Arrange
    var mediatorMock = new Mock<IMediator>();
    var controller = new PanelCoordinatorController(mediatorMock.Object, null);

    var expectedPanelMembers = new List<PanelMemberDTO>
    {
        new PanelMemberDTO { Email = "test1@test.com", Name = "Test User 1" },
        new PanelMemberDTO { Email = "test2@test.com", Name = "Test User 2" }
    };

    mediatorMock.Setup(m => m.Send(It.IsAny<GetUserExceptPanelMemberQuery>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync(expectedPanelMembers);

    // Act
    var result = await controller.GetExceptPanelMember();

    // Assert
    var okResult = Assert.IsType<OkObjectResult>(result);
    var panelMembersResult = Assert.IsAssignableFrom<IEnumerable<PanelMemberDTO>>(okResult.Value);
    Assert.Equal(expectedPanelMembers, panelMembersResult);
}
[Fact]
public async Task GetExceptPanelMember_NoPanelMembersFound_ReturnsBadRequest()
{
    // Arrange
    var mediatorMock = new Mock<IMediator>();
    var controller = new PanelCoordinatorController(mediatorMock.Object, null);

    mediatorMock.Setup(m => m.Send(It.IsAny<GetUserExceptPanelMemberQuery>(), It.IsAny<CancellationToken>()))
                .ReturnsAsync((IEnumerable<PanelMemberDTO>)null); // Simulate no panel members found

    // Act
    var result = await controller.GetExceptPanelMember();

    // Assert
    var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
    Assert.Equal("No panel members found.", badRequestResult.Value);
}


    }
}
