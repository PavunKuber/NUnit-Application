using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Assignment.Contracts.DTO;
using Assignment.Controllers;
using Assignment.Core.Exceptions;
using Assignment.Providers.Handlers.Commands;
using Assignment.Providers.Handlers.Queries;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using Xunit;

namespace Assignment.Tests.Controllers
{
    public class UserRoleControllerTests
    {
        [Fact]
        public async Task GetUsersRole_Returns_OK_With_Valid_Response()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var controller = new UserRoleController(mediatorMock.Object);

            var expectedResponse = new List<UsersDetailDTO> { new UsersDetailDTO { Name = "User1", RoleName = "Admin", ReportingManager = "Manager1" } };

            mediatorMock.Setup(m => m.Send(It.IsAny<GetUserRoleQuery>(), default))
                        .ReturnsAsync(expectedResponse);

            // Act
            var result = await controller.GetUsersRole();

            // Assert
            var okResult = Assert.IsType<OkObjectResult>(result);
            var responseData = Assert.IsAssignableFrom<IEnumerable<UsersDetailDTO>>(okResult.Value);
            Assert.Single(responseData);
        }



        [Fact]
        public async Task GetUsersRole_Returns_NotFound_When_EntityNotFoundException_Thrown()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            var controller = new UserRoleController(mediatorMock.Object);

            mediatorMock.Setup(m => m.Send(It.IsAny<GetUserRoleQuery>(), default))
                        .ThrowsAsync(new EntityNotFoundException("User role not found"));

            // Act
            var result = await controller.GetUsersRole();

            // Assert
            var notFoundResult = Assert.IsType<NotFoundObjectResult>(result);
            Assert.Equal((int)HttpStatusCode.NotFound, notFoundResult.StatusCode);
        }





        [Fact]
public async Task CreateUsers_Returns_Created_With_Valid_Response()
{
    // Arrange
    var mediatorMock = new Mock<IMediator>();
    var controller = new UserRoleController(mediatorMock.Object);
    var model = new List<UserRoleDTO> { new UserRoleDTO() };

    // Mock mediator to return OK
    mediatorMock.Setup(m => m.Send(It.IsAny<CreateUserRoleCommand>(), default))
                .ReturnsAsync(HttpStatusCode.Created);

    // Act
    var result = await controller.CreateUsers(model);

    // Assert
    var okResult = Assert.IsType<OkObjectResult>(result);
    Assert.Equal((int)HttpStatusCode.OK, okResult.StatusCode);
}

[Fact]
public async Task CreateUsers_Returns_BadRequest_When_DuplicateUserException_Thrown()
{
    // Arrange
    var mediatorMock = new Mock<IMediator>();
    var controller = new UserRoleController(mediatorMock.Object);

    var model = new List<UserRoleDTO> { new UserRoleDTO { Username = "User1", Rolename = "Admin" } };

    mediatorMock.Setup(m => m.Send(It.IsAny<CreateUserRoleCommand>(), default))
                .ThrowsAsync(new DuplicateUserException("Duplicate user found"));

    // Act
    var result = await controller.CreateUsers(model);

    // Assert
    var badRequestResult = Assert.IsType<BadRequestObjectResult>(result);
    Assert.Equal((int)HttpStatusCode.BadRequest, badRequestResult.StatusCode);
    Assert.Equal("Duplicate user found", ((BaseResponseDTO)badRequestResult.Value).Errors[0]);
}

[Fact]
public async Task CreateUsers_Returns_OK_When_No_Exception_Thrown()
{
    // Arrange
    var mediatorMock = new Mock<IMediator>();
    var controller = new UserRoleController(mediatorMock.Object);

    var model = new List<UserRoleDTO> { new UserRoleDTO { Username = "User1", Rolename = "Admin" } };

    mediatorMock.Setup(m => m.Send(It.IsAny<CreateUserRoleCommand>(), default))
                .ReturnsAsync(Guid.NewGuid()); // Assuming a unique identifier is returned on successful creation

    // Act
    var result = await controller.CreateUsers(model);

    // Assert
    var okResult = Assert.IsType<OkObjectResult>(result);
    Assert.Equal((int)HttpStatusCode.OK, okResult.StatusCode);
    Assert.NotNull(okResult.Value); // Assuming some response object is returned
}


    }
}
