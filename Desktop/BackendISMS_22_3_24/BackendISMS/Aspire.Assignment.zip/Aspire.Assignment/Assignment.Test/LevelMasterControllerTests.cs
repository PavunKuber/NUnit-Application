using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.DTO;
using Assignment.Controllers;
using Assignment.Core.Exceptions;
using Assignment.Providers.Handlers.Queries;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace Assignment.Tests.Controllers
{
    public class LevelMasterControllerTests
    {
        // Test case for successful retrieval of levels
        [Fact]
        public async Task GetLevelMaster_ReturnsOkResult()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            mediatorMock.Setup(m => m.Send(It.IsAny<GetLevelMasterQuery>(), It.IsAny<CancellationToken>()))
                        .ReturnsAsync(new List<LevelMasterDTO>()); // Empty list as an example

            var controller = new LevelMasterController(mediatorMock.Object, null);

            // Act
            var result = await controller.GetLevelMaster();

            // Assert
            Assert.IsType<NotFoundObjectResult>(result);
        }

        // Test case for handling exceptions
        [Fact]
        public async Task GetLevelMaster_HandlesException()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            mediatorMock.Setup(m => m.Send(It.IsAny<GetLevelMasterQuery>(), It.IsAny<CancellationToken>()))
                        .ThrowsAsync(new Exception("An error occurred"));

            var controller = new LevelMasterController(mediatorMock.Object, null);

            // Act
            var result = await controller.GetLevelMaster();

            // Assert
            Assert.IsType<ObjectResult>(result);
            var objectResult = result as ObjectResult;
            Assert.Equal((int)HttpStatusCode.InternalServerError, objectResult.StatusCode);
            Assert.Equal("An error occurred while processing your request.", objectResult.Value);
        }

        // Test case for specific exception handling (NotFoundException)
        [Fact]
        public async Task GetLevelMaster_NotFoundException()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            mediatorMock.Setup(m => m.Send(It.IsAny<GetLevelMasterQuery>(), It.IsAny<CancellationToken>()))
                        .ThrowsAsync(new NotFoundException("Levels not found"));

            var controller = new LevelMasterController(mediatorMock.Object, null);

            // Act
            var result = await controller.GetLevelMaster();

            // Assert
            var objectResult = Assert.IsType<NotFoundObjectResult>(result);
            Assert.Equal("Levels not found", objectResult.Value);
        }

        // Test case for specific exception handling (UnauthorizedAccessException)
        [Fact]
        public async Task GetLevelMaster_UnauthorizedAccessException()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            mediatorMock.Setup(m => m.Send(It.IsAny<GetLevelMasterQuery>(), It.IsAny<CancellationToken>()))
                        .ThrowsAsync(new UnauthorizedAccessException("Unauthorized access"));

            var controller = new LevelMasterController(mediatorMock.Object, null);

            // Act
            var result = await controller.GetLevelMaster();

            // Assert
            var objectResult = Assert.IsType<UnauthorizedObjectResult>(result);
            Assert.Equal("Unauthorized access", objectResult.Value);
        }

        // Test case for specific exception handling (ValidationException)
        [Fact]
        public async Task GetLevelMaster_ValidationException()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            mediatorMock.Setup(m => m.Send(It.IsAny<GetLevelMasterQuery>(), It.IsAny<CancellationToken>()))
                        .ThrowsAsync(new ValidationException("Invalid request"));

            var controller = new LevelMasterController(mediatorMock.Object, null);

            // Act
            var result = await controller.GetLevelMaster();

            // Assert
            var objectResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal("Invalid request", objectResult.Value);
        }

        // Test case for specific exception handling (InvalidOperationException)
        [Fact]
        public async Task GetLevelMaster_InvalidOperationException()
        {
            // Arrange
            var mediatorMock = new Mock<IMediator>();
            mediatorMock.Setup(m => m.Send(It.IsAny<GetLevelMasterQuery>(), It.IsAny<CancellationToken>()))
                        .ThrowsAsync(new InvalidOperationException("Invalid operation"));

            var controller = new LevelMasterController(mediatorMock.Object, null);

            // Act
            var result = await controller.GetLevelMaster();

            // Assert
            var objectResult = Assert.IsType<BadRequestObjectResult>(result);
            Assert.Equal("Invalid operation", objectResult.Value);
        }
    }
}
