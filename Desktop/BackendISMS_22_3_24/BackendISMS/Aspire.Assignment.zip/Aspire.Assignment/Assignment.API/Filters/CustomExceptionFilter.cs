using System;
using System.Net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using System.Reflection;
using Assignment.Core.Exceptions;
using System.Collections.Generic;

namespace Assignment.API.Filters
{
    // Custom exception filter
    public class CustomExceptionFilter : ExceptionFilterAttribute
    {
        private readonly ILogger<CustomExceptionFilter> _logger;

        public CustomExceptionFilter(ILogger<CustomExceptionFilter> logger)
        {
            _logger = logger;
        }

        public override void OnException(ExceptionContext context)
        {
            var exception = context.Exception;
            var statusCode = HttpStatusCode.InternalServerError;
            var message = "An error occurred while processing your request.";

            // Log the exception
            _logger.LogError(exception, message);

            // Check if the exception type exists
            var exceptionType = Type.GetType($"Assignment.Core.Exceptions.{exception.GetType().Name}");
            if (exceptionType != null)
            {
                statusCode = GetHttpStatusCode(exceptionType);
                message = GetMessage(exceptionType);
            }

            // Set the response
            context.Result = new ObjectResult(new { error = message })
            {
                StatusCode = (int)statusCode
            };
            context.ExceptionHandled = true;
        }

        // Helper method to get HTTP status code from exception type
        private HttpStatusCode GetHttpStatusCode(Type exceptionType)
        {
            // Define mapping of exception types to HTTP status codes
            var statusCodeMap = new Dictionary<Type, HttpStatusCode>
            {
                { typeof(DateErrorException), HttpStatusCode.BadRequest },
                { typeof(EntityNotFoundException), HttpStatusCode.NotFound },
                { typeof(InvalidCredentialsException), HttpStatusCode.Unauthorized },
                { typeof(NotFoundException), HttpStatusCode.NotFound },
                { typeof(EmptyListNotFoundException), HttpStatusCode.NotFound },
                { typeof(DuplicateUserException), HttpStatusCode.Conflict },
                { typeof(HttpRequestException), HttpStatusCode.BadRequest },
                { typeof(InvalidArgumentException), HttpStatusCode.BadRequest },
                { typeof(InvalidInputException), HttpStatusCode.BadRequest },
                { typeof(InvalidMeetDetailsException), HttpStatusCode.BadRequest },
                { typeof(InvalidOperationException), HttpStatusCode.BadRequest },
                { typeof(InvalidParameterException), HttpStatusCode.BadRequest },
                { typeof(InvalidRequestBodyException), HttpStatusCode.BadRequest },
                { typeof(InvalidTokenException), HttpStatusCode.BadRequest },
                { typeof(MeetingScheduleFailedException), HttpStatusCode.BadRequest },
                { typeof(SignInProcessException), HttpStatusCode.BadRequest },
                { typeof(UnauthorizedAccessException), HttpStatusCode.Forbidden },
                { typeof(UnauthorizedRefreshTokenException), HttpStatusCode.Unauthorized },
                { typeof(UserRoleException), HttpStatusCode.BadRequest },
                { typeof(ValidationException), HttpStatusCode.BadRequest },
                { typeof(ParsingFailedNotFoundException), HttpStatusCode.NotFound },
                { typeof(RetrievalFailedNotFoundException), HttpStatusCode.NotFound },
                { typeof(PermissionDeniedException), HttpStatusCode.Forbidden },
                { typeof(TimeoutException), HttpStatusCode.RequestTimeout },
                 { typeof(SystemDownException), HttpStatusCode.ServiceUnavailable },
                { typeof(DatabaseConnectionException), HttpStatusCode.ServiceUnavailable },
                { typeof(NetworkException), HttpStatusCode.ServiceUnavailable }
            };
        

            // Get HTTP status code from mapping
            return statusCodeMap.TryGetValue(exceptionType, out var statusCode) ? statusCode : HttpStatusCode.InternalServerError;
        }

        // Helper method to get message from exception type
        private string GetMessage(Type exceptionType)
        {
            // Get default message if exception type is NotFoundException or its derived class
            if (exceptionType == typeof(NotFoundException) || exceptionType.IsSubclassOf(typeof(NotFoundException)))
            {
                return "Resource not found.";
            }

            // Define default message
            var defaultMessage = "An error occurred while processing the request.";

            // Get message from exception type
            var messageProperty = exceptionType.GetProperty("Message", BindingFlags.Public | BindingFlags.Instance);
            if (messageProperty != null)
            {
                return (string)messageProperty.GetValue(null);
            }

            return defaultMessage;
        }
    }
}
