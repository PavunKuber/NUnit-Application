using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using Assignment.Core.Exceptions;
using Assignment.Contracts.DTO;
using System;

namespace Assignment.API.Middlewares
{
    // Custom middleware for exception handling
    public class ExceptionHandlingMiddleware : IMiddleware
    {
        private readonly ILogger<ExceptionHandlingMiddleware> _logger;
        private readonly IHttpContextAccessor _httpContextAccessor;

        // Constructor to initialize logger and HTTP context accessor
        public ExceptionHandlingMiddleware(ILogger<ExceptionHandlingMiddleware> logger, IHttpContextAccessor httpContextAccessor)
        {
            _logger = logger;
            _httpContextAccessor = httpContextAccessor;
        }

        // Method to handle HTTP requests and exceptions
        public async Task InvokeAsync(HttpContext context, RequestDelegate next)
        {
            try
            {
                // Executing next middleware in the pipeline
                await next(context);
            }
            // Catching custom exception for invalid request body
            catch (InvalidRequestBodyException ex)
            {
                // Logging error with user ID and action name
                LogErrorWithUserId(ex, context.Request.Path);
                // Creating bad request response
                var badRequestObjectResult = new BadRequestObjectResult(new BaseResponseDTO
                {
                    IsSuccess = false,
                    Errors = new[] { ex.Message }
                });
                // Setting response status code
                context.Response.StatusCode = StatusCodes.Status400BadRequest;
                // Returning bad request response
                await badRequestObjectResult.ExecuteResultAsync(new ActionContext
                {
                    HttpContext = context
                });
            }
            // Catching other exceptions
            catch (Exception ex)
            {
                // Logging error with user ID and action name
                LogErrorWithUserId(ex, context.Request.Path);
                // Creating problem details for internal server error
                var problemDetails = new ProblemDetails()
                {
                    Status = StatusCodes.Status500InternalServerError,
                    Title = "Internal Server Error",
                    Detail = "An unexpected error occurred"
                };
                // Setting response status code
                context.Response.StatusCode = StatusCodes.Status500InternalServerError;
                // Returning internal server error response
                await context.Response.WriteAsJsonAsync(problemDetails);
            }
        }

        // Method to log errors with user ID
        private void LogErrorWithUserId(Exception ex, string actionName)
        {
            // Retrieving user ID and username from HTTP context
            var userId = _httpContextAccessor.HttpContext?.User?.FindFirst("id")?.Value;
            var username = _httpContextAccessor.HttpContext?.User?.Identity?.Name;
            // Logging error with user ID, username, action name, and error message
            _logger.LogError(ex, "Exception occurred for user '{Username}' (ID: {UserId}) while performing action '{Action}': {Message}", username, userId, actionName, ex.Message);
        }
    }
}
