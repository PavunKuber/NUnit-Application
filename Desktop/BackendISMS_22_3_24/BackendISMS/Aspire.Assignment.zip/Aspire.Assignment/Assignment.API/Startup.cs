using Assignment.Contracts.Data.Entities;
using Assignment.Core;
using Assignment.Core.Security;
using Assignment.Infrastructure;
//using Assignment.API.Filters;
using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using Serilog;
using Swashbuckle.AspNetCore.Filters;
using System;
using Assignment.API.Middlewares;

namespace Assignment
{
    public class Startup
    {
        // Constructor to initialize configuration
        public IConfiguration Configuration { get; }
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        // Method to configure services
        public void ConfigureServices(IServiceCollection services)
        {
            // Adding Swagger documentation generation and security definitions
            services.AddSwaggerGen(options =>
            {
                options.AddSecurityDefinition(
                    "oauth2",
                    new OpenApiSecurityScheme
                    {
                        Description = "Standard Authorization header using the Bearer scheme (\"bearer {token}\")",
                        In = ParameterLocation.Header,
                        Name = "Authorization",
                        Type = SecuritySchemeType.ApiKey
                    }
                );
                options.OperationFilter<SecurityRequirementsOperationFilter>();
            });

            // Adding persistence services
            services.AddPersistence(Configuration);
            // Adding core services
            services.AddCore();

            // Configuring CORS policy to allow requests from a specific origin
            services.AddCors(options =>
            {
                options.AddPolicy(
                    "AllowSpecificOrigin",
                    builder =>
                    {
                        builder
                            .WithOrigins("http://localhost:4200")
                            .AllowAnyHeader()
                            .AllowAnyOrigin()
                            .AllowAnyMethod();
                    }
                );
            });

            // Adding authentication services
            services.AddMarketplaceAuthentication(Configuration);

            // Configuring email settings
            services.Configure<EmailConfig>(Configuration.GetSection("EmailConfig"));

            // Configuring API behavior options to suppress default model state validation
            services.Configure<ApiBehaviorOptions>(options =>
            {
                options.SuppressModelStateInvalidFilter = true;
            });

            // Adding authorization policies
            services.AddAuthorization(options =>
            {
                options.AddPolicy("Panel Coordinator", policy => policy.RequireRole("Panel Coordinator"));
            });

            // Adding HTTP context accessor
            services.AddHttpContextAccessor();

            // Adding custom exception handling middleware
            services.AddScoped<ExceptionHandlingMiddleware>();

            // Adding controllers and enabling OData support
            services.AddControllers(options =>
            {
                // Registering CustomExceptionFilter globally
                //options.Filters.Add<CustomExceptionFilter>();
            })
            .AddOData(options => options.Select().Filter().OrderBy().Count().SetMaxTop(100));

            // Adding Serilog logging
            services.AddLogging(loggingBuilder =>
            {
                loggingBuilder.AddSerilog();
            });

            // Configuring Swagger documentation
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc(
                    "v1",
                    new OpenApiInfo
                    {
                        Title = "Interview Slot Management System",
                        Description = "The Interview Slot Management System for Aspire efficiently schedules and organizes interview slots for candidates and interviewers",
                        Version = "v1"
                    }
                );
            });
        }

        // Method to configure the HTTP request pipeline
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            // Checking if in development environment and enabling developer exception page if true
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            // Adding custom exception handling middleware
            app.UseMiddleware<ExceptionHandlingMiddleware>();

            // Redirecting HTTP requests to HTTPS
            app.UseHttpsRedirection();

            // Adding Swagger documentation middleware
            app.UseSwagger();

            // Adding Swagger UI middleware
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Aspire Assignment App API v1");
            });

            // Applying CORS policy
            app.UseCors("AllowSpecificOrigin");

            // Enabling routing middleware
            app.UseRouting();

            // Adding authentication middleware
            app.UseAuthentication();

            // Adding authorization middleware
            app.UseAuthorization();

            // Endpoints routing
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
