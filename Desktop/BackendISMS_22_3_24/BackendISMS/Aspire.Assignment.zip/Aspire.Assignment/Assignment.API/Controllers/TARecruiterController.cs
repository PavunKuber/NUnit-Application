using System;
using System.Collections;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.DTO;
using Assignment.Core.Exceptions;
using Assignment.Providers.Handlers.Commands;
using Assignment.Providers.Handlers.Queries;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace Assignment.Controllers
{
    // Controller for managing actions related to TA recruiters
    [Route("api/[controller]")]
    [ApiController]
    [EnableQuery]
    [Authorize(Roles = "TA Recruiter, TA Admin")]
    public class TARecruiterController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly IConfiguration _configuration;

        // Constructor to initialize mediator and configuration
        public TARecruiterController(IMediator mediator, IConfiguration configuration)
        {
            _mediator = mediator;
            _configuration = configuration;
        }

        // Action method to get all details
        [HttpGet]
        public async Task<IActionResult> GetallDetails()
        {
            try
            {
                // Send query to get all slot details
                var query = new GetAllSlotdetailQuery();
                var response = await _mediator.Send(query);
                
                // Convert the response to an array of MeetDetailsDTO
                var meetDetailsArray = response.ToArray();

                return Ok(meetDetailsArray);
            }
            catch (Exception ex)
            {
                // Log the exception
                // Return internal server error response
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        // Action method to schedule a meeting
        [HttpPost("Initiatemeet")]
        public async Task<IActionResult> ScheduleMeet(MeetDetailsDTO meetDetailsDTO)
        {
            try
            {
                // Send command to schedule meet
                var command = new ScheduleMeetCommand(meetDetailsDTO);
                var response = await _mediator.Send(command);
                return Ok(response);
            }
            catch (Exception ex)
            {
                // Handle exception
                return HandleException(ex);
            }
        }

        // Method to handle exceptions
        private IActionResult HandleException(Exception ex)
        {
            if (ex is InvalidMeetDetailsException)
            {
                return BadRequest(ex.Message);
            }
            else if (ex is NotFoundException)
            {
                return NotFound(ex.Message);
            }
            else if (ex is MeetingScheduleFailedException)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
            else
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, "An unexpected error occurred.");
            }
        }
    }
}
