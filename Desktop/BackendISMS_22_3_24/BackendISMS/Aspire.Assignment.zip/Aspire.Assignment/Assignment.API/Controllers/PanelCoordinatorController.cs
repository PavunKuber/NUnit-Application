using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.DTO;
using Assignment.Core.Exceptions;
using Assignment.Providers.Handlers.Commands;
using Assignment.Providers.Handlers.Queries;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.Extensions.Configuration;

namespace Assignment.Controllers
{
    // Controller for managing panel coordinator actions
    [Route("api/[controller]/[action]")]
    [ApiController]
    [EnableQuery]
    // [Authorize(Roles = "Panel Coordinator")] // Authorize attribute to restrict access to Panel Coordinator role only
    public class PanelCoordinatorController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly IConfiguration _configuration;

        // Constructor to initialize mediator and configuration
        public PanelCoordinatorController(IMediator mediator, IConfiguration configuration)
        {
            _mediator = mediator;
            _configuration = configuration;
        }

        // Endpoint for POST /api/PanelCoordinator/PostDate
        [HttpPost("AllocateDate")]
        // Action method to allocate dates
        [Authorize(Roles = "Panel Coordinator")]
        public async Task<IActionResult> PostDate([FromBody] List<AllocateDateDTO> model)
        {
            try
            {
                var responses = new List<object>();
                var errors = new List<string>();
                foreach (var data in model)
                {
                    try
                    {
                        var command = new AllocateDateCommand(data);
                        var response = await _mediator.Send(command);
                        responses.Add(response);
                    }
                    catch (InvalidRequestBodyException exception)
                    {
                        errors.AddRange(exception.Errors);
                    }
                    catch (DuplicateUserException exception)
                    {
                        errors.Add(exception.Message);
                    }
                }
                if (errors.Any())
                {
                    return BadRequest(new BaseResponseDTO { IsSuccess = false, Errors = errors.ToArray() });
                }
                // Return a success message with a 200 OK status code
                return Ok(new { message = "Data successfully stored in the database." });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // Endpoint for GET /api/PanelCoordinator/GetEmail
        [HttpGet("GetEmail")]
        [Authorize(Roles = "Panel Coordinator")]
        // Action method to get panel members
        public async Task<IActionResult> GetUser()
        {
            try
            {
                var query = new GetPanelMemberQuery();
                var response = await _mediator.Send(query);

                if (response == null || !response.Any())
                {
                    return BadRequest("No panel members found.");
                }

                return Ok(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // Endpoint for POST /api/PanelCoordinator/CodeMapping
        [HttpPost("CodeMapping")]
        // Action method to map designation and interview level
        [Authorize(Roles = "Panel Coordinator")]
        public async Task<IActionResult> DesignationAndInterviewLevel([FromBody] List<CodeMappingDTO> codeMappingDTO)
        {
            try
            {
                var responses = new List<object>();
                var errors = new List<string>();

                foreach (var dto in codeMappingDTO)
                {
                    try
                    {
                        var query = new CodeMappingCommand(dto);
                        var response = await _mediator.Send(query);
                        responses.Add(response);
                    }
                    catch (InvalidRequestBodyException exception)
                    {
                        errors.AddRange(exception.Errors);
                    }
                    catch (Exception error)
                    {
                        errors.Add(error.Message);
                    }
                }

                if (errors.Any())
                {
                    return BadRequest(new BaseResponseDTO { IsSuccess = false, Errors = errors.ToArray() });
                }

                // All data added successfully, return a success message
                return Ok(new { IsSuccess = true, Message = "All data added successfully", Responses = responses });
            }
            catch (Exception error)
            {
                return BadRequest(error.Message);
            }
        }

        // Endpoint for POST /api/PanelCoordinator/PanelMembers
        [HttpPost("PanelMembers")]
        // Action method to map panel members
        [Authorize(Roles = "Panel Coordinator")]
        public async Task<IActionResult> MapPanelMembers([FromBody] List<string> usernames)
        {
            try
            {
                var responses = new List<object>();
                var errors = new List<string>();

                foreach (var username in usernames)
                {
                    try
                    {
                        var command = new MapPanelMemberCommand(username);
                        var response = await _mediator.Send(command);
                        responses.Add(response);
                    }
                    catch (InvalidOperationException ex)
                    {
                        errors.Add(ex.Message);
                    }
                    catch (Exception ex)
                    {
                        errors.Add(ex.Message);
                    }
                }

                if (errors.Any())
                {
                    return BadRequest(new BaseResponseDTO { IsSuccess = false, Errors = errors.ToArray() });
                }

                return Ok(responses);
            }
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        // Endpoint for GET /api/PanelCoordinator/Getallocatedate
        [HttpGet]
        // Action method to get allocated dates for panel members
        [Authorize(Roles = "Panel Member, Reporting Manager")] // Authorize attribute to restrict access to Panel Member role only
        public async Task<IActionResult> Getallocatedate()
        {
            var loggedInUser = User.Identity.Name;
            if (string.IsNullOrEmpty(loggedInUser))
                return BadRequest(
                    new BaseResponseDTO
                    {
                        IsSuccess = false,
                        Errors = new[] { "User not authenticated." }
                    }
                );

            var query = new GetAllocatedateQuery(loggedInUser);
            var dates = await _mediator.Send(query);
            return Ok(dates.ToList());
        }
        [HttpGet]
        public async Task<IActionResult> GetExceptPanelMember()
        {
             try
            {
                var query = new GetUserExceptPanelMemberQuery();
                var response = await _mediator.Send(query);
 
                if (response == null || !response.Any())
                {
                    return BadRequest("No panel members found.");
                }
 
                return Ok(response);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
         [HttpGet("dates")]
[EnableQuery]
[Authorize(Roles = "Panel Coordinator")]
public async Task<IActionResult> GetAllAllocatedate()
{
    // Create a new query to get all allocated dates
    var query = new GetAllAlloocateDateQuery();

    // Send the query to the mediator asynchronously and await the result
    var dates = await _mediator.Send(query);

    // Check if any dates are found
    if (dates == null || !dates.Any())
    {
        // Return a BadRequest response with an appropriate message
        return BadRequest("No allocated dates found.");
    }

    // Return an HTTP 200 OK response with the retrieved dates
    return Ok(dates);
}

    }
}

