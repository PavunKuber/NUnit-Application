using System;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Assignment.Contracts.DTO;
using Assignment.Core.Exceptions;
using Assignment.Providers.Handlers.Queries;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.Extensions.Configuration;

namespace Assignment.Controllers
{
    // Controller for managing code masters
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Panel Coordinator")]
    public class CodeMasterController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly IConfiguration _configuration;

        // Constructor to initialize mediator and configuration
        public CodeMasterController(IMediator mediator, IConfiguration configuration)
        {
            _mediator = mediator;
            _configuration = configuration;
        }

        // Endpoint for GET /api/CodeMaster
        [HttpGet("GetDesignation")]
        [EnableQuery]
        // Action method to retrieve code masters
        public async Task<IActionResult> GetCodeMaster()
        {
            try
            {
                // Sending query to mediator to get code masters
                var query = new GetCodeMasterQuery();
                var codeMaster = await _mediator.Send(query);

                // If code masters not found, return NotFound response
                if (codeMaster == null || !codeMaster.Any())
                    return NotFound("Code master not found");

                // Return code masters
                return Ok(codeMaster);
            }
            catch (Exception ex)
            {
                // Log the exception for further investigation
                Console.WriteLine($"An error occurred: {ex}");

                // Handling different types of exceptions and returning appropriate responses
                if (ex is RetrievalFailedNotFoundException || ex is EmptyListNotFoundException)
                    return NotFound(ex.Message);
                else if (ex is ParsingFailedNotFoundException)
                    return BadRequest(ex.Message);
                else
                    return StatusCode((int)HttpStatusCode.InternalServerError, "An error occurred while processing your request.");
            }
        }
    }
}
