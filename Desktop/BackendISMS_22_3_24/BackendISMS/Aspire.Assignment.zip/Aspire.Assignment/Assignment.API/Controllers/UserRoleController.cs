using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Assignment.Contracts.DTO;
using Assignment.Core.Exceptions;
using Assignment.Providers.Handlers.Commands;
using Assignment.Providers.Handlers.Queries;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Assignment.Controllers
{
    // Controller for managing user roles
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Super Admin")] // Authorize attribute to restrict access to Super Admin role only
    public class UserRoleController : ControllerBase
    {
        private readonly IMediator _mediator;

        // Constructor to initialize mediator
        public UserRoleController(IMediator mediator)
        {
            _mediator = mediator;
        }

        // Action method to retrieve user roles
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<UsersDetailDTO>), (int)HttpStatusCode.OK)]
        [ProducesErrorResponseType(typeof(BaseResponseDTO))]
        public async Task<IActionResult> GetUsersRole()
        {
            try
            {
                // Sending query to mediator to get user roles
                var query = new GetUserRoleQuery();
                var usersWithRoles = await _mediator.Send(query);
                return Ok(usersWithRoles);
            }
            catch (Exception ex)
            {
                // Handling exceptions
                return HandleException(ex);
            }
        }

        // Action method to create user roles
        [HttpPost]
        [ProducesResponseType(typeof(IEnumerable<Guid>), (int)HttpStatusCode.Created)]
        [ProducesErrorResponseType(typeof(BaseResponseDTO))]
        public async Task<IActionResult> CreateUsers([FromBody] List<UserRoleDTO> model)
        {
            var responses = new List<object>();
            var errors = new List<string>();
            foreach (var dto in model)
            {
                try
                {
                    var command = new CreateUserRoleCommand(dto);
                    var response = await _mediator.Send(command);
                    responses.Add(response);
                }
                catch (DuplicateUserException ex)
                {
                    errors.Add(ex.Message);
                }
            }
            if (errors.Any())
            {
                return BadRequest(new BaseResponseDTO { IsSuccess = false, Errors = [.. errors] });
            }
 
            return Ok(responses);
        }

        // Method to handle exceptions and return appropriate responses
        private IActionResult HandleException(Exception ex)
        {
            if (ex is EntityNotFoundException)
            {
                return NotFound(new BaseResponseDTO { Errors = new string[] { ex.Message } });
            }
            else if (ex is InvalidOperationException)
            {
                return BadRequest(new BaseResponseDTO { Errors = new string[] { ex.Message } });
            }
            else if (ex is UserRoleException)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, new BaseResponseDTO { Errors = new string[] { ex.Message } });
            }
            else
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, new BaseResponseDTO { Errors = new string[] { "An unexpected error occurred." } });
            }
        }
    }
}
