using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.DTO;
using Assignment.Core.Exceptions;
using Assignment.Providers.Handlers.Commands;
using Assignment.Providers.Handlers.Queries;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using Newtonsoft.Json;

namespace Assignment.Controllers
{
    // Controller for managing slot details
    [Route("api/[controller]")]
    [ApiController]
    [EnableQuery]
    public class SlotDetailsController : ControllerBase
    {
        private readonly IMediator _mediator;

        // Constructor to initialize mediator
        public SlotDetailsController(IMediator mediator)
        {
            _mediator = mediator;
        }

        // Action method to add slot details
        [HttpPost]
        [Authorize(Roles = "Panel Member, Reporting Manager")]
        public async Task<IActionResult> AddSlotDetails([FromBody] List<SlotDetailsDTO> model)
        {
            try
            {
                var responses = new List<object>();
                var errors = new List<string>();

                // Get logged-in user's name
                var loggedInUser = User.Identity.Name;

                // Send command to add slot details
                foreach (var data in model)
                {
                    try
                    {
                        var command = new SlotDetailsCommand(data, loggedInUser);
                        var response = await _mediator.Send(command);
                        responses.Add(response);
                    }
                    catch (InvalidRequestBodyException exception)
                    {
                        errors.AddRange(exception.Errors);
                    }
                    catch (EntityNotFoundException exception)
                    {
                        errors.Add(exception.Message);
                    }
                    catch (DuplicateUserException exception)
                    {
                        errors.Add(exception.Message);
                    }
                }
                if (errors.Any())
                {
                    return BadRequest(new BaseResponseDTO { IsSuccess = false, Errors = errors.ToArray() });
                }
                return StatusCode((int)HttpStatusCode.Created);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        // Action method to view slots
        [HttpGet]
        [Authorize(Roles = "Panel Member, Reporting Manager")]
        public async Task<IActionResult> ViewSlot()
        {
            try
            {
                // Get logged-in user's name
                var loggedInUser = User.Identity.Name;
                if (string.IsNullOrEmpty(loggedInUser))
                {
                    return BadRequest(new BaseResponseDTO
                    {
                        IsSuccess = false,
                        Errors = new[] { "User not authenticated." }
                    });
                }

                // Send query to get slots
                var query = new SlotViewQuery(loggedInUser);
                var slots = await _mediator.Send(query);
                return Ok(slots.ToList());
            }
            catch (Exception ex)
            {
                // Log the exception
                Console.WriteLine($"An error occurred while processing the ViewSlot request: {ex.Message}");
                // Return a generic error response
                return StatusCode((int)HttpStatusCode.InternalServerError, new BaseResponseDTO
                {
                    IsSuccess = false,
                    Errors = new[] { "An error occurred while processing your request. Please try again later." }
                });
            }
        }

        // Action method to update slot availability
        [HttpPatch("availability")]
        [Authorize(Roles = "TA Recruiter, TA Admin ,Panel Member")]
        public async Task<IActionResult> UpdateSlotAvailability(List<Guid> slotId)
        {
            try
            {
                var responses = new List<object>();
                var errors= new List<string>();
                foreach (var id in slotId)
                {
                    try
                    {
                        var command = new UpdateSlotAvailabilityCommand(id);
                        var response = await _mediator.Send(command);
                        responses.Add(response);
                    }
                    catch(DuplicateUserException ex)
                    {
                        errors.Add(ex.Message);
                    }
                    
                }
                if (errors.Any())
                {
                    return BadRequest(new BaseResponseDTO { IsSuccess = false, Errors = errors.ToArray() });
                }

                // Check if any response is a HttpStatusCode
                if (responses.All(r => r.GetType() == typeof(HttpStatusCode)))
                {
                    // If all responses are HttpStatusCode, return the first one
                    return StatusCode((int)responses.First());
                }

                // If no HttpStatusCode is returned, return OK
                return Ok(new { status = "Updated data successfully!" });
            }
            catch (Exception)
            {
                // Log the exception here
                return StatusCode((int)HttpStatusCode.InternalServerError);
            }

        }

        // Action method to update slot block status
        [HttpPatch("block")]
        [Authorize(Roles = "TA Admin, TA Recruiter")]
        public async Task<IActionResult> UpdateSlotBlock(Guid slotId)
        {
            try
            {
                var command = new UpdateSlotBlockCommand(slotId);
                var response = await _mediator.Send(command);
                var jsonResponse = JsonConvert.SerializeObject(response);
                return Ok(jsonResponse);
            }
            catch (Exception)
            {
                // Log the exception here
                return StatusCode((int)HttpStatusCode.InternalServerError,
                    new BaseResponseDTO { IsSuccess = false, Errors = new[] { "An error occurred while processing the request." } });
            }
        }

        // Action method to handle No Show
        [HttpPatch("NoShow")]
        [Authorize(Roles = "TA Admin, TA Recruiter")]
        public async Task<IActionResult> NoShow([FromBody] NoShowDTO model)
        {
            try
            {
                var command = new NoShowCommand(model);
                var response = await _mediator.Send(command);
                var jsonResponse = JsonConvert.SerializeObject(response);
                return Ok(jsonResponse);
            }
            catch (NotFoundException ex)
            {
                return NotFound(new { ErrorMessage = ex.Message });
            }
            catch (Exception)
            {
                // Log the exception here
                return StatusCode((int)HttpStatusCode.InternalServerError,
                    new BaseResponseDTO { IsSuccess = false, Errors = new[] { "An error occurred while processing the request." } });
            }
        }
    }
}
