using System;
using System.Net;
using System.Security.Authentication;
using System.Threading.Tasks;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.DTO;
using Assignment.Core.Exceptions;
using Assignment.Providers.Handlers.Commands;
using Assignment.Providers.Handlers.Queries;
using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace Assignment.Controllers
{
    // Controller for handling user authentication
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly IConfiguration _configuration;
        private readonly ILogger<LoginController> _logger;
     

        // Constructor to initialize dependencies
        public LoginController(IMediator mediator, IConfiguration configuration, ILogger<LoginController> logger)
        {
            _mediator = mediator;
            _configuration = configuration;
            _logger = logger;
           
        }

        // Endpoint for user login
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] CreateUserDTO model)
        {
            try
            {
                var command = new SignInUserByUserNameQuery(model.Username, model.Password);
                var response = await _mediator.Send(command);

                // Logging successful login
                LogSuccessLogin(model.Username);

                return Ok(response);
            }
            // Handling entity not found exception
            catch (EntityNotFoundException ex)
            {
                return NotFound(new BaseResponseDTO
                {
                    IsSuccess = false,
                    Errors = new[] { ex.Message }
                });
            }
            // Handling invalid credential exception
            catch (InvalidCredentialException ex)
            {
                return BadRequest(new BaseResponseDTO
                {
                    IsSuccess = false,
                    Errors = new[] { ex.Message }
                });
            }
            // Handling invalid request body exception
            catch (InvalidRequestBodyException ex)
            {
                return BadRequest(new BaseResponseDTO
                {
                    IsSuccess = false,
                    Errors = new[] { ex.Message }
                });
            }
            // Handling generic exceptions
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, new BaseResponseDTO
                {
                    IsSuccess = false,
                    Errors = new[] { ex.Message }
                });
            }
        }

        // Endpoint for refreshing access token
        [HttpPost("refresh-token")]
        public async Task<IActionResult> RefreshToken([FromBody] RefreshTokenDTO refreshTokenDto)
        {
            try
            {
                var command = new RefreshTokenCommand(refreshTokenDto.Token);
                var response = await _mediator.Send(command);

                // Logging successful token refresh
                LogSuccessTokenRefresh(refreshTokenDto.Token);

                return Ok(new
                {
                    accessToken = response.AccessToken,
                    accessTokenExpiration = response.AccessTokenExpiration,
                    refreshToken = response.RefreshToken,
                    refreshTokenExpiration = response.RefreshTokenExpiration
                });
            }
            // Handling unauthorized access exception
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(new BaseResponseDTO
                {
                    IsSuccess = false,
                    Errors = new[] { ex.Message }
                });
            }
            // Handling invalid token exception
            catch (InvalidTokenException ex)
            {
                return Unauthorized(new BaseResponseDTO
                {
                    IsSuccess = false,
                    Errors = new[] { ex.Message }
                });
            }
            // Handling generic exceptions
            catch (Exception ex)
            {
                return StatusCode((int)HttpStatusCode.InternalServerError, new BaseResponseDTO
                {
                    IsSuccess = false,
                    Errors = new[] { ex.Message }
                });
            }
        }
// Endpoint for revoking refresh token
[HttpPost("revoke-refresh-token")]
public async Task<IActionResult> RevokeRefreshToken([FromBody] RevokeTokenDTO revokeTokenDto)
{
    try
    {
        var command = new RevokeRefreshTokenCommand(revokeTokenDto.Token);
        await _mediator.Send(command);

        return Ok(new BaseResponseDTO { IsSuccess = true });
    }
    catch (UnauthorizedAccessException ex) // Add this catch block
    {
        return Unauthorized(new BaseResponseDTO
        {
            IsSuccess = false,
            Errors = new[] { ex.Message }
        });
    }
    catch (InvalidTokenException ex) // Catch InvalidTokenException here
    {
        return Unauthorized(new BaseResponseDTO
        {
            IsSuccess = false,
            Errors = new[] { ex.Message }
        });
    }
    catch (Exception ex)
    {
        return StatusCode((int)HttpStatusCode.InternalServerError, new BaseResponseDTO
        {
            IsSuccess = false,
            Errors = new[] { ex.Message }
        });
    }
}

        // Method to log successful login
        private void LogSuccessLogin(string username)
        {
            _logger.LogInformation("User '{Username}' logged in successfully.", username);
        }

        // Method to log successful token refresh
        private void LogSuccessTokenRefresh(string token)
        {
            _logger.LogInformation("Token refresh successful for token '{Token}'.", token);
        }
    }
}
