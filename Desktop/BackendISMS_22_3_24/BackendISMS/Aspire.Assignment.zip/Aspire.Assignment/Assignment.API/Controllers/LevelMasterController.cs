using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Assignment.Contracts.DTO;
using Assignment.Core.Exceptions;
using Assignment.Providers.Handlers.Queries;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.Extensions.Configuration;

namespace Assignment.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize(Roles = "Panel Coordinator")]
    public class LevelMasterController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly IConfiguration _configuration;

        public LevelMasterController(IMediator mediator, IConfiguration configuration)
        {
            _mediator = mediator;
            _configuration = configuration;
        }

      [HttpGet("InterviewLevel")]
[EnableQuery]
public async Task<IActionResult> GetLevelMaster()
{
    try
    {
        var query = new GetLevelMasterQuery();
        var levelMaster = await _mediator.Send(query);

        // Check if levelMaster is null or empty
        if (levelMaster == null || levelMaster.Count() == 0) // Assuming levelMaster is a method group that returns IEnumerable
            return NotFound("Levels not found");

        return Ok(levelMaster);
    }
    catch (NotFoundException ex)
    {
        return NotFound(ex.Message);
    }
    catch (UnauthorizedAccessException ex)
    {
        return Unauthorized(ex.Message);
    }
    catch (ValidationException ex)
    {
        return BadRequest(ex.Message);
    }
    catch (InvalidOperationException ex)
    {
        return BadRequest(ex.Message);
    }
    catch (Exception ex)
    {
        // Log the exception for further investigation
        Console.WriteLine($"An error occurred: {ex}");

        // Return a generic error message to the client
        return StatusCode((int)HttpStatusCode.InternalServerError, "An error occurred while processing your request.");
    }
}

    }
}
