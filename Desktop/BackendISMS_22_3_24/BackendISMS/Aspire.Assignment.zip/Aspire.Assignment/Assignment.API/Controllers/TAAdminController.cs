using System;
using System.Collections;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.DTO;
using Assignment.Core.Exceptions;
using Assignment.Providers.Handlers.Commands;
using Assignment.Providers.Handlers.Queries;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace Assignment.Controllers
{
    // Controller for managing TA admin actions
    [Route("api/[controller]")]
    [ApiController]
    [EnableQuery]
   [Authorize(Roles = "TA Recruiter, TA Admin")]
    public class TAAdminController : ControllerBase
    {
        private readonly IMediator _mediator;

        // Constructor to initialize mediator
        public TAAdminController(IMediator mediator)
        {
            _mediator = mediator;
        }

        // Action method to get slot details
        [HttpGet]
        [ProducesResponseType(typeof(IEnumerable<TAAdminDTO>), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(BaseResponseDTO), (int)HttpStatusCode.InternalServerError)]
        public async Task<IActionResult> GetSlot()
        {
            try
            {
                // Send query to get slot details
                var query = new GetSlotDetailsQuery();
                var slotDetails = await _mediator.Send(query);

                // Check if slotDetails is null
                if (slotDetails == null)
                {
                    return StatusCode((int)HttpStatusCode.InternalServerError,
                        new BaseResponseDTO
                        {
                            IsSuccess = false,
                            Errors = new[] { "Response from mediator is null." }
                        });
                }
                
                return Ok(slotDetails);
            }
            catch (NotFoundException ex)
            {
                // Handle not found exception
                return NotFound(new BaseResponseDTO
                {
                    IsSuccess = false,
                    Errors = new[] { ex.Message }
                });
            }
            catch (InvalidInputException ex)
            {
                // Handle invalid input exception
                return BadRequest(new BaseResponseDTO
                {
                    IsSuccess = false,
                    Errors = new[] { ex.Message }
                });
            }
            catch (DateErrorException ex)
            {
                // Handle date error exception
                return BadRequest(new BaseResponseDTO
                {
                    IsSuccess = false,
                    Errors = new[] { ex.Message }
                });
            }
            catch (Exception ex)
            {
                // Handle general exception
                return StatusCode((int)HttpStatusCode.InternalServerError,
                    new BaseResponseDTO
                    {
                        IsSuccess = false,
                        Errors = new[] { ex.Message }
                    });
            }
        }
    }
}
