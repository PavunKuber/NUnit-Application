using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using Assignment.Contracts.Data.Entities;
using Assignment.Contracts.DTO;
using Assignment.Providers.Handlers.Queries;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OData.Query;

namespace Assignment.Controllers
{
    // Controller for managing reporting manager actions
    [Route("api/[controller]")]
    [ApiController]
    [EnableQuery]
    [Authorize(Roles = "Reporting Manager")] // Authorize attribute to restrict access to Reporting Manager role only
    public class ReportingManagerController : ControllerBase
    {
        private readonly IMediator _mediator;

        // Constructor to initialize mediator
        public ReportingManagerController(IMediator mediator)
        {
            _mediator = mediator;
        }

        // Endpoint for GET /api/ReportingManager/teammembers
        [HttpGet("teammembers")]
        [ProducesResponseType(typeof(IEnumerable<TeamMemberDTO>), (int)HttpStatusCode.OK)]
        [ProducesErrorResponseType(typeof(BaseResponseDTO))]
        // Action method to get team members
        public async Task<IActionResult> GetMember()
        {
            try
            {
                var loggedInUser = User.Identity.Name;
                var query = new GetTeamMemberQuery(loggedInUser);
                var teamMembers = await _mediator.Send(query);
                return Ok(teamMembers);
            }
            catch (NotFoundException ex)
            {
                return NotFound(new BaseResponseDTO
                {
                    IsSuccess = false,
                    Errors = new[] { ex.Message }
                });
            }
            catch (InvalidParameterException ex)
            {
                return BadRequest(new BaseResponseDTO
                {
                    IsSuccess = false,
                    Errors = new[] { ex.Message }
                });
            }
            catch (PermissionDeniedException ex)
            {
                return StatusCode(
                    (int)HttpStatusCode.Forbidden,
                    new BaseResponseDTO
                    {
                        IsSuccess = false,
                        Errors = new[] { ex.Message }
                    }
                );
            }
            catch (Exception ex)
            {
                return StatusCode(
                    (int)HttpStatusCode.InternalServerError,
                    new BaseResponseDTO
                    {
                        IsSuccess = false,
                        Errors = new[] { ex.Message }
                    }
                );
            }
        }
    }
}
