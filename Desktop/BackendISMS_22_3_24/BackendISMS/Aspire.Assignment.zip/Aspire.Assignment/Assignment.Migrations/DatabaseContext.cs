using System.Threading;
using System.Threading.Tasks;
using Assignment.Contracts.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace Assignment.Migrations
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext(DbContextOptions<DatabaseContext> options)
            : base(options)
        {
            ChangeTracker.QueryTrackingBehavior = QueryTrackingBehavior.NoTracking;
        }

        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
        {
            foreach (var item in ChangeTracker.Entries<BaseEntity>().AsEnumerable())
            {
                item.Entity.AddedOn = DateTime.Now;
            }

            return base.SaveChangesAsync(cancellationToken);
        }

        // DbSet property for accessing the CodeMasters table


        // Other DbSet properties for accessing database tables
        public DbSet<App> App { get; set; }
        public DbSet<User> User { get; set; }
        public DbSet<Users> Users { get; set; }
        public DbSet<Roles> Roles { get; set; }
        public DbSet<UserRole> UserRole { get; set; }
        public DbSet<UsersDetail> UsersDetail { get; set; }
        public DbSet<SlotDetails> SlotDetails { get; set; }
        public DbSet<LevelMaster> LevelMasters { get; set; }
        public DbSet<CodeMapping> CodeMapping { get; set; }
        public DbSet<CodeMaster> CodeMasters { get; set; }

        public DbSet<RefreshToken> RefreshToken { get; set; }
        public DbSet<AllocateDate> AllocateDate { get; set; }
        public DbSet<TAAdmin> TAAdmin { get; set; }
        public DbSet<RefreshToken> RefreshTokens { get; set; }

    }
}
