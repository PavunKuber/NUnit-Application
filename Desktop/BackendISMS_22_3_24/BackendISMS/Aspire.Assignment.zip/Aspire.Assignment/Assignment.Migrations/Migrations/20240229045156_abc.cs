﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Assignment.Migrations.Migrations
{
    public partial class abc : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsAvailable",
                table: "SlotDetails");

            migrationBuilder.DropColumn(
                name: "IsBlocked",
                table: "SlotDetails");

            migrationBuilder.AddColumn<string>(
                name: "Remarks",
                table: "SlotDetails",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Status",
                table: "SlotDetails",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Remarks",
                table: "SlotDetails");

            migrationBuilder.DropColumn(
                name: "Status",
                table: "SlotDetails");

            migrationBuilder.AddColumn<bool>(
                name: "IsAvailable",
                table: "SlotDetails",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "IsBlocked",
                table: "SlotDetails",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }
    }
}
